//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// This file implements the "general" functions of Node
//---------------------------------------------------------------------------

#include "general.h"
#include "node.h"

//---------------------------------------------------------------------------

void Node::dump()
{ logState(cerr); }

void dumpAddress(Address& address)
{ cerr << address; }

void dumpNode(Node& node)
{ node.logState(cerr); }

void dumpMessage(IMessageContent& message)
{ cerr << message; }

//---------------------------------------------------------------------------

static int nodeInstanceCounter = 0;

Node::Node() : heardIfaceSet(),
	       neighborSet(this), linkSet(this), twoHopNeighborSet(this),
	       mprSelectorSet(this), topologySet(this), 
	       ifaceAssociationSet(this), hnaSet(this),
	       duplicateSet(this)
#ifdef NU_AUTOCONF // {DAD}
	       , stateSet(this)
#endif // NU_AUTOCONF
	       , hadGeneratedTC(false)
{
  strId = "<identifier not initialized>";
  nodeInstanceIdx = nodeInstanceCounter++;

#ifdef MULTICAST_RESEARCH
  initMulticast();
#endif
#ifdef AUTOCONF_IPV4_NETFILTER
  dadNetfilter = NULL; 
#endif // AUTOCONF_IPV4_NETFILTER

  packetManager = NULL;
  protocolConfig = NULL;
  baseScheduler = NULL;
  networkConfigurator = NULL;
  addressListCache = NULL; // XXX: free at end
  currentRoutingTable = new RoutingTable(this); // XXX: never NULL now

  emptyTCTimeLimit = TimePastNever;

  oneHopNeighborhoodChanged = true;
  twoHopNeighborhoodChanged = true;;
}

int Node::globalEventCounter = 0;

void Node::start()
{
  D(*log, lConfig,
    getRealTime() << " [config] " << getId() << " " 
    << (*protocolConfig) << endl);
  for(std::list<OLSRIface*>::iterator it = ifaceList.begin();
      it != ifaceList.end(); it++) {
    D(*log, lConfig,
      getRealTime() << " [iface-config] " << getId() << " " 
      << (*it)->getAddress() << " " << (*(*it)->getConfig()) << endl);
  }

  eventCounter = globalEventCounter;

  startNeighborSensing();
  startTopologyDiscovery();
  startJitterStrategy();
  startRoutingTableCalculation();
  startHNABase();
  startIfaceAssociationBase();
#ifdef MULTICAST_RESEARCH
  startMulticast();
#endif 
#ifdef NU_AUTOCONF // {DAD}
  autoConfState = STATE_HELLO;
  autoConfStateTime = getCurrentTime();
#endif /* NU_AUTOCONF */

  scheduleNextJitterStrategyEvent(true);
}

void Node::configure(IScheduler* aBaseScheduler,
		     AddressFactory* aAddressFactory,
		     PacketManager* aPacketManager,
		     INetworkConfigurator* aNetworkConfigurator,
		     ProtocolConfig* aProtocolConfig,
		     std::vector<ISystemIface*>& systemIfaceList,
		     Log* aLog)
{
  addressFactory = aAddressFactory;
  packetManager = aPacketManager;
  protocolConfig = aProtocolConfig;
  baseScheduler = aBaseScheduler;
  networkConfigurator = aNetworkConfigurator;
  log = aLog;

  ifaceList.clear();
  for (unsigned int i=0;i<systemIfaceList.size();i++) {
    OLSRIface* iface = new OLSRIface(this, systemIfaceList[i]);
    ifaceList.push_back(iface); // XXX: must be deleted at end of program
  }

  advertisedHNAList.clear();
  for(std::list< std::pair<string,string> >::iterator it 
	= protocolConfig->hnaList.begin();
      it != protocolConfig->hnaList.end(); it++) {
    Address networkAddress = 
      addressFactory->parseAddress((char*)((*it).first.c_str()));
    Address networkMask = 
      addressFactory->parseAddress((char*)((*it).second.c_str()));
    advertisedHNAList.push_back
      ( std::pair<Address,Address>(networkAddress, networkMask) );
  }

  currentTime = baseScheduler->getTime();
  expiredTime = currentTime;
  nextTupleExpireTime = currentTime;

  ostringstream out;
  out << getMainAddress();
  strInitialId = out.str();
  strId = strInitialId;

  packetManager->init();
}

// The main receiving function.
void Node::evReceivePacket(MemoryBlock* packet,
			   Address sendIfaceAddress,
			   OLSRIface* recvIface)
{
  updateCurrentTime();
  preEvent("receive-packet");
  D(*log, lEvent,
    getRealTime() << " [receive-packet] " << getId() << " " 
    << sendIfaceAddress << " " << recvIface->getAddress() << " " << (*packet) 
    << endl );
  if (isRunning()) {
    packetManager->processPacket(sendIfaceAddress,
				 recvIface->getAddress(),
				 packet);
    processChange(true);
  }
  postEvent("receive-packet");
}

//---------------------------------------------------------------------------

//--------------- Expiration management

//template<class Tuple>
//void updateMinExpireTime(Time& result, bool& alreadyHasMinTime,
//			 BasicTupleSet<Tuple>& set)
//{
// bool hasTime = false;
// Time newTime = set.getMinExpireTime(hasTime);
// if (hasTime) {
//   if(!alreadyHasMinTime || (newTime < result))
//     result = newTime;
//   alreadyHasMinTime = true;
// }
//}

void Node::performTupleExpiration()
{
  expiredTime = getCurrentTime();
  Time clock = expiredTime;

  linkSet.removeAndDeleteExpired(clock);
  twoHopNeighborSet.removeAndDeleteExpired(clock);
  mprSelectorSet.removeAndDeleteExpired(clock);
  topologySet.removeAndDeleteExpired(clock);
  ifaceAssociationSet.removeAndDeleteExpired(clock);
  hnaSet.removeAndDeleteExpired(clock);
  // (XXX: one could do lazy-removal of duplicate set)
  duplicateSet.removeAndDeleteExpired(clock); 

  nextTupleExpireTime = currentTime;
}

void Node::getNextExpireTime(Time& nextExpireTime, bool& hasExpireTime)
{
  //XXX:remove: this->nextTupleExpireTime;

  hasExpireTime = false;
  updateMinExpireTime(nextExpireTime, hasExpireTime, linkSet);
  updateMinExpireTime(nextExpireTime, hasExpireTime, twoHopNeighborSet);
  updateMinExpireTime(nextExpireTime, hasExpireTime, mprSelectorSet);
  updateMinExpireTime(nextExpireTime, hasExpireTime, topologySet);
  updateMinExpireTime(nextExpireTime, hasExpireTime, ifaceAssociationSet);
  updateMinExpireTime(nextExpireTime, hasExpireTime, hnaSet);
  updateMinExpireTime(nextExpireTime, hasExpireTime, duplicateSet);
}

void Node::eventPerformExpiration(void* timePtr)
{
  updateCurrentTime();

  Time* previousTime = (Time*)timePtr;
  if (nextTupleExpireTime>*previousTime) {
    // the min expire time as changed since, so don't bother
    delete previousTime;
    return;
  }

  preEvent("expire");
  performTupleExpiration();
  processChange(true);
  scheduleExpirationEvent();
  postEvent("expire");
  delete previousTime;
}

void Node::scheduleExpirationEvent()
{
  bool hasExpireTime;
  Time nextExpireTime;
  getNextExpireTime(nextExpireTime, hasExpireTime);
  if(hasExpireTime && nextExpireTime >= this->nextTupleExpireTime) {
    Time* expireTimePtr = new Time;
    *expireTimePtr = nextExpireTime;
    this->nextTupleExpireTime = nextExpireTime;
    addEventAt(nextExpireTime, 
	       new NodeMethodCallback(this, &Node::eventPerformExpiration),
	       expireTimePtr);
  }
}

//---------------------------------------------------------------------------

//-------------------- Jitter strategy
/// [JitterStrategy] Initialize the counters of the jitter strategy

void Node::startJitterStrategy()
{ 
  jitterStrategyEventTime = getCurrentTime();
  jitterStrategyEventIndex = 0;
  addEvent(0.0, new NodeMethodCallback(this, &Node::eventJitterStrategy),
	   (void*)jitterStrategyEventIndex);
}

/// [JitterStrategy] The moment at which the node decide to send orc
/// not the message which are pending in the queues.

void Node::eventJitterStrategy(void* uintAsVoidPtr)
{
  unsigned int eventIndex = (unsigned int)uintAsVoidPtr;
  updateCurrentTime();
  log->active = getCurrentTime() >= protocolConfig->startLogTime;
  D(*log, lEventStrategy, getRealTime() << " [event-strategy] " << getId() 
    << " " << eventIndex);
  if (eventIndex != jitterStrategyEventIndex) {
    D(*log, lEventStrategy, " ignored" << endl);
    return; // the event was overridden
  }

#ifdef NU_AUTOCONF
  _getAutoConfState();
#endif
  double delay = drawDouble(protocolConfig->strategyInterval);

  // XXX: non-optimal: because the event may be canceled in processJitterStrat.
  jitterStrategyEventIndex++;
  jitterStrategyEventTime = getCurrentTime() + delay;
  D(*log, lEventStrategy, " next=" << jitterStrategyEventTime << endl);
  addEvent(delay, new NodeMethodCallback(this, &Node::eventJitterStrategy),
	   (void*)jitterStrategyEventIndex);
  
  processJitterStrategy();
}

void Node::processJitterStrategy()
{
  bool shouldReschedule = false;

  jitterStrategyEventTime = 
    adjustTimeWithGeneration(jitterStrategyEventTime, shouldReschedule);
  if(shouldReschedule) {
    D(*log, lEventStrategy, getRealTime() << " [strategy-reschedule] " 
      << jitterStrategyEventTime << endl);
  }

  bool hasProcessedEvent = false;

  // Process all generation events that must be scheduled now:
  std::list<GenerationEvent>::iterator it = generationEventList.begin();
  while(it != generationEventList.end()) {
    std::list<GenerationEvent>::iterator current = it;
    it++;
    if ((*current).maxTime < jitterStrategyEventTime) {
      assert((*current).minTime <= getCurrentTime());
      NodeMethod method = (*current).method;
      D(*log, lEventStrategy, getRealTime() << " [event-strategy-callback] " 
	<< getId() << " " << endl);
      (this->*method)();
      generationEventList.erase(current);
      hasProcessedEvent = true;
    }
  }
  // XXX: those might have re-generated expiring events...
  // It should be ok, if the INTERVALs-MAXJITTER > strategyInterval

  // Process and send all messages that would be expired by 
  // strategy time:
  packetManager->sendUpToTime(jitterStrategyEventTime);

  processChange(true);
  if (hasProcessedEvent) // XXX: is this really necessary?
    scheduleExpirationEvent();
  scheduleNextJitterStrategyEvent(shouldReschedule);
}

Time Node::adjustTimeWithGeneration(Time upcomingTime, bool& hasChanged)
{
  Time nextTime = upcomingTime;
  hasChanged = false;
  for(std::list<GenerationEvent>::iterator it = generationEventList.begin();
      it != generationEventList.end(); it++) 
    {
      if ((*it).minTime > getCurrentTime() && (*it).maxTime < nextTime) {
	nextTime = drawDouble((*it).maxTime - (*it).minTime) + (*it).minTime;
	hasChanged = true;
      }
    }
  return nextTime;
}

void Node::scheduleNextJitterStrategyEvent(bool shouldReschedule)
{
  bool hasChanged = false;
  jitterStrategyEventTime = adjustTimeWithGeneration
    (jitterStrategyEventTime, hasChanged);  

  if (shouldReschedule || hasChanged) {
    jitterStrategyEventIndex++;
    D(*log, lEventStrategy, getRealTime() << " [strategy-reschedule] " 
      << getId() << " " << jitterStrategyEventIndex << " "  
      << jitterStrategyEventTime << endl);

    // XXX!! remove this
    if(jitterStrategyEventTime < getCurrentTime()) {
      D(*log, lEventStrategy, getRealTime() << " [strategy-FATAL] " 
	<< getCurrentTime() << " " << jitterStrategyEventTime
	<< endl);
      FatalAndCloseLog(*log, "Scheduler going back in time! Bad, bad, bad.");
    }

    addEventAt(jitterStrategyEventTime,
	     new NodeMethodCallback(this, &Node::eventJitterStrategy),
	     (void*)jitterStrategyEventIndex);
  }
}

//---------------------------------------------------------------------------

void Node::writeIfaceList(ostream& out)
{
  out << "[node-iface]";
  std::list<Address>* addressList = getAddressList();
  for(std::list<Address>::iterator it = addressList->begin();
      it != addressList->end(); it++)
    out << " "<< (*it);
  out << endl;
}

#ifndef LOG_LINK_SET
#define LOG_LINK_SET
#endif

void Node::logState(ostream& out)
{
  out << getRealTime() << " [state-begin] " << getId()
      << endl;
  out << getRealTime() << " [table-neighbor] " << getId()
      << ": " << neighborSet << endl;
#ifdef LOG_LINK_SET
  out << getRealTime() << " [table-link] " << getId()
      << ": " << linkSet << endl;
#endif
  out << getRealTime() << " [table-two-hop] " << getId()
      << ": " << twoHopNeighborSet << endl;
  out << getRealTime() << " [table-topology] " << getId()
      << ": " << topologySet << endl;
  out << getRealTime() << " [table-mpr] "<< getId()
      << ": "; writeMPRSet(out); out << endl;
  out << getRealTime() << " [table-mpr-selector] "<< getId()
      << ": " << mprSelectorSet << endl;
  out << getRealTime() << " [table-route] " << getId()
      << ": " << (*currentRoutingTable) << endl;
  out << getRealTime() << " [table-mid] " << getId()
      << ": " << ifaceAssociationSet << endl;
  out << getRealTime() << " [table-hna] " << getId()
      << ": " << hnaSet << endl;
  out << getRealTime() << " [table-duplicate] " << getId()
      << ": " << duplicateSet << endl;
#ifdef NU_AUTOCONF // {DAD}
  out << getRealTime() << " [table-state] " << getId() 
      << ": " << stateSet << endl;
#endif
#ifdef MULTICAST_RESEARCH
  out << getRealTime() << " [table-joined-group-list] " << getId()
      << ": "; writeJoinedGroupList(out); out << endl;
  out << getRealTime() << " [table-group-map] " << getId()
      << ": "; writeGroupMap(out); out << endl;
#endif

  out << getRealTime() << " [state-info] " << getId()
      << " strategy_time=" << jitterStrategyEventTime
      << "; evt_counter=" << eventCounter
      << "; current_time=" << currentTime
      << "; expire_time=" << expiredTime
      << "; next_expire_time=" << nextTupleExpireTime
      << "; message_queue=(";
  packetManager->writeMessageQueue(out);
  out <<")";
#ifdef NU_AUTOCONF // {DAD}
  out << "; auto_conf_state=" << autoConfState
      << "; auto_conf_time=" << autoConfStateTime;
#endif
  out << endl;

  out << getRealTime() << " [state-end] " << getId()
      << endl;


}

//---------------------------------------------------------------------------
