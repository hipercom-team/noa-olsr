//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
// TODO:
// XXX: enforce MTU
//---------------------------------------------------------------------------

#include "general.h"

#include <stdlib.h>
#include <assert.h>
#include <stdio.h>

#ifdef SYSTEMlinux
#include <dlfcn.h>
#endif

#include "mystream.h"
#include <vector>

//---------------------------------------------------------------------------

#include "simulation-api.h"
#include "protocol-plugin-api.h"

//---------------------------------------------------------------------------

#include <node.h>
#include "network_generic.h"
#include "scheduler_simulation.h"
#include "simul_world.h"

//---------------------------------------------------------------------------

const int IfaceMtu = 1000;

PPA_PlugeeApi myApi;

SimulationScheduler* scheduler = NULL;
PPA_PluginApi* pluginApi = NULL;
PPA_OpaqueFunctionCall pluginOpaqueFunction = NULL;

//unsigned int broadcastAddress = 0xfffffffful;
static int maxNodeIndex = -1;
//PPA_PluginNode* nodeArray = NULL;
class InternalNode;
static InternalNode** nodeArray = NULL;

bool validNodeIndex(int nodeIndex, int ifaceIndex = -1);

#ifdef NU_AUTOCONF
#include "nu_autoconf.h"
NUAutoConfExtensionApi* nuAutoConfApi;
#endif

//---------------------------------------------------------------------------

class SimulationStatistic
{
public:
  int nbPacketSend;
  int nbPacketRecv;
  int nbByteSend;
  int nbByteRecv;
  int nbRouteAdd;
  int nbRouteDel;
  int currentRouteMetric;

  void reset() {
    nbPacketSend = 0;
    nbPacketRecv = 0;
    nbByteSend = 0;
    nbByteRecv = 0;
    nbRouteAdd = 0;
    nbRouteDel = 0;
    currentRouteMetric = 0;
  }
};

SimulationStatistic statistic;

#include <sstream> // XXX

extern "C"
void getSimulationStat(char** resultData, int* resultSize)
{
  ostringstream out;
  SimulationStatistic& s = statistic;
  out << "#send: " << s.nbPacketSend << ", #recv: " << s.nbPacketRecv
      << ", #byte_send: " << s.nbByteSend << ", #byte_recv: " << s.nbByteRecv
      << ",\n  #route+: " <<  s.nbRouteAdd << ", #route-: " << s.nbRouteDel
      << ", #route: " << (s.nbRouteAdd - s.nbRouteDel)
      << ", #avgRoute: " << ((double)s.currentRouteMetric 
			     / (s.nbRouteAdd - s.nbRouteDel));
  out << endl;
  std::string result = out.str();
  *resultSize = result.length()+1;
  *resultData = (char*) malloc( *resultSize );
  memcpy(*resultData, result.c_str(), *resultSize-1);
  (*resultData)[(*resultSize)-1] = '\0';
}

//---------------------------------------------------------------------------

typedef struct {
  int nodeIdx;
  int ifaceIdx;
} InternalAddress;

typedef struct {
  int srcIfaceIdx;
  int dstNodeIdx;
  int dstIfaceIdx;
  GetLinkFunction getLinkFunction;
  void* getLinkFunctionData;
} InternalLink;

static void makeAddress(int nodeIdx, int ifaceIdx, void*& result)
{
  if (result == NULL)
    result = malloc(sizeof(InternalAddress));
  InternalAddress* address = (InternalAddress*) result;
  address->nodeIdx = nodeIdx;
  address->ifaceIdx = ifaceIdx;
}

static int addressToNodeIdx(PPA_Address address)
{ return ((InternalAddress*)address)->nodeIdx; }

static int addressToIfaceIdx(PPA_Address address)
{ return ((InternalAddress*)address)->ifaceIdx; }

static const int multicastNodeIdx = 0xfffe;
static const int noNodeIdx = 0xffff;
static const int noIfaceIdx = 0xffff;

static void getBroadcastAddress(PPA_Address resultAddress)
{ makeAddress(noNodeIdx, noIfaceIdx, resultAddress); }


typedef void(*NodeMulticastOperationFunction)(PPA_PluginNode pluginNode,
					      PPA_Address multicastAddress);
class InternalNode 
{
public:
  InternalNode(int aNodeIdx, int aNbIface, int aMTU) 
    :   pluginNode(NULL), nbIface(aNbIface), nodeIdx(aNodeIdx)
  { 
    interfaceAddressArray = (void**)malloc(sizeof(void*)* nbIface);
    interfaceMTUArray = (int*)malloc(sizeof(int)* nbIface);
    for(int i=0;i<nbIface;i++) {
      interfaceAddressArray[i] = NULL;
      interfaceMTUArray[i] = aMTU;
      makeAddress(nodeIdx, i, interfaceAddressArray[i]);
    }
  }

  void multicastOperation(int groupIndex, 
			  NodeMulticastOperationFunction operationFunction)
  {
    PPA_Address multicastAddress = NULL;
    makeAddress(multicastNodeIdx, groupIndex, multicastAddress);
    assert( operationFunction != NULL );
    operationFunction(pluginNode, multicastAddress);
    free(multicastAddress);
  }

  void multicastJoinGroup(int groupIndex)
  {
    multicastOperation(groupIndex,
		       pluginApi->nodeMulticastJoinGroupFunction);
  }

  void multicastLeaveGroup(int groupIndex)
  {
    multicastOperation(groupIndex,
		       pluginApi->nodeMulticastLeaveGroupFunction);
  }


  void multicastSenderJoin(int groupIndex)
  {
    multicastOperation(groupIndex,
		       pluginApi->nodeMulticastSenderJoinFunction);
  }

  void multicastSenderLeave(int groupIndex)
  {
    multicastOperation(groupIndex,
		       pluginApi->nodeMulticastSenderLeaveFunction);
  }


  void addLink(int ifaceIdx, int dstNodeIdx, int dstIfaceIdx)
  {
    assert( validNodeIndex(nodeIdx, ifaceIdx) );
    assert( validNodeIndex(dstNodeIdx, dstIfaceIdx) );
    InternalNode* dstNode = nodeArray[dstNodeIdx]; UNUSED(dstNode);
    InternalLink link;
    link.srcIfaceIdx = ifaceIdx;
    link.dstNodeIdx = dstNodeIdx;
    link.dstIfaceIdx = dstIfaceIdx;
    link.getLinkFunction = NULL;
    link.getLinkFunctionData = NULL;
    linkList.push_back(link);
  }

  void addDynamicLink(int ifaceIdx, GetLinkFunction getLinkFunction,
		      void* data)
  {
    assert( validNodeIndex(nodeIdx, ifaceIdx) );
    InternalLink link;
    link.srcIfaceIdx = ifaceIdx;
    link.dstNodeIdx = -1;
    link.dstIfaceIdx = -1;
    link.getLinkFunction = getLinkFunction;
    link.getLinkFunctionData = data;
    linkList.push_back(link);
  }

  void removeLink(int ifaceIdx, int dstNodeIdx, int dstIfaceIdx)
  {
    assert( validNodeIndex(nodeIdx, ifaceIdx) );
    assert( validNodeIndex(dstNodeIdx, dstIfaceIdx) );
    InternalNode* dstNode = nodeArray[dstNodeIdx]; UNUSED(dstNode);

    for(std::list<InternalLink>::iterator it = linkList.begin();
	it != linkList.end(); it++) {
      InternalLink link = (*it);
      if ( (link.srcIfaceIdx == ifaceIdx)
	   && (link.dstNodeIdx == dstNodeIdx)
	   && (link.dstIfaceIdx == dstIfaceIdx)) {
	linkList.erase(it);
	return;
      }
    }
    Fatal("link to be removed not existing");
  }

  void removeDynamicLink(int ifaceIdx)
  {
    assert( validNodeIndex(nodeIdx, ifaceIdx) );

    std::list<InternalLink>::iterator it = linkList.begin();
    while(it != linkList.end()) {
      InternalLink link = (*it);
      std::list<InternalLink>::iterator nextIt = it;
      nextIt++;
      if ( (link.srcIfaceIdx == ifaceIdx)
	   && (link.getLinkFunction != NULL)) {
	linkList.erase(it);
      }
      it = nextIt;
    }
    Fatal("link to be removed not existing");
  }

  void writeLink(ostream& out)
  {
    for(std::list<InternalLink>::iterator it = linkList.begin();
	it != linkList.end(); it++) {
      InternalLink link = (*it);
      if (link.getLinkFunction == NULL) {
	out << " N" << nodeIdx << "I" << link.srcIfaceIdx << "->"
	    << "N" << link.dstNodeIdx << "I" << link.dstIfaceIdx;
      } else {
	out << " N" << nodeIdx << "I" << link.srcIfaceIdx << "->*";
      }
    }
  }

  PPA_PluginNode pluginNode;

  std::list<InternalLink> linkList;

  void** interfaceAddressArray;
  int* interfaceMTUArray;
  int nbIface;
  int nodeIdx;
};

bool validNodeIndex(int nodeIndex, int ifaceIndex)
{ 
  return inrange(0, nodeIndex, maxNodeIndex)
    && nodeArray[nodeIndex] != NULL
    && ((ifaceIndex<0) 
	|| inrange(0, ifaceIndex, nodeArray[nodeIndex]->nbIface));
}

//---------------------------------------------------------------------------

PPA_Packet clonePacket(const PPA_Packet& packet)
{
  PPA_Packet result;
  result.data = (octet*)malloc(packet.size);
  result.size = packet.size;
  memcpy(result.data, packet.data, packet.size);
  return result;
}

//inline unsigned int makeAddress(int nodeIndex, int ifaceIndex)
//{ return (nodeIndex<<8) | ifaceIndex; }


class PacketEvent : public IEvent
{
public:
  int nodeIdx;
  int ifaceIdx;
  PPA_Packet packet;
  PPA_Address srcAddress; // XXX! it must live longer than the function call

  PacketEvent(int aNodeIdx, int aIfaceIdx, PPA_Address aSrcAddress,
	      PPA_Packet aPacket)
    : nodeIdx(aNodeIdx), ifaceIdx(aIfaceIdx), packet(aPacket),
      srcAddress(aSrcAddress)
  {}

  virtual void handleEvent(void* data);

protected:
};

void PacketEvent::handleEvent(void* data)
{
  assert( data == NULL );
  assert( validNodeIndex(nodeIdx, ifaceIdx) );
  InternalNode* node = nodeArray[nodeIdx]; 

#ifdef NU_AUTOCONF__NOT_XXX_REMOVE
  PPA_Address actualSrcAddress = malloc(sizeof(InternalAddress));
  if (nuAutoConfApi != NULL)
    nuAutoConfApi->getActualAddressFunction(node->pluginNode,
					    srcAddress,
					    actualSrcAddress);
  else memcpy(actualSrcAddress, srcAddress, sizeof(InternalAddress));
#else
    PPA_Address actualSrcAddress = srcAddress;
#endif

  for(std::list<InternalLink>::iterator it = node->linkList.begin();
      it != node->linkList.end(); it++) {
    InternalLink link = (*it);
    if (link.srcIfaceIdx == ifaceIdx) {

      int dstCount = 0;
      int* dstNodeIdxList = NULL;
      int* dstIfaceIdxList = NULL;

      if(link.getLinkFunction != NULL) {
	link.getLinkFunction(link.getLinkFunctionData,
			     nodeIdx, ifaceIdx, &dstCount,
			     &dstNodeIdxList, &dstIfaceIdxList);

      } else {
	dstCount = 1;
	dstNodeIdxList = (int*) malloc(sizeof(int));
	dstIfaceIdxList = (int*) malloc(sizeof(int));
	dstNodeIdxList[0] = link.dstNodeIdx;
	dstIfaceIdxList[0] = link.dstIfaceIdx;
      }

      statistic.nbPacketSend ++;
      statistic.nbPacketRecv += dstCount;
      statistic.nbByteSend += packet.size;
      statistic.nbByteRecv += packet.size*dstCount;

      for(int i = 0;i<dstCount; i++) {
	assert( validNodeIndex(dstNodeIdxList[i], dstIfaceIdxList[i]) );
	if (dstNodeIdxList[i] != nodeIdx 
	    || dstIfaceIdxList[i] != ifaceIdx) {
	  // no loopback
	  InternalNode* dstNode = nodeArray[dstNodeIdxList[i]];
	  PPA_Address recvAddress =
	    dstNode->interfaceAddressArray[dstIfaceIdxList[i]];
	  pluginApi->nodeReceiveFunction(dstNode->pluginNode,
					 actualSrcAddress, recvAddress, 
					 dstIfaceIdxList[i],
					 clonePacket(packet));
	}
      }
      free(dstNodeIdxList);
      free(dstIfaceIdxList);
    }
  }
#ifdef NU_AUTOCONF__NOT_XXX_REMOVE
  free(actualSrcAddress);
#endif /* NU_AUTOCONF */
  free(packet.data);
}

double transmissionDelay = 0.0;

// Note:
// even when the node change its address, the srcAddress here would
// be the initial address of the node.
void sendPacket(PPA_PlugeeNode simSrcNode,
		PPA_Address srcAddress, /* of one of iface */
		int srcIfaceIndex,
		PPA_Address dstAddress,
		PPA_Packet packet)
{
  //const double transmissionDelay = 0.0;
  //unsigned int nodeIndex = addressToNodeIdx(srcAddress);
  //unsigned int ifaceIndex = addressToIfaceIdx(srcAddress);
  InternalNode* node = (InternalNode*)simSrcNode;
  int nodeIndex = node->nodeIdx;
  unsigned int ifaceIndex = srcIfaceIndex;
  assert( validNodeIndex(nodeIndex, ifaceIndex) );
  //InternalNode* node = nodeArray[nodeIndex]; 
  assert( ((PPA_PlugeeNode)node) == simSrcNode );
  // check that dst address is broadcast address:
  assert( (addressToNodeIdx(dstAddress) == noNodeIdx)
	  && (addressToIfaceIdx(dstAddress) == noIfaceIdx) );

  assert( sizeof(void*) >= sizeof(unsigned int) );
  scheduler->addEvent(transmissionDelay, 
		      new PacketEvent(nodeIndex, ifaceIndex, srcAddress,
				      packet), NULL);
}


int configureRoute(PPA_PlugeeNode simSrcNode,
		   /* borrowed: */
		   PPA_Route* route,
		   int flags /* add or delete */)
{ 
  /* do nothing - XXX: can record route */ 
  if (flags == PPA_ADD_ROUTE) {
    statistic.nbRouteAdd ++;
    statistic.currentRouteMetric += route->distance;
  } else if (flags == PPA_DEL_ROUTE) {
    statistic.nbRouteDel ++;
    statistic.currentRouteMetric -= route->distance;
  } else Fatal("Impossible configureRoute flags: " << flags);
  return 0; // XXX!: what should be returned?
}

//---------------------------------------------------------------------------

static unsigned int statEventCounter=0;
static unsigned int lastEventCounter=0;
static unsigned int eventCounterCheck=10;

#if 0
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <sched.h>

#include <sys/time.h>
#include <stdio.h>
#endif


volatile bool isFinished = false;

void outputStat(ostream& out)
{   
  char* data; int dataSize;
  getSimulationStat(&data, &dataSize);
  assert((int)strlen(data) == dataSize-1);
  out << getSimulationTime() << "/ " << data;;
  free(data);
  out.flush();
}

static double lastStatTime = 0.0;
static double firstStatTime = -1.0;

double displayInterval = 10.0;
 

#ifndef NO_STAT
extern int statMPRSelection; // XXX
extern int statRouteCalculation;
extern double statMPRSelectionTime;
extern double statRouteCalculationTime;
extern double statRouteCalculationFullTime;

static void displayStat()
{
  cout << "--" << (getTimeOfDay()-firstStatTime) << " #evt="
       << statEventCounter 
       << " #routeComp=" << statRouteCalculation << " #MPRSel="
       << statMPRSelection<< " ("
       << statRouteCalculationTime << "+" << statMPRSelectionTime 
       <<":"<< (statRouteCalculationFullTime+statMPRSelectionTime)    
       <<")"<< ")\n  ";
  outputStat(cout);
}
#endif

static void pollDisplayStat()
{
#ifndef NO_STAT
  if (displayInterval > 0) {
    double currentTime = getTimeOfDay();
    if (currentTime - lastStatTime > displayInterval) {
      if (firstStatTime < 0)
	firstStatTime = currentTime;

      displayStat();

      eventCounterCheck = statEventCounter
	+ (statEventCounter-lastEventCounter)/100+2;
      lastEventCounter = statEventCounter;
      lastStatTime = currentTime;
    }
  }
#endif
}

//---------------------------------------------------------------------------

class SimulationEvent : public IEvent
{
public:
  SimulationEvent(PPA_CallbackFunction aFunction,
		  void* aData1, void* aData2, void* aData3)
    : function(aFunction), data1(aData1), data2(aData2), data3(aData3)
  {}

  virtual void handleEvent(void* data)
  { function(data1, data2, data3); }

protected:
  PPA_CallbackFunction function;
  void* data1; void* data2; void* data3;
};

bool pollShowStat = true;

void internalScheduleFunction(double relativeTime,
			      PPA_CallbackFunction function,
			      void* data1, void* data2, void* data3)
{
  // - Statistics
  if (pollShowStat) {
    statEventCounter++;
    if (statEventCounter >= eventCounterCheck)
      pollDisplayStat();
  }
  // ---

  scheduler->addEvent(relativeTime, 
		      new SimulationEvent(function, data1, data2, data3),
		      NULL);
}

double getCurrentTime()
{ return scheduler->getTime(); }

//---------------------------------------------------------------------------

void sendDecapsulatedMulticastPacket(PPA_PlugeeNode plugeeNode,
				     PPA_Address originatorAddress,
				     PPA_Address destinationAddress,
				     PPA_Address receiverAddress,
				     PPA_Packet packet /*own*/);

//---------------------------------------------------------------------------

void* plugeeOpaqueFunctionCall
(char* cFunctionName,
 int argCount, void** argData, int* argSize,
 int* resultCount, void*** resultData, int** resultSize)
{
  string name = cFunctionName;
  list<string> resultList;
  if (name == "test") {
    resultList.push_back("simulator result value 1");
    resultList.push_back("plugee result value 2");
    return opaqueMakeResult(resultList, resultCount, resultData, resultSize);

  } else if (name == "getInternalNodeMemoryAddress") {
    if (argCount != 1) 
      return errorBadNbArg("Simulator ", 1, argCount);
    int nodeIndex = atoi((char*)argData[1]);
    if (!validNodeIndex(nodeIndex))
      return strdup("Opaque function call: invalid node index");
    InternalNode* internalNode = nodeArray[nodeIndex];
    string info((char*)&internalNode, sizeof(internalNode));
    resultList.push_back(info);
    return opaqueMakeResult(resultList, resultCount, resultData, resultSize);

  } else if (name == "getNodeMemoryAddress") {
    if (argCount != 1) 
      return errorBadNbArg("Simulator ", 1, argCount);
    int nodeIndex = atoi((char*)argData[0]);
    if (!validNodeIndex(nodeIndex))
      return strdup("Opaque function call: invalid node index");
    void* node = nodeArray[nodeIndex]->pluginNode;
    string info((char*)&node, sizeof(node));
    resultList.push_back(info);
    return opaqueMakeResult(resultList, resultCount, resultData, resultSize);
  } else if (name == "setSeed") {
    if (argCount != 1)
      return errorBadNbArg("Simulator", 1, argCount); //XXX: check size
#ifdef NEWRAND
    init_genrand( atoi((char*)argData[0]) );
#else
    srand48( atoi((char*)argData[0]) );
    srandom( atoi((char*)argData[0]) );
#endif
    return opaqueMakeResult(resultList, resultCount, resultData, resultSize);
  } else if (name == "setTransmissionDelay") {
    if (argCount != 1)
      return errorBadNbArg("Simulator", 1, argCount); //XXX: check size
    transmissionDelay = atof((char*)argData[0]);
    return opaqueMakeResult(resultList, resultCount, resultData, resultSize);
  }
#if 0
  std::cerr << name << " = " << cFunctionName << " "
	    << strlen(cFunctionName) << " "
	    << strcmp(cFunctionName, "getNodeMemoryAddress") << " ";
  std::cerr << (name == "getNodeMemoryAddress") << std::endl;
#endif
  resultCount = 0;
  *resultData = NULL;
  *resultSize = NULL;
  string errorMsg = "Unknown simulator opaque function name '" + name + "'";
  return strdup(errorMsg.c_str());
}

//---------------------------------------------------------------------------

extern "C" void* doPluginOpaqueFunctionCall
(char* cFunctionName,
 int argCount, void** argData, int* argSize,
 int* resultCount, void*** resultData, int** resultSize)
{
  if (pluginOpaqueFunction == NULL)
    Fatal("plugin didn't provide opaque function calls");
  return (*pluginOpaqueFunction)(cFunctionName, argCount, argData, argSize,
				 resultCount, resultData, resultSize);
}

extern "C" void* doSimulatorOpaqueFunctionCall
(char* cFunctionName,
 int argCount, void** argData, int* argSize,
 int* resultCount, void*** resultData, int** resultSize)
{
  return plugeeOpaqueFunctionCall(cFunctionName, argCount, argData, argSize,
				  resultCount, resultData, resultSize);
}

//---------------------------------------------------------------------------

static int getExtension(PPA_ExtensionInfo* info, void* data)
{
  string name = info->name;
  if (name == "OpaqueFunctionCall") {
    if (info->majorVersion != STD_OPAQUE_EXTENSION_VERSION_MAJOR)
      return PPA_FAILURE;
    PPA_OpaqueFunctionCall* opaqueFunction = (PPA_OpaqueFunctionCall*)data;
    *opaqueFunction = &plugeeOpaqueFunctionCall;
    return PPA_OK;
  }
  return PPA_FAILURE;
}

//---------------------------------------------------------------------------

extern "C" 
void initSimulation(char* pluginFileName, int aMaxNodeIndex)
{
  maxNodeIndex = aMaxNodeIndex;

  scheduler = new SimulationScheduler;
  PPA_PlugeeApi* simulatorApi = &myApi;
  memset(&myApi, 0, sizeof(myApi));
  simulatorApi->sendPacketFunction          = sendPacket;
  simulatorApi->configureRouteFunction      = configureRoute;
  simulatorApi->scheduleAtFunction          = internalScheduleFunction;
  simulatorApi->getBroadcastAddressFunction = getBroadcastAddress;
  simulatorApi->getCurrentTimeFunction      = getCurrentTime;
  simulatorApi->addressSize                 = sizeof(InternalAddress);
  simulatorApi->sendDecapsulatedMulticastPacketFunction 
    = sendDecapsulatedMulticastPacket;
  simulatorApi->getExtensionFunction = getExtension;

  loadPlugin(pluginFileName, simulatorApi, &pluginApi);
 
#ifdef NU_AUTOCONF
  PPA_ExtensionInfo extensionInfo;
  memset(&extensionInfo, 0, sizeof(extensionInfo));
  extensionInfo.name = "NiigataUniversityAutoConfiguration";
  extensionInfo.majorVersion = NU_AUTOCONF_EXTENSION_VERSION_MAJOR;
  extensionInfo.minorVersion = NU_AUTOCONF_EXTENSION_VERSION_MINOR;
  nuAutoConfApi = NULL;
  if (pluginApi->pluginGetExtension == NULL)
    Fatal("plugin doesn't implement an getExtension function");
  if (pluginApi->pluginGetExtension
      (&extensionInfo, &nuAutoConfApi) == PPA_FAILURE)
    Fatal("plugin doesn't implement Niigata University autoconf");
  assert(nuAutoConfApi != NULL);
#endif /* NU_AUTOCONF */

  if (pluginApi->pluginGetExtension != NULL) {
    PPA_ExtensionInfo opaqueExtensionInfo;
    memset(&opaqueExtensionInfo, 0, sizeof(opaqueExtensionInfo));
    opaqueExtensionInfo.name = "OpaqueFunctionCall";
    opaqueExtensionInfo.majorVersion = STD_OPAQUE_EXTENSION_VERSION_MAJOR;
    opaqueExtensionInfo.minorVersion = STD_OPAQUE_EXTENSION_VERSION_MINOR;
    if (pluginApi->pluginGetExtension
	(&opaqueExtensionInfo, &pluginOpaqueFunction) == PPA_FAILURE) {
      Warn("Couldn't load opaque function call from the plugin");
      pluginOpaqueFunction = NULL;
    }
  }
  
  nodeArray = new InternalNode* [maxNodeIndex];

  for(int i=0;i < maxNodeIndex;i++) {
    nodeArray[i] = NULL;
  }
} 

extern "C"
void addNode(int nodeIndex, int nbIface, int mtu,
	     void* configData, int configSize)
{
  assert( inrange(0, nodeIndex, maxNodeIndex) );
  InternalNode* node = new InternalNode(nodeIndex, nbIface, mtu);
  nodeArray[nodeIndex] = node;
  node->pluginNode = pluginApi->createNodeFunction(node,
	node->nbIface, node->interfaceAddressArray, node->interfaceMTUArray,
						   configData, configSize);
}

extern "C" 
void addNodeLink(int srcNodeIdx, int srcIfaceIdx, 
		 int dstNodeIdx, int dstIfaceIdx)
{ nodeArray[srcNodeIdx]->addLink(srcIfaceIdx, dstNodeIdx, dstIfaceIdx); }

extern "C" 
void addDynamicLink(int srcNodeIdx, int srcIfaceIdx, 
		    GetLinkFunction getLinkFunction, void* data)
{ nodeArray[srcNodeIdx]->addDynamicLink(srcIfaceIdx, getLinkFunction, data); }

extern "C" 
void removeDynamicLink(int srcNodeIdx, int srcIfaceIdx)
{ nodeArray[srcNodeIdx]->removeDynamicLink(srcIfaceIdx); }

extern "C" 
void removeNodeLink(int srcNodeIdx, int srcIfaceIdx, 
		 int dstNodeIdx, int dstIfaceIdx)
{ nodeArray[srcNodeIdx]->removeLink(srcIfaceIdx, dstNodeIdx, dstIfaceIdx); }

extern "C" 
void runUntil(double maxTime)
{
  for(int i=0;i<maxNodeIndex;i++)
    if (nodeArray[i] != NULL)
      pluginApi->nodeStartFunction(nodeArray[i]->pluginNode);

  scheduler->runUntil(maxTime);
}

extern "C"
void writeState(char* fileName, char* info)
{
  {
    ofstream out(fileName, 
#ifdef NEW			    
			    std::ios_base::app | std::ios_base::out);
#else
     			    std::ios::app | std::ios::out);
#endif
    out << "[begin-check-point]" << endl;
    out << info;
    out << "[graph]";
    for(int i=0;i<maxNodeIndex;i++)
      if (nodeArray[i] != NULL)
	nodeArray[i]->writeLink(out);
    out << endl;
    out.close();
  }
  for(int i=0;i<maxNodeIndex;i++)
    if (nodeArray[i] != NULL)
      pluginApi->nodeOutputFunction(nodeArray[i]->pluginNode, fileName);
  {
    ofstream out(fileName, 
#ifdef NEW			    
			    std::ios_base::app | std::ios_base::out);
#else
     			    std::ios::app | std::ios::out);
#endif
    out << "[end-check-point]" << endl;
    out.close();
  }
}

extern "C"
void scheduleFunctionAt(double relativeTime, 
      void(*f)(void*, void*, void*), void*d)
{
  internalScheduleFunction(relativeTime, f, d, NULL, NULL);
}

#if 0
extern "C"
void setNodeConfig(int nodeIndex, char* configString)
{
  /*scheduleAt(relativeTime, f, d, NULL, NULL);*/
  pluginApi->nodeSetConfigFunction(nodeArray[nodeIndex]->pluginNode,
				   configString, strlen(configString));
}
#endif

//---------------------------------------------------------------------------

#ifdef MULTICAST_RESEARCH

extern "C"
void multicastJoinGroup(int nodeIndex, int groupIndex)
{ 
  assert( inrange(0, nodeIndex, maxNodeIndex) );
  nodeArray[nodeIndex]->multicastJoinGroup(groupIndex); 
}

extern "C"
void multicastLeaveGroup(int nodeIndex, int groupIndex)
{ 
  assert( inrange(0, nodeIndex, maxNodeIndex) );
  nodeArray[nodeIndex]->multicastLeaveGroup(groupIndex); 
}

extern "C"
void multicastSenderJoin(int nodeIndex, int groupIndex)
{ 
  assert( inrange(0, nodeIndex, maxNodeIndex) );
  nodeArray[nodeIndex]->multicastSenderJoin(groupIndex); 
}

extern "C"
void multicastSenderLeave(int nodeIndex, int groupIndex)
{ 
  assert( inrange(0, nodeIndex, maxNodeIndex) );
  nodeArray[nodeIndex]->multicastSenderLeave(groupIndex); 
}

#else

extern "C"
void multicastJoinGroup(int nodeIndex, int groupIndex)
{ }

extern "C"
void multicastLeaveGroup(int nodeIndex, int groupIndex)
{ }

extern "C"
void multicastSenderJoin(int nodeIndex, int groupIndex)
{ }

extern "C"
void multicastSenderLeave(int nodeIndex, int groupIndex)
{ }

#endif /*MULTICAST_RESEARCH*/

//---------------------------------------------------------------------------

extern "C" 
double getSimulationTime()
{ return getCurrentTime(); }

//---------------------------------------------------------------------------


static World* world = NULL;
static int worldNbNode = -1;
static int worldNbIface = -1;

extern "C"
void initWorld(int nbNode, int nbIface, double areaWidth, double areaHeight,
	       double minRange, double maxRange, double maxSpeed)
{
  assert( world == NULL );
  worldNbNode = nbNode;
  worldNbIface = nbIface;
  world = new World(nbNode*nbIface, areaWidth, areaHeight,
		    minRange, maxRange, maxSpeed);
}

//---------------------------------------------------------------------------

int idxToIfaceIdx(int idx, int nbNode) { return idx/nbNode; }
int idxToNodeIdx(int idx, int nbNode) { return idx%nbNode; }
int nodeIfaceToIdx(int nodeIdx, int ifaceIdx, int nbNode)
{ return nodeIdx+ifaceIdx*nbNode; }

void getDynamicLink(void* data,
		    int srcNodeIdx, int srcIfaceIdx,
		    int* resultCount,
		    int** nodeIdxList, 
		    int** ifaceIdxList)
{
  std::list<int> infoList;
  world->getReceiverList(nodeIfaceToIdx(srcNodeIdx, srcIfaceIdx, worldNbNode),
			 getSimulationTime(), infoList);
  *resultCount = infoList.size();
  *nodeIdxList = (int*) malloc( *resultCount * sizeof(int) );
  *ifaceIdxList = (int*) malloc( *resultCount * sizeof(int) );
  int current = 0;
  for(std::list<int>::iterator it = infoList.begin(); 
      it != infoList.end(); it++) {
    (*nodeIdxList)[current] = idxToNodeIdx(*it, worldNbNode);
    (*ifaceIdxList)[current] = idxToIfaceIdx(*it, worldNbNode);
    current ++;
  }
}

//---------------------------------------------------------------------------

extern "C"
void worldCreateRadioLink()
{
  assert( world != NULL );
  for(int i=0; i<worldNbNode; i++) {
    for (int j=0; j<worldNbIface; j++) {
      world->create(nodeIfaceToIdx(i, j, worldNbNode));
      addDynamicLink(i, j, getDynamicLink, NULL);
    }
  }
}

//---------------------------------------------------------------------------

extern "C" 
void* getInternalNode(int nodeIndex)
{
   assert( world != NULL );
   assert( inrange(0, nodeIndex, worldNbNode) );
   return nodeArray[nodeIndex];
}

extern "C" 
void* getInternalWorldNode(int nodeIndex)
{
   assert( world != NULL );
   return (void*)world->getNode(nodeIndex);
}

extern "C"
WorldNodeInfo* getWorldNodeInfo(int nodeIndex)
{
   assert( world != NULL );
   return world->getNode(nodeIndex);
}

extern "C"
void sendMulticastPacket(int senderNodeIndex, int senderIfaceIndex,
			 int dstGroupIndex, void* packetData, int packetSize)
{
  int ifaceIdx = senderIfaceIndex;
  PPA_Packet packet;
  packet.data = malloc(packetSize);
  memcpy(packet.data, packetData, packetSize);
  packet.size = packetSize;

  assert( validNodeIndex(senderNodeIndex, ifaceIdx) );
  InternalNode* node = nodeArray[senderNodeIndex]; 

  PPA_Address multicastAddress = NULL;
  makeAddress(multicastNodeIdx, dstGroupIndex, multicastAddress);
  // XXX: the source address is not given
  pluginApi->nodeMulticastEncapsulateFunction(node->pluginNode,
					      multicastAddress,
					      packet);
  free(multicastAddress);
}

MulticastRecvPacketFunction recvMulticastCallBack = NULL;

extern "C"
void setRecvMulticastPacketFunction(MulticastRecvPacketFunction func)
{
  recvMulticastCallBack = func;
}

//---------------------------------------------------------------------------

void sendDecapsulatedMulticastPacket(PPA_PlugeeNode plugeeNode,
				     PPA_Address originatorAddress,
				     PPA_Address destinationAddress,
				     PPA_Address receiverAddress,
				     PPA_Packet packet /*own*/)
{
#if 0
  const double transmissionDelay = 0.0;
#endif

  unsigned int originatorNodeIndex = addressToNodeIdx(originatorAddress);
  unsigned int originatorIfaceIndex = addressToIfaceIdx(originatorAddress);
  assert( validNodeIndex(originatorNodeIndex, originatorIfaceIndex) );

  unsigned int nodeIndex = addressToNodeIdx(receiverAddress);
  unsigned int ifaceIndex = addressToIfaceIdx(receiverAddress);
  assert( validNodeIndex(nodeIndex, ifaceIndex) );
  InternalNode* node = nodeArray[nodeIndex]; 
  assert( ((PPA_PlugeeNode)node) == plugeeNode );
  // check that dst address is broadcast address:

  if (recvMulticastCallBack != NULL) {
    unsigned int dstNodeIndex = addressToNodeIdx(destinationAddress);
    assert( dstNodeIndex == (unsigned int)multicastNodeIdx );
    unsigned int groupIndex = addressToIfaceIdx(destinationAddress);
    recvMulticastCallBack(originatorNodeIndex, originatorIfaceIndex,
			  nodeIndex, ifaceIndex, groupIndex,
			  packet.data, packet.size);
    free(packet.data);
  }

#if 0
  assert( sizeof(void*) >= sizeof(unsigned int) );
  scheduler->addEvent(transmissionDelay, 
		      new PacketEvent(nodeIndex, ifaceIndex, srcAddress,
				      packet), NULL);
#endif
}

//---------------------------------------------------------------------------
