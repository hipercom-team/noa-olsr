//-----------------------------------------------------------------*- c++ -*-
//                             OOLSR
//               Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include "exec_manager.h"
#include "general.h"

//---------------------------------------------------------------------------


//---

typedef enum {
  IP4, IP6
} IPVersion;

class SystemCommandManager
{
public:
  SystemCommandManager(string aIpRoutePath) 
    : ipRoutePath(aIpRoutePath)
  { }

  SystemCommandManager() 
    : ipRoutePath("/iproute/path/should/have/been/initialized") { }

  int runCommand(list<string> commandArg, string& output, string& error)
  {
    CommandManager command(commandArg);
    command.start();
    command.endPushIn();
    command.waitIOCompletion();
    if (command.hasTerminated()) {
      // Ok
      output = command.popOutData();
      error = command.popErrData();
      return command.getStatus();
    } else return -1;
  }

  bool getIfaceAddressList(string deviceName, 
			   list<string>& ipv4Address,
			   list<string>& ipv6Address,
			   string& errorString)
  {
    list<string> commandArg;
    string strOut;
    commandArg << ipRoutePath << "addr" << "show" << "dev" << deviceName;
    if (runCommand(commandArg, strOut, errorString) == 0) {
      vector<string> lineList = stringSplit(strOut, "\n");
      for (unsigned int i=1; i<lineList.size();i++) {
	string line = stringStrip(lineList[i], " \t");
	vector<string> tokenList = stringSplit(line, " ");
	if (tokenList.size() >= 2) {
	  if (tokenList[0] == "inet")
	    ipv4Address.push_back(tokenList[1]);
	  else if (tokenList[0] == "inet6")
	    ipv6Address.push_back(tokenList[1]);
	}
      }
      return true;
    } else return false;
  }

  bool getIfaceIndex(string deviceName, int& resultIfaceIndex, 
		     string& errorString)
  {
    list<string> commandArg;
    string strOut;
    commandArg << ipRoutePath << "link" << "show" << "dev" << deviceName;
    if (runCommand(commandArg, strOut, errorString) == 0) {
      vector<string> lineList = stringSplit(strOut, ":");
      if (lineList.size() == 0 || !strToInt(lineList[0], resultIfaceIndex) ) {
	errorString = Repr("Unable to parse <ip link show dev " << deviceName
			   << "> output: " << errorString);
	return false;
      }
      return true;
    } else return false;
  }
  
  bool delIfaceAddress(string deviceName,
		       string ipStrAddress,
		       string& errorString)
  {
    list<string> commandArg;
    string strOut;
    commandArg << ipRoutePath << "addr" << "del" << ipStrAddress
	       << "dev" << deviceName;
    if (runCommand(commandArg, strOut, errorString)==0) 
      return true;
    else return false;
  }

  bool addIfaceAddress(string deviceName,
		       string ipStrAddress,
		       string& errorString)
  { // XXX: similar to delIfaceAddress
    list<string> commandArg;
    string strOut;
    commandArg << ipRoutePath << "addr" << "add" << ipStrAddress
	       << "dev" << deviceName;
    if (runCommand(commandArg, strOut, errorString)==0) 
      return true;
    else return false;
  }

  bool setIfaceUpOrDown(string deviceName, bool up, string& errorString)
  {
    list<string> commandArg;
    string strOut;
    commandArg << ipRoutePath << "link" << "set" << deviceName;
    if (up) commandArg << "up";
    else commandArg << "down";
    if (runCommand(commandArg, strOut, errorString)==0) 
      return true;
    else return false;    
  }

  bool setIfaceArpFlag(string deviceName, bool isOn, string& errorString)
  {
    list<string> commandArg;
    string strOut;
    commandArg << ipRoutePath << "link" << "set" << deviceName << "arp";
    if (isOn) commandArg << "on";
    else commandArg << "off";
    if (runCommand(commandArg, strOut, errorString)==0) 
      return true;
    else return false;    
  }

  string ipRoutePath;
};

//---------------------------------------------------------------------------
