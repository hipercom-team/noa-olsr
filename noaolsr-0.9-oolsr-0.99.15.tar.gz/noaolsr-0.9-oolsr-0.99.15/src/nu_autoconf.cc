//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
// Cedric Adjih, Information Network Research Group,
// Department of Information Engineering, Niigata University.
// Copyright 2004-2005 - Niigata University
// All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include "protocol_tuple.h"
#include "packet.h"
#include "node.h"
#include "nu_autoconf.h"
#include "exec_manager.h"

//---------------------------------------------------------------------------
// XXX: this is bad bad bad, because it should be done in packet.cc, 
// but there is little choice, overwise I would have to make many 
// changes in packet.cc - another solution is to put the STATE in the header

AutoConfState peekHelloOriginatorState(Message* helloMessage)
{
  assert(helloMessage->packedContent != NULL);
  assert(helloMessage->messageType == HELLO_MESSAGE
	 || helloMessage->messageType == HELLO_MESSAGE_WITH_STATE);
  if (helloMessage->packedContent->size < 4)
    return STATE_undefined;
  return (AutoConfState)helloMessage->packedContent->data[0];
}

AutoConfState peekHelloNeighborState(Message* helloMessage)
{
  assert(helloMessage->packedContent != NULL);
  assert(helloMessage->messageType == HELLO_MESSAGE
	 || helloMessage->messageType == HELLO_MESSAGE_WITH_STATE);
  if (helloMessage->packedContent->size < 4)
    return STATE_undefined;
  return (AutoConfState)helloMessage->packedContent->data[1];
}

AutoConfState peekTCOriginatorState(Message* tcMessage)
{
  assert(tcMessage->packedContent != NULL);
  assert(tcMessage->messageType == TC_MESSAGE
	 || tcMessage->messageType == TC_MESSAGE_WITH_STATE);
  if (tcMessage->packedContent->size < 4)
    return STATE_undefined;
  return (AutoConfState)tcMessage->packedContent->data[2];
}

AutoConfState peekTCNeighborState(Message* tcMessage)
{
  assert(tcMessage->packedContent != NULL);
  assert(tcMessage->messageType == TC_MESSAGE
	 || tcMessage->messageType == TC_MESSAGE_WITH_STATE);
  if (tcMessage->packedContent->size < 4)
    return STATE_undefined;
  return (AutoConfState)tcMessage->packedContent->data[3];
}

//---------------------------------------------------------------------------

// {DAD}
StateTuple* StateSet::ensure(Address address, AutoConfState state) 
{
  StateTuple* result = findFirst_MainAddr(address);
  Time currentTime = node->getCurrentTime();
  if (result == NULL) {
    result = new StateTuple(node);
    result->S_main_addr = address;
    // result->S_time: see below
    result->S_last_hello_time = TimePastNever;
    result->S_last_tc_time = TimePastNever;
    //result->S_hello_conflict_time = TimePastNever;
    //result->S_tc_conflict_time = TimePastNever;
    result->S_conflict_time = TimePastNever;
    result->S_MPR_remember_time = TimePastNever;
    result->S_MPR_forced_time = TimePastNever;
    result->S_creation_time = currentTime;
    result->S_state = STATE_undefined;
    result->isOwn = false;
    add(result);
  }
  result->isOwn |= address == node->getMainAddress();
  ProtocolConfig* config = node->getProtocolConfig();  
  result->S_time = currentTime + config->NODE_STATE_HOLD_TIME;
  if (state != STATE_undefined && result->S_state != state) {
    node->notifyOneHopNeighborhoodChange(); // XXX: not true but ...
    // ... this will trigger MPR recalculation and route recalculation
    result->S_state = state;
  }
  return result;
}

void StateSet::write(ostream& out)
{
  Time currentTime = node->getCurrentTime();

  bool isFirst = true;
  for(StateSet::TupleIterator it = getIter(); !it.isDone(); it.next()) {
    if (!isFirst) out << ";";
    else isFirst = false;

    StateTuple* s = it.getCurrent();
    out << s->S_main_addr << " " << s->S_state;
    if (s->S_last_hello_time > TimePastNever)
      out << ",last_hello@" << (currentTime - s->S_last_hello_time) 
	  << ":" << s->S_last_hello_seq_num;
    if (s->S_last_tc_time > TimePastNever)
      out << ",last_tc@" << (currentTime - s->S_last_tc_time) 
	  << ":" << s->S_last_tc_seq_num << " ";
    if (s->S_conflict_time > currentTime)
      out << ",conflict(" << (s->S_conflict_time-currentTime) << ")";
    if (s->S_MPR_remember_time > currentTime)
      out << ",remember_mpr(" << (s->S_MPR_remember_time-currentTime) << ")";
    if (s->S_MPR_forced_time > currentTime)
      out << ",forced_mpr(" << (s->S_MPR_forced_time-currentTime) << ")";
    if (s->isFamiliar()) out << ",familiar";
    else out << ",unfamiliar";
    out << "(" << (currentTime - s->S_creation_time) << ") ";
    writeExpireTime(out, currentTime, s->S_time);
  }
}

void StateSet::notifyRemoval(StateTuple* tuple)
{ /* nothing to do */ }

void StateSet::notifyAddition(StateTuple* tuple)
{ /* nothing to do */ }

//---------------------------------------------------------------------------

// {DAD}
bool Node::autoConfCheckHelloMessage(HelloMessage* helloMessage)
{
  Message* header = helloMessage->header;  
  AutoConfState originatorState = header->messageType == HELLO_MESSAGE ? 
    STATE_NORMAL : helloMessage->originatorState;
  AutoConfState neighborState = header->messageType == HELLO_MESSAGE ?
    STATE_NORMAL : helloMessage->neighborState;

  // XXX: we should check this before any processing, but then we would
  // need to parse the message content (at least message content header).
  bool shouldInteroperate = (getProtocolConfig()->autoConfInteroperate);
  if (shouldInteroperate
      && (header->messageType == HELLO_MESSAGE_WITH_STATE) 
      && (originatorState == STATE_NORMAL) && (neighborState == STATE_NORMAL))
    return false;
  else if (!shouldInteroperate
	   && (header->messageType == HELLO_MESSAGE))
    return false;

  StateTuple* stateTuple = stateSet.ensure(header->originatorAddress,
					   originatorState);
  Time lastSeenInterval = getCurrentTime() - stateTuple->S_last_hello_time;
  int headerSeqNum = header->messageSequenceNumber;
  
  if (lastSeenInterval < protocolConfig->DUP_HOLD_TIME) {
    // perform the check of R2
    int lastSeqNum = stateTuple->S_last_hello_seq_num;
    if (headerSeqNum == lastSeqNum 
	|| seqNumGreater(lastSeqNum, headerSeqNum)) {
      // Duplicate detected
      D(*log, lAutoConf, getRealTime() << " [autoconf-conflict] " << getId()
	<< " <R2> detected hello_orig=" << header->originatorAddress
	<< " hello_time=" << stateTuple->S_last_hello_time 
	<< " last_seq_num=" << lastSeqNum << " seq_num=" << headerSeqNum
	<< endl);
      stateTuple->S_conflict_time = getCurrentTime()
	+ protocolConfig->CONFLICT_HOLD_TIME;
#ifdef WITH_AUTOCONF_PRIORITY
      stateTuple->S_conflict_state = ;
#endif
       
    }
  }

  int selfAddressCount = 0;
  for (list<LinkEntry>::iterator it = helloMessage->linkList.begin();
       it != helloMessage->linkList.end(); it++) {
    (void) stateSet.ensure((*it).address, neighborState); // refresh the node
    if ((*it).address == getMainAddress())
      selfAddressCount++;
    else if ((*it).neighborType == SYM_NEIGH  
	     || (*it).neighborType == MPR_NEIGH) {
      NeighborTuple* neighborTuple 
	= neighborSet.findFirst_MainAddr((*it).address);
      if (neighborTuple != NULL && neighborTuple->N_status == SYM) {
	// This is a symetrical neighbor of the HELLO originator and ourself
	// check there is a two hop tuple...
	TwoHopNeighborTuple* twoHop 
	  = twoHopNeighborSet.findFirst_1hopAddr_2hopAddr
	  ((*it).address, header->originatorAddress); // @@2101-2102
	if (twoHop == NULL) {
	  // the two hop neighbor
	  D(*log, lAutoConf, getRealTime() << " [autoconf-conflict] " 
	    << getId() << " <R@12> detected hello_orig=" 
	    << header->originatorAddress << " two_hop=" << (*it).address
	    << endl);
	  stateTuple->S_MPR_forced_time = getCurrentTime()
	    + protocolConfig->CONFLICT_HOLD_TIME;
	}
      }
    }
  }
  if (selfAddressCount >= 2) {
    // Duplicate signaling from neighbor node
    D(*log, lAutoConf, getRealTime() << " [autoconf-conflict] " 
      << getId() << " <R3> detected hello_orig="
      << header->originatorAddress << endl);
    chooseNewAddress(getMainAddress());
    return false;
  }

  stateTuple->S_last_hello_time = getCurrentTime();
  stateTuple->S_last_hello_seq_num = header->messageSequenceNumber;
  return true;
}

// {DAD}
void Node::autoConfPreCheckHelloMessage(Message* message,
					string messageHash,
					DuplicateTuple* duplicateTuple,
					bool& resultShouldSkipPacket,
					bool& resultShouldSkipMessage)
{
  // Check D1
  if (message->originatorAddress == getMainAddress()) {
    // This one of our packets
    bool isError = true;
    if (protocolConfig->autoConfHashHello) {
      if (duplicateTuple == NULL || messageHash != duplicateTuple->D_hash) 
	isError = true;
      else isError = false;
    }

    if (isError) {
      D(*log, lAutoConf, getRealTime() << " [autoconf-conflict] " 
	<< getId() << " <R1> detected has_dup=" <<
	(duplicateTuple != NULL) << endl);
      chooseNewAddress(getMainAddress());
      resultShouldSkipPacket = true;
      return;
    }
  }
}

void Node::autoConfPreCheckTCMessage(Message* message,
				     string messageHash,
				     DuplicateTuple* duplicateTuple,
				     bool& resultShouldSkipPacket,
				     bool& resultShouldSkipMessage)
{
  //D(*log, lPacketProcessing, getRealTime() << " [autoconf-info] "
  //  << getId() << " pre-check-message  tc=" << (*message) << endl);

  if (_getAutoConfState() == STATE_HELLO) {
    resultShouldSkipMessage = true;
    return;
  }

#if 0
  TCMessage* tcMessage = dynamic_cast<TCMessage*>(message->content);
    // (some other processing is done in _autoConfCheckTCMessage())
  AutoConfState originatorState = message->messageType == TC_MESSAGE
    ? STATE_NORMAL : tcMessage->originatorState;
#endif
  
  //----- Check for a TC with our address as originator
  if (message->originatorAddress == getMainAddress()) {
    // This one of our packets
    if (duplicateTuple == NULL) {
      // Conflict (R4.1) is detected
      D(*log, lAutoConf, getRealTime() << " [autoconf-conflict] "
	<< getId() << " <R4.1> detected "
	<< " tc=" << (*message) << endl);
      chooseNewAddress(getMainAddress());
      resultShouldSkipPacket = true;

    } else if (messageHash != duplicateTuple->D_hash) {      
      // This node is in conflict with another... (R4.2)
      D(*log, lAutoConf, getRealTime() << " [autoconf-conflict] " << getId()
	<< " <R4.2> detected duplicate="
	<< (*duplicateTuple) << " tc_hash=" << asHex(messageHash)
	<< " tc=" << (*message) << endl);
      chooseNewAddress(getMainAddress());
      resultShouldSkipPacket = true;
    }
    resultShouldSkipMessage = true;
    return;
  }

  //----- Check for a TC from another node as originator
  //bool isInConflict = false;
  bool shouldRetransmit = false;
  if (duplicateTuple == NULL) {

    StateTuple* stateTuple = stateSet.ensure(message->originatorAddress,
		peekTCOriginatorState(message));
    if (stateTuple->S_last_tc_time == TimePastNever) {
      stateTuple->S_last_tc_time = getCurrentTime();
      stateTuple->S_last_tc_seq_num = message->messageSequenceNumber;
      return; // unknown originator, unknown TC: no problem possible
    }
    Time timeDifference = getCurrentTime() - stateTuple->S_last_tc_time;
    //if (timeDifference < protocolConfig->DUP_HOLD_TIME) {
    int sequenceNumberDifference = (int)stateTuple->S_last_tc_seq_num
      - (int)message->messageSequenceNumber;
    // this is not true: 
    //    assert( sequenceNumberDifference != 0 );
    // in some weird scenarios this can happen
    if (sequenceNumberDifference == 0)
      return; // dunno so: relies on other detection methods to catch the issue
    if (sequenceNumberDifference < 0)
      sequenceNumberDifference = - sequenceNumberDifference;
    Time tcRate = sequenceNumberDifference / timeDifference;

    if (sequenceNumberDifference > protocolConfig->MAX_TC_DIFF_SEQ_NUM
	&& tcRate > protocolConfig->MAX_MESSAGE_RATE) { 
      D(*log, lAutoConf, getRealTime() << " [autoconf-conflict] " << getId() 
	<< " <R5.1> detected tc_orig=" << message->originatorAddress
	<< " tc_seq_num=" << message->messageSequenceNumber
	<< " last_tc_seq_num=" << stateTuple->S_last_tc_seq_num
	<< " last_tc_rel_time=" << timeDifference << endl);

      //isInConflict = true; // XXX 
      resultShouldSkipMessage = true;
      // also the message will be normally rebroadcasted as there is
      // no duplicate tuple:
      // -- correction: NO, it was not, because it was skipped, so
      // we have to retransmit it:
      shouldRetransmit = true;
    }
    stateTuple->S_last_tc_time = getCurrentTime();
    stateTuple->S_last_tc_seq_num = message->messageSequenceNumber;

  } else if (messageHash != duplicateTuple->D_hash) {

    // Conflict detected between two other nodes (for the first time
    // for this message)
    // must retransmit it
    D(*log, lAutoConf, getRealTime() << " [autoconf-conflict] " << getId() 
      << " <R5.2> detected duplicate=" << (*duplicateTuple) 
      << " tc_hash=" << asHex(messageHash) << " tc=" << (*message) <<endl);
    
    //isInConflict = true; // XXX
    resultShouldSkipMessage = true;
    shouldRetransmit = true;
  }

#if 0   
  if (isInConflict) { // XXX!!: this is no longer used
    // set the conflict state
    StateTuple* stateTuple =
      stateSet.ensure(message->originatorAddress);
    stateTuple->S_conflict_time = getCurrentTime()
      + protocolConfig->CONFLICT_HOLD_TIME;

    // remove all the topology tuples from the originator
    TopologySet::TupleIterator it=topologySet.getIter();
    while (!it.isDone()) {
      TopologyTuple* topologyTuple = it.getCurrent();
      if (topologyTuple->T_last_addr == message->originatorAddress) {
	it.removeAndDeleteCurrentAndDoNext();
	// shouldRecomputeRoute is set in 'notifyRemoval':
	assert( shouldRecomputeRoute );
      } else it.next();
    }
  }
#endif
  if (shouldRetransmit) {
    // perform 'manual' retransmission of the message:
    addDuplicateTupleRetransmitted(message, message->packedContent);
    //XXX: PktD(*log, info, m, ",retransmit");
    Message* newMessage = message->clone();
    newMessage->timeToLive --; // @@1059
    newMessage->hopCount ++; // @@1061
    packetManager->sendPackedMessageToAll(newMessage); // @@1071-1073
    resultShouldSkipMessage = true;
  }
}

// {DAD}
void Node::autoConfPreCheckMessage(Message* message,
				   bool& resultShouldSkipPacket,
				   bool& resultShouldSkipMessage)
{
  resultShouldSkipPacket = false;
  resultShouldSkipMessage = false;

  // Find the closest hash
  assert( message->packedContent != NULL );
  string messageHash = getMessageHash(message->packedContent);
  // try to find a duplicate tuple with the same hash:
  DuplicateTuple* duplicateTuple = duplicateSet.findFirst
    (message->originatorAddress, message->messageSequenceNumber, messageHash);

  if (message->messageType == HELLO_MESSAGE
      || message->messageType == HELLO_MESSAGE_WITH_STATE)
    autoConfPreCheckHelloMessage(message, messageHash, duplicateTuple,
				 resultShouldSkipPacket, 
				 resultShouldSkipMessage);
  else if (message->messageType == TC_MESSAGE
	   || message->messageType == TC_MESSAGE_WITH_STATE)
    autoConfPreCheckTCMessage(message, messageHash, duplicateTuple,
			      resultShouldSkipPacket, resultShouldSkipMessage);
}

// {DAD}
void Node::autoConfPostCheckMessage(Message* message)
{
  if (message->messageType == TC_MESSAGE
      || message->messageType == TC_MESSAGE_WITH_STATE) {
    DuplicateTuple* duplicateTuple 
      = duplicateSet.findFirst_Address_MessageSequenceNumber
      (message->originatorAddress, message->messageSequenceNumber);
    if (duplicateTuple != NULL && duplicateTuple->D_hash.length() == 0) {
      // Update the hash value
      assert( message->packedContent != NULL );
      string messageHash = getMessageHash(message->packedContent);
      duplicateTuple->D_hash = messageHash;
    }
  }
}

//#define ForIt(type, name, variable)					
//  for (type::iterator it = variable.begin(); it != variable.end(); it++)
// {DAD}
bool Node::autoConfCheckTCMessage(TCMessage* tcMessage)
{
  assert( _getAutoConfState() != STATE_HELLO );
  Message* header = tcMessage->header;
  AutoConfState originatorState = header->messageType == TC_MESSAGE ?
    STATE_NORMAL : tcMessage->originatorState;
  AutoConfState neighborState = header->messageType == TC_MESSAGE ?
    STATE_NORMAL : tcMessage->neighborState;

  // XXX: we should check this before any processing, but then we would
  // need to parse the message content (at least message content header).
  bool shouldInteroperate = (getProtocolConfig()->autoConfInteroperate);
  if (shouldInteroperate
      && (header->messageType == TC_MESSAGE_WITH_STATE) 
      && (originatorState == STATE_NORMAL) && (neighborState == STATE_NORMAL))
    return false;
  else if (!shouldInteroperate
	   && (header->messageType == TC_MESSAGE))
    return false;

  StateTuple* stateTuple = stateSet.ensure(header->originatorAddress,
					   originatorState);

  // XXX:AUTOCONF
  // XXX:AUTOCONF: check when data is deleted from the TC,
  // this doesn't affect forwarding...
#if 0
  if (stateTuple->isInConflict())
    // The originator is in conflict. We ignore the TC.
    return /*ok=*/ false;    
#endif

  int countUnfamiliarNode = 0;
  int countFamiliarNode = 0;
  bool includeThisNode = false;
  list<Address>::iterator it = tcMessage->addressList.begin();
  while(it != tcMessage->addressList.end()) {
    list<Address>::iterator nextIt = it;
    nextIt++;
    StateTuple* otherStateTuple = stateSet.ensure(*it, neighborState);
    if (*it == getMainAddress())
      includeThisNode = true;
    if (otherStateTuple->isFamiliar())
      countFamiliarNode++;
    else countUnfamiliarNode++;
    bool wasErased = false;

    // Rule R11
    if (protocolConfig->autoConfContaminationAvoidance
	&& protocolConfig->autoConfUseR10R11) {
      if (nextIt != tcMessage->addressList.end() && *nextIt == *it) {
	D(*log, lAutoConf, getRealTime() << " [autoconf-conflict] " << getId()
	  << " <R@11> detected tc_orig=" << header->originatorAddress 
	  << " unfamiliar=" << (*it) << endl);
	list<Address>::iterator oldNextIt = nextIt;
	nextIt++;
	tcMessage->addressList.erase(it);
	it = oldNextIt;
	tcMessage->addressList.erase(it);
	wasErased = true;
      }
    }

    if (protocolConfig->autoConfContaminationAvoidance && !wasErased
	&& !stateTuple->isFamiliar() && otherStateTuple->isFamiliar() // {DAD}
	&& !(otherStateTuple->S_main_addr == getMainAddress())) {
      // Implement D8 by removing this familiar node, if it has not been
      // already seen in any TC
      if (topologySet.findFirst_LastAddr(*it) != NULL
	  || topologySet.findFirst_DestAddr(*it) != NULL) {
	D(*log, lAutoConf, getRealTime() << " [autoconf-conflict] " << getId()
	  << " <R7> detected tc_orig=" << header->originatorAddress 
	  << " seq_num=" << header->messageSequenceNumber 
	  << " familiar=" << (*it) << endl);
	tcMessage->addressList.erase(it);
	wasErased = true;
      }
    }

    // Now check rule R8: // {DAD}
    NeighborTuple* neighborTuple = neighborSet.findFirst_MainAddr(*it);
    if (!wasErased && neighborTuple != NULL 
	&& neighborTuple->N_status == SYM) {
      // This is a symetrical neighbor of this node originator and allegedly
      // a MPR selector of the TC originator
      // check there is at least a two hop tuple...
      TwoHopNeighborTuple* twoHop 
	= twoHopNeighborSet.findFirst_1hopAddr_2hopAddr
	(*it, header->originatorAddress);
      if (protocolConfig->autoConfContaminationAvoidance
	  && twoHop == NULL) {
	// no such neighbor, possible conflict
	D(*log, lAutoConf, getRealTime() << " [autoconf-conflict] " << getId()
	  << " <R8> detected tc_orig=" << header->originatorAddress 
	  << " two_hop=" << (*it) << endl);	
	tcMessage->addressList.erase(it);
	wasErased = true;
      }
    }
    it = nextIt;
  }

  // This is a neighbor which selected this node as MPR.
  if (includeThisNode // {DAD}
      && !isMPR(header->originatorAddress)
      && (stateTuple->S_MPR_remember_time < getCurrentTime())) {
    D(*log, lAutoConf, getRealTime() << " [autoconf-conflict] "
      << getId() << " <R6> detected tc_orig=" 
      << header->originatorAddress << " rel_remember_time=" 
      << stateTuple->S_MPR_remember_time << endl);
    chooseNewAddress(getMainAddress());
    return /*ok=*/ false;
  }
         
  if (protocolConfig->autoConfContaminationAvoidance
      && stateTuple->isFamiliar()) { // {DAD}
    // The node is not familiar. We check the familiarity ratio
    if (countFamiliarNode < (countFamiliarNode + countUnfamiliarNode)
	* protocolConfig->MIN_TC_FAMILIARITY_RATE) {
      D(*log, lAutoConf, getRealTime() << " [autoconf-conflict] "
	<< getId() << " <R9> detected tc_orig=" << header->originatorAddress
	<< " nb_fam=" << countFamiliarNode
	<< " nb_unfam=" << countUnfamiliarNode
	<< " tc=" << (*tcMessage) << endl);
      return /*ok=*/ false;
    }
  } 
  return /*ok=*/ true;
}

// {DAD}
void Node::autoConfNotifyPreMPRComputation()
{
  // Implement the update for later test D6.
  // save MPR_remember_time, just in case a MPR will no longer be.
  for (list<NeighborTuple*>::iterator it = mprList.begin(); 
       it != mprList.end(); it++){
    StateTuple* stateTuple = stateSet.ensure((*it)->N_neighbor_main_addr);
    stateTuple->S_MPR_remember_time = getCurrentTime()
      + protocolConfig->MAX_MPR_REMEMBER_TIME;
  }
}

// {DAD}
void Node::autoConfUpdateMPRList(list<NeighborTuple*>& newMPRList)
{
  AddressMap<bool> isMPRTable;

  // Build a table of new MPR nodes
  for (list<NeighborTuple*>::iterator it = newMPRList.begin(); 
       it !=newMPRList.end(); it++)
    isMPRTable.add((*it)->N_neighbor_main_addr, true);
  
  // Implement the action of D10
  for (StateSet::TupleIterator it = stateSet.getIter(); 
       !it.isDone(); it.next()) {
    StateTuple* stateTuple = it.getCurrent();
    if (stateTuple->S_MPR_forced_time > getCurrentTime() 
	&& !isMPRTable.get(stateTuple->S_main_addr, false)) {
      NeighborTuple* neighborTuple =
	neighborSet.findFirst_MainAddr(stateTuple->S_main_addr);
      bool possible = (neighborTuple != NULL) 
	&& (neighborTuple->N_status == SYM);

      D(*log, lAutoConf, getRealTime() << " [autoconf] " << getId() 
	<< " <R10> forcing mpr=" << stateTuple->S_main_addr << 
	" possible=" << possible << endl);
      if (possible)
	newMPRList.push_back(neighborTuple);
    }
  }
}

string Node::getMessageHash(MemoryBlock* messageContent)
{
#if 0
  // XXX:remove
  int addressSize = addressFactory->getAddressSize();
  int messageHeaderSize = MessageHeaderWithoutAddressSize + addressSize;
  assert( messageBlock->size >= messageHeaderSize );
  string content((char*)(messageBlock->data + messageHeaderSize),
		 messageBlock->size - messageHeaderSize);
#endif
  string content((char*)messageContent->data, messageContent->size);
  return getMD5(content);
}

// {DAD}
void Node::autoConfNotifyMessageQueuing(Message* message, 
					MemoryBlock* completeMessageBlock)
{
  // Detection, step R4: a duplicate tuple is created with the proper
  // hash, each time a TC is sent by this node.
  assert( completeMessageBlock != NULL );
  if (!(message->originatorAddress == getMainAddress()))
    return; // we didn't send this message
  MessageType mType = message->messageType;
  if (mType != TC_MESSAGE && mType != TC_MESSAGE_WITH_STATE) {
    if ((mType != HELLO_MESSAGE && mType != HELLO_MESSAGE_WITH_STATE)
	|| !protocolConfig->autoConfHashHello)
      return; // this isn't a TC message, or we don't hash HELLOs
  }

  assert( message->packedContent == NULL );
  int addressSize = addressFactory->getAddressSize();
  int messageHeaderSize = MessageHeaderWithoutAddressSize + addressSize;
  assert( completeMessageBlock->size >= messageHeaderSize );
  string content((char*)(completeMessageBlock->data + messageHeaderSize),
		 completeMessageBlock->size - messageHeaderSize);
  MemoryBlock messageBlock((octet*)content.data(), content.size(), 
			   /*shouldCopy:*/true);

  DuplicateTuple* duplicateTuple 
    = duplicateSet.findFirst_Address_MessageSequenceNumber
    (message->originatorAddress, message->messageSequenceNumber);
  if (duplicateTuple != NULL) {
    // We already have received a similar message, so something is wrong
    D(*log, lAutoConf, getRealTime() << " [autoconf-conflict] " << getId() 
      << " <R4.3> detected already_duplicate="
      << (*duplicateTuple) << endl);
    chooseNewAddress(getMainAddress());
    return;
  }
  addDuplicateTupleRetransmitted(message, &messageBlock);
}

void Node::addDuplicateTupleRetransmitted(Message* message,
					  MemoryBlock* messageBlock)
{
  DuplicateTuple* duplicateTuple = new DuplicateTuple;
  duplicateTuple->D_addr = message->originatorAddress; // i.e. getMainAddress()
  duplicateTuple->D_seq_num = message->messageSequenceNumber;
  duplicateTuple->D_retransmitted = true;
  duplicateTuple->D_time = getCurrentTime() + protocolConfig->DUP_HOLD_TIME;
  duplicateTuple->D_hash = getMessageHash(messageBlock);
  duplicateSet.add(duplicateTuple);
}

//---------------------------------------------------------------------------

// {DAD}
void Node::performAddressChange(Address initialAddress, Address newAddress)
{
  D(*log, lAutoConf, getRealTime() << " [autoconf-address-change] " << getId()
    << " " << initialAddress << " becomes " << newAddress << endl);

  // 
  autoConfState = STATE_HELLO;
  autoConfStateTime = getCurrentTime();

  //  forget about previous messages
  // (maybe they include our [wrong] previous address)
  packetManager->clearAllMessageQueue();

  // Set a new empty routing table (cleans the current one)
  _setRoutingTable(new RoutingTable(this));
  
  if (initialAddress == getMainAddress()) {
    ostringstream out;
    out << newAddress;
    strId = out.str() + "("+strInitialId+")";
  }

  int changeCount = 0;
  list<OLSRIface*>* ifaceList = getIfaceList();
  for (list<OLSRIface*>::iterator it = ifaceList->begin();
       it != ifaceList->end(); it++)
    if ((*it)->getAddress() == initialAddress) {
      ISystemIface* systemIface = (*it)->getSystemIface(); 
      systemIface->changeAddress(newAddress);
      changeCount++;
    }
  assert( changeCount == 1 );

  if (addressListCache != NULL) {
    delete addressListCache;
    addressListCache = NULL;
    (void)getAddressList();
  }

  for (LinkSet::Iter it = linkSet.getIter(); !it.isDone(); it.next()) {
    LinkTuple* linkTuple = it.getCurrent();
    if (linkTuple->L_local_iface_addr == initialAddress)
      linkTuple->L_local_iface_addr = newAddress;
  }

  for (MPRSelectorSet::Iter it = mprSelectorSet.getIter();
       !it.isDone(); it.removeAndDeleteCurrentAndDoNext())
    ;

#if 0
  // XXX: this is useless because we have to re-set the routing table
  // in the kernel or simulator, anyway
  for (RoutingTable::TupleIterator it = currentRoutingTable->getIter(); 
       !it.isDone(); it.next()) {
    RoutingTuple* routingTuple = it.getCurrent();
    if (routingTuple->R_iface_addr == initialAddress)
      routingTuple->R_iface_addr = newAddress;
  }
#endif  

  // XXX: should be factored
  if (protocolConfig->fastRouteCalculation)
    fasterComputeRoutingTable();
  else 
    computeRoutingTable();
}

void dumpData(ostream& out, void* data, int size)
{
  char str[4];
  for(int i=0;i<size;i++) {
    if (i!=0) sprintf(str,":%02x", ((unsigned char*)data)[i]);
    else sprintf(str,"%02x", ((unsigned char*)data)[i]);
    out << str;
  }
}

Address incrementAddress(AddressFactory* addressFactory, Address oldAddress,
			 int prefixLength)
{
  const int BitsPerByte = 8;
  int nbBit = oldAddress.getNetSize() * BitsPerByte;
  unsigned char* data = (unsigned char*)oldAddress.getRawAddress();
  unsigned char* newData = new unsigned char [oldAddress.getNetSize()];
  memcpy(newData, data, oldAddress.getNetSize());

  int index = nbBit-1;
  while (index >= prefixLength) {
    int oldBit = getBit(newData, index);
    setBit(newData, index, oldBit ^ 1);
    if (oldBit == 0) 
      break;
    index--;
  }
  if (index < prefixLength) {
    // complete wrap-around
    // XXX: test this case
    assert( getBit(newData, nbBit-1) == 0 );
    setBit(newData, nbBit-1, 1);
  }

  Address newAddress = Address(addressFactory, newData);
  delete [] newData;
  return newAddress;
}

double randomOf(string someString)
{
  string text = "OOLSR Hashing" + someString;
  string strResult = getMD5(text);
  double result = 0.0;
  for (unsigned int i=0; i<strResult.length();i++)
    result = result/256.0 + (int)(strResult.data()[i])/256.0;
  return result;
}

int randomIntOf(int maxValue, string someString)
{ return (int)(randomOf(someString)* maxValue); }

#define SetToStringOf(resultName, expr) \
  BeginMacro \
    ostringstream out; \
    out << expr; \
    resultName = out.str(); \
  EndMacro

#if 0
vector<bool> addressToVectorBool(Address address)
{
  vector<bool> result;
  unsigned char* data = (unsigned char*)address.getRawAddress();
  for (int i=0; i<address.getNetSize(); i++) {
    unsigned char value = data[i];
    for (int i=0; i<8; i++) {
      if (value&(1<<i) != 0)
	result.push_back(0);
      else result.push_back(1);
    }
  }
  return result;
}
#endif

// Choose a new address according to an algorithm
// 0: increment the address once, until it is not conflicting ; then increment
//    it once again with a probability of --auto-conf-increment-probability
// 1: in case of conflict change to an unique address (only for simulations)
// 2: choose random bits in the address
void Node::chooseNewAddress(Address oldAddress)
{
  const int BitPerByte = 8;
  assert( oldAddress == getMainAddress() );
  Address newAddress = oldAddress;

  if (protocolConfig->autoConfAlgorithm == 0) {
    // Add 1 or 2 to our address

    // Compute by how much we will increase our address: 0 or 1
    // XXX: why doesn't it work?
    //string internalSeed;
    //SetToStringOf(internalSeed, getCurrentTime() << ":" << getId());
    //int incrementCount = 1+2*drand48(); //randomIntOf(2, internalSeed);
    //---
    int incrementCount = 1;
    if (drawDouble(1.0) < protocolConfig->autoConfIncrementProbability)
      incrementCount ++;
    
    // Increment the address
    for (int i=0; i<incrementCount; i++) {
      do {
	newAddress = incrementAddress(addressFactory, newAddress,
				      protocolConfig->autoConfPrefixLength);
      } while(stateSet.findFirst_MainAddr(newAddress) != NULL);
    }

  } else if (protocolConfig->autoConfAlgorithm == 1) {
    // In case of conflict,  use this magic counter.
    // this can work decently only in simulations.
    static unsigned int magicAddressCounter = 1024;
    assert( oldAddress.getNetSize() == 2*sizeof(int) );

    assert( protocolConfig->autoConfPrefixLength 
	    < BitPerByte * oldAddress.getNetSize() ); // XXX: should pre-check

    do {
      unsigned int value = magicAddressCounter++;
      unsigned char* data = (unsigned char*)oldAddress.getRawAddress();
      unsigned char* newData = new unsigned char [oldAddress.getNetSize()];
      memcpy(newData, data, oldAddress.getNetSize());
#if 0      
      for (int i=0; i<protocolConfig->autoConfPrefixLength; i++)
	setBit(newData, i, (value>>i)&1);
#endif
      int* newDataPtr = (int*)newData;
      *newDataPtr = (value) & ((1 << protocolConfig->autoConfPrefixLength)-1);
      
      newAddress = Address(addressFactory, newData);
      delete [] newData;
    } while(stateSet.findFirst_MainAddr(newAddress) != NULL);

  } else if (protocolConfig->autoConfAlgorithm == 2) {

    assert( protocolConfig->autoConfPrefixLength 
	    < BitPerByte * oldAddress.getNetSize() ); // XXX: should pre-check

    do {
      unsigned char* data = (unsigned char*)oldAddress.getRawAddress();
      unsigned char* newData = new unsigned char [oldAddress.getNetSize()];
      memcpy(newData, data, oldAddress.getNetSize());

      setSuffixBitToRandom(newData, oldAddress.getNetSize(),
			   protocolConfig->autoConfPrefixLength);
      
      newAddress = Address(addressFactory, newData);
      delete [] newData;
    } while(stateSet.findFirst_MainAddr(newAddress) != NULL);
    
  } else if (protocolConfig->autoConfAlgorithm == 3) {
    // same as 1, for simulations
    assert( oldAddress.getNetSize() == 2*sizeof(int) );
    int incrementCount = 1;
    if (drawDouble(1.0) < protocolConfig->autoConfIncrementProbability)
      incrementCount ++;
    
    // Increment the address
    for (int i=0; i<incrementCount; i++) {
      do {
	unsigned char* newData = new unsigned char [newAddress.getNetSize()];
	unsigned char* data = (unsigned char*)newAddress.getRawAddress();
	memcpy(newData, data, newAddress.getNetSize());
	int* newDataPtr = (int*)newData;
	*newDataPtr = (*newDataPtr + 1) &
	  ((1 << protocolConfig->autoConfPrefixLength)-1);
	newAddress = Address(addressFactory, newData);
	delete [] newData;
      } while(stateSet.findFirst_MainAddr(newAddress) != NULL);
    }

  } else if (protocolConfig->autoConfAlgorithm == 4) {
    // same as 2, for simulations -- UNTESTED
    assert( oldAddress.getNetSize() == 2*sizeof(int) );    

    assert( (int)protocolConfig->autoConfPrefixLength 
	    < (int)(BitPerByte * sizeof(int)) ); // XXX: should pre-check

    do {
      unsigned char* newData = new unsigned char [oldAddress.getNetSize()];
      unsigned char* data = (unsigned char*)oldAddress.getRawAddress();
      memcpy(newData, data, oldAddress.getNetSize());

      int* newDataPtr = (int*)newData;
      *newDataPtr = (int)drawDouble(1 << protocolConfig->autoConfPrefixLength);
      
      newAddress = Address(addressFactory, newData);
      delete [] newData;
    } while(stateSet.findFirst_MainAddr(newAddress) != NULL);

  } else Fatal("Unknown auto conf address change algorithm #" 
	       << protocolConfig->autoConfAlgorithm);

  performAddressChange(oldAddress, newAddress);
}

//---------------------------------------------------------------------------

bool StateTuple::isInConflict()
{ return S_conflict_time >= node->getCurrentTime(); }

bool StateTuple::isFamiliar()
{ return isOwn //S_main_addr == node->getMainAddress()
    || node->getCurrentTime() 
    >= S_creation_time + node->getProtocolConfig()->NODE_FAMILIAR_TIME; }

//---------------------------------------------------------------------------

// XXX:AUTOCONF useless
void Node::autoConfNotifyTCGeneration(bool hasGenerated)
{
  if (hasGenerated != hadGeneratedTC) {
    D(*log, lAutoConf, getRealTime() << " [autoconf-tc-generation] " 
      << getId() << " " << hadGeneratedTC << endl);
  }
  hadGeneratedTC = hasGenerated;
}

#if 0
void Node::clearAllIfaceQueue()
{
  std::list<OLSRIface*>* ifaceList = getIfaceList();
  for(std::list<OLSRIface*>::iterator it = ifaceList->begin();
      it != ifaceList->end(); it++)
    ;
}
#endif
//---------------------------------------------------------------------------

// {DAD}
AutoConfState Node::_getAutoConfState() 
{
  if (protocolConfig->autoConfNoState)
    return STATE_NORMAL;
  // First update state:
  Time helloStateEndTime = TimeNever;
  Time topologyStateEndTime = TimeNever;
  if (autoConfState == STATE_HELLO) {
    helloStateEndTime = protocolConfig->autoConfHelloStateDuration
      + autoConfStateTime;
    if (getCurrentTime() > helloStateEndTime) {
      autoConfState = STATE_TOPOLOGY;
      autoConfStateTime = helloStateEndTime;
      notifyOneHopNeighborhoodChange(); // XXX: not true but ...
      // ... this will trigger MPR recalculation and route recalculation
    }
  }
  if (autoConfState == STATE_TOPOLOGY) {
    topologyStateEndTime = protocolConfig->autoConfTopologyStateDuration
      + autoConfStateTime;
    if (getCurrentTime() > topologyStateEndTime) {
      autoConfState = STATE_NORMAL;
      autoConfStateTime = topologyStateEndTime;
      notifyOneHopNeighborhoodChange(); // XXX: not true but ...
      // ... this will trigger MPR recalculation and route recalculation
    }
  }
  
  assert( autoConfStateTime <= getCurrentTime() );
  return autoConfState;
}

//---------------------------------------------------------------------------

// {DAD}
bool Node::autoConfGenerateTCMessage(list<Address>& addressList)
{
  bool result = false;
  AutoConfState stateList [] = { 
    STATE_HELLO, STATE_TOPOLOGY, STATE_NORMAL, STATE_undefined 
  };

  AutoConfState currentState = _getAutoConfState();

  for (int i=0; stateList[i]!=STATE_undefined; i++) {
    list<Address> currentAddressList;
    for (list<Address>::iterator it = addressList.begin();
	 it != addressList.end(); it++) {
      StateTuple* stateTuple = stateSet.ensure(*it);
      if (stateTuple->S_state == stateList[i]) {
	bool isSufficientlyFamiliar = true;
	if (protocolConfig->autoConfContaminationAvoidance
	    && protocolConfig->autoConfUseR10R11) {
	  int countFamiliarNode = 0;
	  int countUnfamiliarNode = 0;
	  StateTuple* thisStateTuple = stateSet.ensure(*it);
	  if (thisStateTuple->isFamiliar())
	    countFamiliarNode++;
	  else countUnfamiliarNode++;
	  NeighborTuple* neighborTuple = neighborSet.findFirst_MainAddr(*it);
	  assert( neighborTuple != NULL );
	  for(NeighborTuple::AssociatedTwoHopNeighborIterator twoHopIt =
		neighborTuple->getAssociatedTwoHopNeighborIterator(); 
	      !twoHopIt.isDone();twoHopIt.next()) {
	    StateTuple* stateTuple = stateSet.ensure((*twoHopIt)->N_2hop_addr);
	    if (stateTuple->isFamiliar())
	      countFamiliarNode++;
	    else countUnfamiliarNode++;
	  }
	  if (countFamiliarNode < (countFamiliarNode + countUnfamiliarNode)
	      * protocolConfig->MIN_TC_FAMILIARITY_RATE) {
	    D(*log, lAutoConf, getRealTime() << " [autoconf-conflict] "
	      << getId() << " <R@10> detected neighbor=" << (*it)
	      << " nb_fam=" << countFamiliarNode
	      << " nb_unfam=" << countUnfamiliarNode
	      << endl);
	    isSufficientlyFamiliar = false;
	  }
	}
	if (isSufficientlyFamiliar)
	  currentAddressList.push_back(*it);
	else {
	  // XXX: this is a hack, we put 2 times the address
	  // XXX: handle message split.
	  for (int i=0;i<2;i++) 
	    currentAddressList.push_back(*it);
	}
      }
    }
    
    if (currentAddressList.size() > 0) {
      result = true;
      //MessageType messageType = TC_MESSAGE;

      //if (currentState != STATE_NORMAL || stateList[i] != STATE_NORMAL)
      //messageType = TC_MESSAGE_WITH_STATE;
      _generateTCMessage(//messageType,
			 currentState, stateList[i],
			 currentAddressList);
    }
  }
  return result;
}

void Node::autoConfGenerateHelloMessage(OLSRIface* iface,
					list<LinkEntry>& linkList)
{
  AutoConfState stateList [] = { 
    STATE_HELLO, STATE_TOPOLOGY, STATE_NORMAL, STATE_undefined 
  };
  AutoConfState currentState = _getAutoConfState();
  int linkSent = 0;

  for (int i=0; stateList[i]!=STATE_undefined; i++) {
    list<LinkEntry> currentLinkList;
    for (list<LinkEntry>::iterator it = linkList.begin();
	 it != linkList.end(); it++) {
      StateTuple* stateTuple = stateSet.ensure( (*it).address );
      if (stateTuple->S_state == stateList[i])
	currentLinkList.push_back(*it);
    }
    
    if (currentLinkList.size() > 0) {
      _generateHelloMessage(iface, currentState, 
			    stateList[i], currentLinkList);
      linkSent += currentLinkList.size();
    }
  }

  if (linkSent == 0)  // implies: no message sent: Generate empty Hello
    _generateHelloMessage(iface, currentState, STATE_NORMAL, linkList);
}


//---------------------------------------------------------------------------

#ifdef AUTOCONF_IPV4_NETFILTER

#include "autoconf_netfilter.h"

void Node::autoConfSetNetfilterManager(DADNetfilterManager* aManager)
{ dadNetfilter = aManager; }

// The main receiving function.
void Node::autoConfNotifyEventAddressConflict(Address addressInConflict)
{
  updateCurrentTime();
  D(*log, lAutoConf, getRealTime() << " [autoconf-conflict] " 
    << getId() << " <R1> detected" << endl);
  preEvent("netfilter-dad");
  D(*log, lEvent, getRealTime() << " [autoconf-netfilter-dad] " 
    << getId() << " " << addressInConflict << endl );
  chooseNewAddress(addressInConflict);
  processChange(true);
  postEvent("netfilter-dad");

}


int DADNetfilterManager::modifyRule(bool shouldAdd, string deviceName,
				    Address ipv4Address,
				    string strIpv4Address, 
				    int udpPort, int ruleIndex)
{
  assert( (shouldAdd && (ruleIndex == NoRuleIndex))
	  || (!shouldAdd && ruleIndex >= 0 ));
  if (shouldAdd) {
    ruleIndex = nextRuleIndex;
    nextRuleIndex++;
  }
  string prefix = Repr("OOLSR:DAD:" << getpid() << ":" << ruleIndex);
  string iptablesPath = node->getProtocolConfig()->iptablesPath;
  if (iptablesPath.length() == 0)
    Fatal("iptables command path was not given in the configuration");
  list<string> commandArg;
  list<string>& l = commandArg;
  l << iptablesPath;
  l << "-t" << "mangle";
  l << (shouldAdd ? "-A" : "-D") << "PREROUTING";
  l << "--in-interface" << deviceName;
  l << "--protocol" << "udp";
  l << "--source" << strIpv4Address;
  l << "--destination-port" << Repr(udpPort);
  l << "-m" << "mac" << "--mac-source" << "!" << "ff:ff:ff:ff:ff:ff";
  l << "-j" << "ULOG";
  l << "--ulog-prefix" << prefix;
  l << "--ulog-nlgroup" << "1";
  l << "--ulog-qthreshold" << "1";
  l << "--ulog-cprange" << "68"; // 68 == max ip hdr size(60) + UDP header(8)
  
  CommandManager commandManager(commandArg);
  string unusedOutput;
  DoOrDie(commandManager.simpleRun(unusedOutput, _strError) == 0);

  if (shouldAdd) {
    ruleToAddress[ruleIndex] = ipv4Address;
  } else {
    int count = ruleToAddress.erase(ruleIndex);
    assert( count == 1 );
  }

  return ruleIndex;
}


void DADNetfilterManager::handleUlogMessage(ulog_packet_msg_t* message, 
					    int messageSize)
{
  assert(message->indev_name[0] != '\0');
  message->prefix[ULOG_PREFIX_LEN-1] = '\0'; // just to be sure...
  string prefix = message->prefix;
  vector<string> prefixList = stringSplit(prefix, ":");
  int destinationPid = -1, ruleIndex = -1;
  if (prefixList.size() != 4 
      || prefixList[0] != "OOLSR" || prefixList[1] != "DAD"
      || !strToInt(prefixList[2], destinationPid)
      || !strToInt(prefixList[3], ruleIndex)) {
    string errorString = 
      Repr("Ulog message parsing: error in prefix '" << prefix << "'");
    D(*node->log, lAutoConf, node->getRealTime() << " [autoconf-warning] "
      << node->getId() << " " << errorString << endl);
    Warn(errorString);
    return;
  }
  if (destinationPid != getpid()) {
    D(*node->log, lAutoConf, node->getRealTime() << " [autoconf-notice] "
      << node->getId() << " ulog for another process :'" <<  
      prefix << "'" << endl);
    return;
  }
  map<int, Address>::iterator mapping = ruleToAddress.find(ruleIndex);
  if (mapping == ruleToAddress.end()) {
    string errorString = 
      Repr("ulog for an unknow rule index :'" << prefix << "'" << endl);
    D(*node->log, lAutoConf, node->getRealTime() << " [autoconf-error] "
      << node->getId() << " " << errorString);
    Warn(errorString);
    return;
  }
  
  node->autoConfNotifyEventAddressConflict((*mapping).second);
}

#endif // AUTOCONF_IPV4_NETFILTER

//---------------------------------------------------------------------------
