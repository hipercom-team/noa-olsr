//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
//  $Id: protocol_config.cc,v 1.17 2004/09/09 17:17:00 adjih Exp $
//---------------------------------------------------------------------------

#include "base.h"

#include <list>
#include <vector>
#include "mystream.h"

using std::vector;

//---------------------------------------------------------------------------

#include "protocol_config.h"
#include "log.h"
#include "general.h"

//---------------------------------------------------------------------------

// XXX: not Windows compatible
string readFile(string fileName)
{
#ifndef UNDER_CE
  std::ifstream input;
  input.open (fileName.c_str(), std::ios::binary );

  input.seekg (0, std::ios::end);
  int fileSize = input.tellg();
  input.seekg (0, std::ios::beg);
  
  string result;
  result.resize(fileSize, '\0');
  input.read((char*)result.data(), fileSize); // XXX: error handling? CONVERT?
  input.close();
  return result;
#else
  return "";
#endif
}

void ConfigParser::parseFile(GeneratedProtocolConfig& baseConfig,
			     Log& log,
			     string fileName)
{
  string data = readFile(fileName);
  string previousFileName = currentFileName;
  int previousLineNumber = currentLineNumber;
  currentFileName = fileName;
  currentLineNumber = 0;
  parse(baseConfig, log, data);
  currentFileName = previousFileName;
  currentLineNumber = previousLineNumber;
}


bool isOption(string current)
{
  return (current == "-f")
    || (current == "-i") || (current == "-I")
    || (current == "-c")
    || (current.length()>2 && current[0] == '-' && current[1] == '-');
}

void ConfigParser::parseArgList(GeneratedProtocolConfig& baseConfig, Log& log,
				char** argv, int argc)
{
  string currentData = "# Automatically generated from command line:\n#";
  for(int i=0; i<argc; i++) {
    currentData += " ";
    currentData += argv[i];
  }
  currentData += "\n\n";
  while (argc >= 1) {
    string current = argv[0];
    if (current == "-I" || current == "-i") {
      currentData += "# From -I option, BEGIN:\n";
      currentData += "interface ";
      currentData += argv[1];
      currentData += "\n";
      currentData += "# From -I option, END.\n";
      argv += 2; argc -= 2;
    } else if (current == "-c") {
      if (argc < 2)
	Exit("argument list error: -c option without argument");
      currentData = "# From -c option, BEGIN:\n";
      currentData += argv[1];
      currentData = "# From -c option, END.\n";
      argv += 2; argc -= 2;
    } else if (current == "-f") {
      if (argc < 2)
	Exit("argument list error: -f option without filename argument");
      currentData += "\n# from command line argument: -f ";
      currentData += argv[1];
      currentData += "\n";
      currentData += "include ";
      currentData += argv[1];
      currentData += "\n";
      argv += 2;
      argc -= 2;
    } else if (current.length()>2 && current[0] == '-' && current[1] == '-') {
      // "--" options
      string tmpCurrent = current;
      tmpCurrent.erase(0,2); // remove "--"
      string comment = "# From command line argument: " + current;
      int i = 1;
      while( i<argc && !isOption(argv[i]) ) {
	tmpCurrent += " "; 
	tmpCurrent += argv[i];
	comment += " ";
	comment += argv[i];
	i++;
      }
      argv += i;
      argc -= i;
      currentData += comment + "\n";
      currentData += tmpCurrent + "\n";
#if 0
      if(tmpCurrent == "on") {
	if(argc < 4)
	  Exit("not enough arguments after " << current.c_str());
	currentData += "# from command line argument: ";
	currentData += argv[0]; currentData += " ";
	currentData += argv[1]; currentData += " ";
	currentData += argv[2]; currentData += " ";
	currentData += argv[3]; currentData += "\n";

	currentData += tmpCurrent; currentData += " ";
	currentData += argv[1]; currentData += " ";
	currentData += argv[2]; currentData += " ";
	currentData += argv[3]; currentData += "\n";
	
	argv += 4;
	argc -= 4;
      } else {
	if(argc < 2)
	  Exit("not enough arguments after " << current.c_str());
	currentData += "# from command line argument: ";
	currentData += argv[0]; currentData += " ";
	currentData += argv[1]; currentData += "\n";

	currentData += tmpCurrent; currentData += " ";
	currentData += argv[1]; currentData += " ";
	
	argv += 2;
	argc -= 2;
      }
#endif
    } else {
      Exit("Cannot understand argument '" << argv[0] << "'");
    }
  }
  parse(baseConfig, log, currentData);
}

void ConfigParser::parse(GeneratedProtocolConfig& baseConfig, 
			 Log& log, string& allData)
{
  int lineBeginPos = 0;
  int nextLineBeginPos = 0;
  currentLineNumber = 0;
  string data(allData);
  string lineSeparatorSet = ";\n";
  while(data.length()>0) {
    lineBeginPos = nextLineBeginPos;
    string::size_type pos = data.find_first_of(lineSeparatorSet);
    string line;
    if (pos == string::npos) {
      line = data;
      data.erase(0, data.length());
      nextLineBeginPos = lineBeginPos + pos;
    } else {
      if (data[pos] == '\n')
	currentLineNumber++;
      line = data.substr(0, pos);
      data.erase(0, pos+1);
      nextLineBeginPos = lineBeginPos + pos + 1;
    }
    if (line.length() == 0)
      continue; // empty line
    if (line[0] == '#')
      continue; // comment
    parseLine(baseConfig, log, line);
  }
}


void ConfigParser::parseLine(GeneratedProtocolConfig& baseConfig, 
			     Log& log, string& line)
{
  string spaceSet = " \t";
  vector<string> rawDataList = stringSplit(line, spaceSet);
  vector<string> dataList;
  for(std::vector<string>::iterator it = rawDataList.begin();
      it != rawDataList.end(); it++)
    if((*it).length() > 0)
      dataList.push_back(*it);

  if(dataList.size() == 0)
    return; // line with only space and tabs

  if(dataList[0] == "on") {
    if (dataList.size() < 2) {
      Exit("Syntax error in line " << currentLineNumber << ": "
	    << "'interface-option' misses arguments in: " << endl
	    << "  " << line);
    }
    string ifaceName = dataList[1];
    dataList.erase(dataList.begin());
    dataList.erase(dataList.begin());
    if (baseConfig.ifaceConfig.count(ifaceName) == 0) {
      GeneratedIfaceConfig* ifaceConfig = new GeneratedIfaceConfig;
      ifaceConfig->setDefaultValue();
      baseConfig.ifaceConfig[ifaceName] = ifaceConfig;
    } 
    string errorMsg = baseConfig.ifaceConfig[ifaceName]->parseData(dataList);
    bool ok = errorMsg.empty();
    if (!ok) 
      Exit("Parse error in interface '" << ifaceName << "' configuration: "
	    << endl << "  " << line);

  } else if (dataList[0] == "include") {
    if (dataList.size() != 2) 
      Exit("Incorrect number of arguments for 'include' option: "
	    << dataList.size());
    string fileName = dataList[1];
    parseFile(baseConfig, log, fileName);

  } else if (dataList[0] == "log-all") {
    dataList.erase(dataList.begin());
    log.setAllDefaultValue(true);

  } else if (dataList[0] == "log-none") {
    dataList.erase(dataList.begin());
    log.setAllDefaultValue(false);

  } else if (dataList[0] == "use-ipv4") {
    dataList.erase(dataList.begin());
    baseConfig.ipv6 = false;
    baseConfig.ipv4 = true;

  } else if (dataList[0] == "use-ipv6") {
    dataList.erase(dataList.begin());
    baseConfig.ipv6 = true;
    baseConfig.ipv4 = false;

  } else if (dataList[0] == "interface") {
    if (dataList.size() != 2) 
      Exit("Incorrect number of arguments for 'interface' option: "
	    << dataList.size());
    // XXX: this is cut&paste from above
    string ifaceName = dataList[1];
    if (baseConfig.mainIface == "")
      baseConfig.mainIface = ifaceName;
    dataList.erase(dataList.begin());
    dataList.erase(dataList.begin());
    if (baseConfig.ifaceConfig.count(ifaceName) == 0) {
      GeneratedIfaceConfig* ifaceConfig = new GeneratedIfaceConfig;
      ifaceConfig->setDefaultValue();
      baseConfig.ifaceConfig[ifaceName] = ifaceConfig;
    }     
  } else {
    string errorMsg = baseConfig.parseData(log, dataList);
    bool ok = errorMsg.empty();
    if (!ok) 
      Exit("Parse error in configuration: "
	    << endl << "  " << line);
  }
}

//---------------------------------------------------------------------------
