//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Anis Laouiti, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// This file implements the Multiple Interface Association Information Base.
//---------------------------------------------------------------------------

#include "node.h"

//-------------------- IfaceAssociationBase
/// [IfaceAssociationBase] This method is called when the OLSR Node 
/// is started.
void Node::startIfaceAssociationBase()
{
  Time delay = _startDelay(0, protocolConfig->MID_INTERVAL);
  addGenerationEvent(delay, delay, &Node::eventMIDGeneration,"mid-generation");
}

//---------------------------------------------------------------------------
/// [IfaceAssociationBase] This method is called when an MIDMessage is
/// received and should be processed.

void Node::processMIDMessage(MIDMessage* message)
{
  Message* header = message->header;
  
  Time currentTime = getCurrentTime();
  Time validityTime = header->getValidityTime();

  Address sendMainAddress = ifaceToMainAddress(header->sendIfaceAddress);
  if (!isSymmetricNeighbor(sendMainAddress)) // @@2513-2515
    return; 

  for(std::list<Address>::iterator it = message->addressList.begin();
      it!=message->addressList.end(); it++)
  
    {
      IfaceAssociationTuple* midTuple;
      if(!(midTuple=ifaceAssociationSet.findFirst_IfaceAssociation
	   (header->originatorAddress,(*it))))
	{
	  midTuple= new IfaceAssociationTuple;
	  
	  midTuple->I_main_addr = header->originatorAddress;
	  midTuple->I_iface_addr = (*it);
	  midTuple->I_time=currentTime + validityTime; 
	  notifyNoLongerMainAddress(midTuple->I_iface_addr);
	  ifaceAssociationSet.add(midTuple);
	} else midTuple->I_time=currentTime + validityTime; 
      midTuple->update();
    }
}

//---------------------------------------------------------------------------
/// [IfaceAssociationBase] This method is called when an MIDMessage should
/// be generated.
void Node::eventMIDGeneration()
{
  updateCurrentTime();
  preEvent("gen-mid");
  // reschedule  XXX: refs
  double minDelay = protocolConfig->MID_INTERVAL - protocolConfig->MAXJITTER;
  if(minDelay <0) minDelay = 0;
  addGenerationEvent(getCurrentTime() + minDelay,
		     getCurrentTime() + protocolConfig->MID_INTERVAL,
		     &Node::eventMIDGeneration, "mid-generation");

  if (getAddressList()->size() > 1) { // @@XXX: only MID if there is more than
    MIDMessage* midMessage= new MIDMessage;

    for(std::list<Address>::iterator it = getAddressList()->begin();
	it != getAddressList()->end(); it++) {
      if( !((*it)== getMainAddress()))
	midMessage->addressList.push_back((*it));
    }
    
    Message* message = new Message
      (MID_MESSAGE, 
       toMantissaExponentByte(protocolConfig->MID_HOLD_TIME), 
       getMainAddress(), // Originator 
       MaxTTL, // ttl, 
       0); // hop vcount, 
  
    message->content = midMessage;
    message->maxTime = getCurrentTime();
    
    packetManager->sendMessageToAll(message);
  }

  postEvent("gen-mid");
}

//---------------------------------------------------------------------------
/// [IfaceAssociationBase] Convert an interface address to a main address
/// according to the Iface Association Tuple, and to the temporary
/// association if one was set by setTemporaryIfaceAssociation
/// and not removed later by forgetTemporaryIfaceAssociation

Address Node::ifaceToMainAddress(Address ifaceAddress)
{
  if (isOneOfOurIfaceAddress(ifaceAddress))
    return getMainAddress();
  IfaceAssociationTuple* midTuple 
    = ifaceAssociationSet.findFirst_IfaceAssociation(ifaceAddress);
  if( midTuple )
    return midTuple->I_main_addr;
  return ifaceAddress; // [CA] actually return itself
}
//---------------------------------------------------------------------------

void Node::setTemporaryIfaceAssociation(Address mainAddress, 
					Address ifaceAddress,
					Time validityTime)
{
  IfaceAssociationTuple* midTuple;
  Time currentTime = getCurrentTime();
  
  if( !(midTuple= ifaceAssociationSet.findFirst_IfaceAssociation
	(mainAddress,ifaceAddress)))   
    {
      midTuple= new IfaceAssociationTuple;
      midTuple->I_main_addr = mainAddress;
      midTuple->I_iface_addr = ifaceAddress;
      midTuple->I_time=currentTime + validityTime;
      notifyNoLongerMainAddress(midTuple->I_iface_addr);
      ifaceAssociationSet.add(midTuple);
    }
  else {
    Time newExpireTime = currentTime + validityTime;
    if (newExpireTime > midTuple->I_time)
      midTuple->I_time = newExpireTime;
  }
  midTuple->update();
}

//---------------------------------------------------------------------------

void Node::forgetTemporaryIfaceAssociation()
{ /*XXX: should do something*/ }

//---------------------------------------------------------------------------

void IfaceAssociationSet::notifyPreRemoval(IfaceAssociationTuple* tuple)
{
  Address previousIfaceAddress = tuple->I_iface_addr;
  // All the link with the previous tuple->L_local_iface_address are
  // no longer properly associated to a NeighborTuple: as a result,
  // they would break invariants, so they are removed:
  LinkSet::TupleIterator it = node->linkSet.getIter();
  while (!it.isDone()) {
    LinkTuple* linkTuple = it.getCurrent();
    NeighborTuple* neighborTuple = linkTuple->getAssociatedNeighbor();
    if (neighborTuple->N_neighbor_main_addr == tuple->I_main_addr
	&& linkTuple->L_neighbor_iface_addr == previousIfaceAddress)
      it.removeAndDeleteCurrentAndDoNext();
    else it.next();
  }
}

void IfaceAssociationSet::notifyRemoval(IfaceAssociationTuple* tuple)
{ 
  node->shouldRecomputeRoute = true; 

}

void IfaceAssociationSet::notifyAddition(IfaceAssociationTuple* tuple)
{ node->shouldRecomputeRoute = true; }


#if 0
void Node::notifyNoLongerIfaceAssociation(Address previousMainAddress, 
					  Address previousIfaceAddress)
{					  
  // All the link with the previous tuple->L_local_iface_address are
  // no longer properly associated to a NeighborTuple: as a result,
  // they would break invariants, so they are removed:
  LinkSet::TupleIterator it = linkSet.getIter();
  while (!it.isDone()) {
    LinkTuple* linkTuple = it.getCurrent();
    NeighborTuple* neighborTuple = linkTuple->getAssociatedNeighbor();
    if (neighborTuple->N_neighbor_main_addr == previousMainAddress
	&& linkTuple->L_neighbor_iface_addr == previousIfaceAddress)
      it.removeAndDeleteCurrentAndDoNext();
    else it.next();
  }
} 
#endif

// We can't put this is notifyAddition, because notifyAddition 
// is called after the tuple is added, that is after the invariants
// are broken.
void Node::notifyNoLongerMainAddress(Address previousMainAddress)
{
  // Remove all the links with main address the one given
  LinkSet::TupleIterator it = linkSet.getIter();
  while (!it.isDone()) {
    LinkTuple* linkTuple = it.getCurrent();
    NeighborTuple* neighborTuple = linkTuple->getAssociatedNeighbor();
    if (neighborTuple->N_neighbor_main_addr == previousMainAddress)
      it.removeAndDeleteCurrentAndDoNext();
    else it.next();
  }
}

//---------------------------------------------------------------------------
