//---------------------------------------------------------------------------
//                             OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//             Anis Laouiti, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// System calls for Linux
//---------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
//#include <sys/types.h>
//#include <netdb.h>
//#include <net/if.h>

#include <errno.h>
#include <asm/types.h>
//#include <linux/netlink.h>
#include <linux/rtnetlink.h> 
//#ifdef WITH_IPV6

//#endif // WITH_IPV6

//#include <arpa/inet.h> // inet_pton


#include <string>
#include <vector>

using std::string;
using std::vector;

//---------------------------------------------------------------------------

#include "general.h"
#include "address.h"
#include "network_generic.h"
#include "scheduler_simulation.h"
#include "scheduler_unix.h"

#include "http_support.h"

#include "html_support.cc" // XXX:  rename

#ifdef LINK_MONITORING
#include "iwevent_client.h"
#endif

#include "system_linux.h"


//---------------------------------------------------------------------------

void LinuxLowLevel::socketBindToDevice(int sd, string deviceName)
{
  const char* strDeviceName = deviceName.c_str();
  if (setsockopt(sd, SOL_SOCKET, SO_BINDTODEVICE, strDeviceName, 
		 strlen(strDeviceName)+1)<0)
    Fatal("setsockopt(sd, SOL_SOCKET, SO_BINDTODEVICE, '" << deviceName
	  << "': " << strerror(errno));
}


void LinuxLowLevel::setSocketReuseAddr(int sd)
{
  int on = 1;
  if (setsockopt(sd, SOL_SOCKET, SO_REUSEADDR, (void*)&on,
		 sizeof (on)) < 0)
    Fatal(" setsockopt SO_REUSEADDR: " << strerror(errno));
}

void LinuxLowLevel::setSocketBroadcast(int sd)
{
  int on = 1;
  if (setsockopt(sd, SOL_SOCKET, SO_BROADCAST, (void*)&on,
		 sizeof (on)) < 0)
    Fatal(" setsockopt SO_BROADCAST: " << strerror(errno));
}

void LinuxLowLevel::setSocketPriority(int sd)
{
  int on;
  on=6;
  if (setsockopt(sd, SOL_SOCKET, SO_PRIORITY, &on, sizeof (on)) < 0)
    Fatal("setsockopt SO_PRIORITY: " << strerror(errno));
}

#if 0
void LinuxLowLevel::setSocketMulticastLoop(int sd, bool value)
{
  int on = (int)value;
  if (setsockopt(sd, SOL_IP, IP_MULTICAST_LOOP, &on, sizeof (on)) < 0)
    Fatal("setsockopt IP_MULTICAST_LOOP: " << strerror(errno));
}
#endif

void LinuxLowLevel::addRoute(int family, int ifaceIndex, Address destIpAddress,
			     Address gatewayAddress, Address netMaskAddress, 
			     int metric, bool notFatal)
{
  //    modifyRoute(RTM_NEWROUTE,NLM_F_REPLACE|NLM_F_CREATE|NLM_F_ACK, family, 
  //		ifaceIndex, destIpAddress, gatewayAddress, netMaskAddress,
  //		metric);
  modifyRoute(RTM_NEWROUTE,NLM_F_CREATE|NLM_F_ACK, family, 
	      ifaceIndex, destIpAddress, gatewayAddress, netMaskAddress,
	      metric, notFatal);
}

void LinuxLowLevel::removeRoute(int family, int ifaceIndex, 
				Address destIpAddress,
				Address gatewayAddress, 
				Address netMaskAddress, 
				int metric, bool notFatal)
{
  modifyRoute(RTM_DELROUTE, NLM_F_ACK, family, ifaceIndex,
	      destIpAddress, gatewayAddress, netMaskAddress, metric, 
	      notFatal);
}

int LinuxLowLevel::modifyRoute(int action, int flags, int family, 
			       int ifaceIndex,
			       Address destIpAddress,
			       Address gatewayAddress, Address netMaskAddress, 
			       int metric, bool notFatal)
{
  int sock;
  struct
  {
    struct nlmsghdr  nlh;
    struct rtmsg routeMsg;
    char   attrbuf[1024];
  } req;
  int netFormatSize = destIpAddress.getNetSize();
  octet* netFormatAddress = new octet[netFormatSize];
  octet* netFormatAddress2 = new octet[netFormatSize];
  
  int index=ifaceIndex;
  int hops=metric;
  struct sockaddr_nl nladdr;
  static unsigned int seq;
  
  
  if((sock = socket(PF_NETLINK, SOCK_DGRAM, NETLINK_ROUTE)) < 0) {
    Fatal(" PF_NETLINK: error socket creation ");
    return -1;
  }
  
  memset(&nladdr,0,sizeof(nladdr));
  
  nladdr.nl_family= AF_NETLINK;
  
  req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct rtmsg));
  req.nlh.nlmsg_type= action;   
  req.nlh.nlmsg_flags = NLM_F_REQUEST|flags;
  req.nlh.nlmsg_pid = 0;
  req.nlh.nlmsg_seq = ++seq;
  
  req.routeMsg.rtm_family=family;
  
  if (netMaskAddress.isNull()) {
    const int BITS_PER_OCTET = 8;
    req.routeMsg.rtm_dst_len = destIpAddress.getNetSize() * BITS_PER_OCTET;
  } else {
    netMaskAddress.toNet(netFormatAddress);
    req.routeMsg.rtm_dst_len = prefix_length(family, netFormatAddress);
  }
  
  req.routeMsg.rtm_src_len = 0;
  req.routeMsg.rtm_tos = 0;
  req.routeMsg.rtm_table = RT_TABLE_MAIN; //DEFAULT;
  req.routeMsg.rtm_protocol = 100;                     //XXX a verifier
  req.routeMsg.rtm_scope = RT_SCOPE_LINK; //RT_SCOPE_LINK;
  req.routeMsg.rtm_type = RTN_UNICAST;
  req.routeMsg.rtm_flags = 0;
  
  gatewayAddress.toNet(netFormatAddress);
  destIpAddress.toNet(netFormatAddress2);
  
  if (!(gatewayAddress==destIpAddress)) {
    req.routeMsg.rtm_scope=RT_SCOPE_UNIVERSE;
    addattr(&req.nlh,RTA_GATEWAY,netFormatAddress,netFormatSize);
  }
  
  addattr(&req.nlh,RTA_DST,netFormatAddress2,netFormatSize);
    
  addattr(&req.nlh,RTA_OIF,&index,sizeof(index));
  addattr(&req.nlh,RTA_PRIORITY,&hops,sizeof(hops));
  
  delete [] netFormatAddress;
  delete [] netFormatAddress2;
  
  if (sendto(sock,&req,sizeof(req),0,NULL,0)<0)
    Fatal("Netlink sendto request to kernel error");
  else get_system_reply(sock,seq, notFatal);
  return 0;
}

int LinuxLowLevel::prefix_length(int family, void *anetmask)
{
  int prefix=0;
  if(family== AF_INET)
    {
      unsigned int netmask;
      memcpy(&netmask,anetmask,sizeof(unsigned int));
      netmask=ntohl(netmask);
      //printf("netmask initialement: %d\n",netmask);
      while(netmask!=0)
        {
          netmask=netmask<<1;
          //printf("netmask : %d\n",netmask);
          prefix++;
          
        }
      //printf("prefix length is: %d\n",prefix);
      return prefix;
    }
  if(family== AF_INET6)
    {
      struct in6_addr netmask;
      unsigned int mask;
      int i;
      memcpy(&netmask,anetmask,sizeof(struct in6_addr));
      for(i=0;i<4;i++)
	{
	  mask=ntohl(netmask.s6_addr32[i]);
	  while(mask!=0)
	    {
	      mask=mask<<1;
	      prefix++;
	    }
	}
      return prefix;
    }
  return (-1);
}
  
int LinuxLowLevel::get_system_reply(int sockFd, int seqNum, bool notFatal)
{
#define NL_BUFSIZE 8192
  char buf[NL_BUFSIZE];
  struct sockaddr_nl nladdr;
  struct iovec iov = { buf,NL_BUFSIZE };
  struct nlmsghdr *h;
  struct nlmsgerr *m;
  //struct rtattr *attr; XXX:unused
    
  int status;
  //int attrsize; XXX:unused
  
  struct msghdr msg = {(void*)&nladdr, sizeof(nladdr),&iov,   1, NULL, 0, 0};
  status = recvmsg(sockFd, &msg, 0);        
  
  h = (struct nlmsghdr*)buf;
  while ( NLMSG_OK(h, (unsigned int)status))
    {
      if (h->nlmsg_seq != (unsigned int)seqNum)
	{
	  Fatal(" Nlmsg error: bad sequence number ");
	  return -1;
	}
      
      if (h->nlmsg_type == NLMSG_DONE)
	{
	  fprintf(stderr,"Netlink call done \n");              
	  
	  return 0;
	}
      
      if (h->nlmsg_type == NLMSG_ERROR)
	{
	  m = (nlmsgerr*) NLMSG_DATA(h); // XXX: error: invalid conversion from `void*' to `nlmsgerr*'
	  
	  if(m->error < 0)
	    {
	      int errorCode = -(m->error);
	      if (errorCode == EEXIST) {
		Warn("Nlmsg ACK: EEXIST, a route probably existed before");
		return -1;
	      } else if (errorCode == EPERM) {
		if (notFatal) {
		  Warn("Nlmsg ACK: EPERM, probably don't have permission to"
		       " set routes");
		} else {
		  Fatal("Nlmsg ACK: EPERM, probably don't have permission to"
			" set routes");
		}
	      } else if (errorCode == EAGAIN || errorCode == EINTR) {
		Warn("Nlmsg ACK: EAGAIN or EINTR, one route is probably"
		     " not correctly set now."); // XXX
	      } else {
		if (notFatal) {
		  Warn("Route config: Nlmsg ACK: "
		       << strerror(-(m->error))); 
		} else {
		  Fatal("Route config: Nlmsg ACK: "
			<< strerror(-(m->error))); 
		}		
	      }
	      return -1;
	    }
	}       
      h=NLMSG_NEXT(h,status);
    }
  return 0;  
}
  
  
int LinuxLowLevel::addattr(struct nlmsghdr *header, 
			   int type, void *data, int alen)
{
  struct rtattr *attr;
  int len = RTA_LENGTH(alen);
  
  attr = (struct rtattr*)(((char*)header) + NLMSG_ALIGN(header->nlmsg_len));
  attr->rta_type = type;
  attr->rta_len = len;
  memcpy(RTA_DATA(attr), data, alen);
  header->nlmsg_len = NLMSG_ALIGN(header->nlmsg_len) + len;
  return 0;
}

//---------------------------------------------------------------------------

#include "linux_iproute_manager.cc"

template<class LowLevel>
void prepareIface(string name)
{
  if (LowLevel::isIPv6()) {
    // IPv6 preparation
    string dirName = "/proc/sys/net/ipv6/conf/";
    dirName += name + "/";
    DoOrDie(writeFile(dirName+"forwarding", "1", _strError));
    DoOrDie(writeFile(dirName+"accept_ra", "0", _strError));
    DoOrDie(writeFile(dirName+"accept_redirects", "0", _strError));
    DoOrDie(writeFile(dirName+"autoconf", "0", _strError));
    DoOrDie(writeFile(dirName+"dad_transmits", "0", _strError));
  } else {
    // IPv4 preparation
    string dirName = "/proc/sys/net/ipv4/conf/";
    dirName += name + "/";
    DoOrDie(writeFile(dirName+"forwarding", "1", _strError));
    DoOrDie(writeFile(dirName+"accept_redirects", "0", _strError));
    DoOrDie(writeFile(dirName+"send_redirects", "0", _strError));
    DoOrDie(writeFile(dirName+"rp_filter", "0", _strError));
    //DoOrDie(writeFile(dirName+"tag", "0", _strError));
    // Added after a remark from Y. Owada:
    DoOrDie(writeFile("/proc/sys/net/ipv4/route/min_delay", "0", _strError));
  }
}

template<class LowLevel>
void LinuxSystemIface<LowLevel>::changeAddress(Address newAddress)
{ internalChangeAddress(newAddress, prefixSize, true); }

//XXX: move out those functions
template<class LowLevel>
void LinuxSystemIface<LowLevel>::internalChangeAddress
(Address newAddress, int newPrefixSize, bool shouldDeletePrevious)
{
  SystemCommandManager iproute(protocolConfig->ipRoutePath);
  typename LowLevel::SystemAddress systemAddress;
  string errorString = "";

  // Possibly delete previously set address
  if (shouldDeletePrevious) {
    addressFactory->makeSystemAddress(address, systemAddress);
    string strAddress = LowLevel::reprAddress(systemAddress) 
      + Repr("/" << prefixSize);
    DoOrDie(iproute.delIfaceAddress(name, strAddress, _strError));
  }

  DoOrDie(iproute.setIfaceUpOrDown(name, true, _strError));

  // Now change current address
  addressFactory->makeSystemAddress(newAddress, systemAddress);
  string strAddress = LowLevel::reprAddress(systemAddress);
  string strFullAddress = strAddress + Repr("/" << newPrefixSize);
  //if (ipVersion == IP4) {
  // should add broadcast address
  //  LowLevel::systemAddressToRawAddress(systemAddress);
  //}

  // This is a hack: in Linux(at least 2.4.20), changing an address
  // result in, necessarily, performing the DAD (probably enforced by
  // RFC??), before it is actually useable (?) i.e. not marked as
  // IFA_F_TENTATIVE. This is unless the address is for loopback 
  // device or NOARP is used: so the following hack is used:
  // we turn on NOARP, change the address, and turn off NOARP back.
  // [addrconf.c:ipv6_chk_addr doesn't accept IFA_F_TENTATIVE, 
  // hence bind would fails]
  if (LowLevel::isIPv6())
    DoOrDie(iproute.setIfaceArpFlag(name, false, _strError));
  DoOrDie(iproute.addIfaceAddress(name, strFullAddress, _strError));
  if (LowLevel::isIPv6())
    DoOrDie(iproute.setIfaceArpFlag(name, true, _strError));
  prepareIface<LowLevel>(name);

  if (shouldDeletePrevious) {
    Node* previousPacketReceiver = packetReceiver;
    closeSocket(); 
    address = newAddress; // done here because closeSocket(...) needs
    // old address. XXX: this could be fixed
    prefixSize = newPrefixSize;
    openSocket(previousPacketReceiver);
  } else {
    address = newAddress;
    prefixSize = newPrefixSize;
  }

  autoConfiguredAddress = true;
}

template<class LowLevel>
void LinuxSystemIface<LowLevel>::clearAllIfaceAddress()
{
  SystemCommandManager iproute(protocolConfig->ipRoutePath);
  list<string> ipv4Address;
  list<string> ipv6Address;
  string errorString = "";
  if (!iproute.getIfaceAddressList(name, ipv4Address, 
				   ipv6Address, errorString))
    Fatal("iproute.getIfaceAddressList failed: " << errorString);
  IPVersion ipVersion = (LowLevel::isIPv6() ? IP6 : IP4);
  if (ipVersion == IP6) {
    for (list<string>::iterator it = ipv6Address.begin();
	 it != ipv6Address.end(); it++)
      if (*it != protocolConfig->keptAddress)
	if (!iproute.delIfaceAddress(name, *it, errorString)) 
	  Fatal("iproute.delIfaceAddress " << name << " " << (*it)
		<< " failed: " << errorString);
  } else {
    for (list<string>::iterator it = ipv4Address.begin();
	 it != ipv4Address.end(); it++)
      if (*it != protocolConfig->keptAddress)
	if (!iproute.delIfaceAddress(name, *it, errorString)) 
	  Fatal("iproute.delIfaceAddress " << name << " " << (*it)
		<< " failed: " << errorString);
  }
}

//---------------------------------------------------------------------------

#if 0
// This was used to understand why the socket bind failed in the program
// but not in test-socket2.cc
void sendIPv6Packet(int ifaceIndex) //, string ifaceStrAddress)
{
  int ifaceSocket = socket(AF_INET6, SOCK_DGRAM, 0);
  if(ifaceSocket < 0)
    Fatal(" socket(PF_INET6, SOCK_DGRAM, 0): " << strerror(errno));

  char* ifaceStrAddress = "fd51::1";
  //struct in_addr ifaceAddress;
  //ifaceAddress.s_addr = inet_addr(argv[2]);


  int on = 1;
  if (setsockopt(ifaceSocket, SOL_SOCKET, SO_REUSEADDR, (void*)&on,
		 sizeof (on)) < 0)
    Fatal(" setsockopt SO_REUSEADDR: " << strerror(errno));

  if (setsockopt(ifaceSocket, IPPROTO_IPV6, IPV6_MULTICAST_IF, 
		 (char*)&ifaceIndex,
		 sizeof(ifaceIndex)) != 0)
    Fatal(" setsockopt IP_MULTICAST_IF: " << strerror(errno) );

  sockaddr_in6 bindAddress;
  memset(&bindAddress, 0, sizeof(bindAddress));
  bindAddress.sin6_family = AF_INET6;
  inet_pton(AF_INET6, ifaceStrAddress, &bindAddress.sin6_addr);
  bindAddress.sin6_port = htons(698);
  int status = bind(ifaceSocket, (struct sockaddr*)&bindAddress,
		    sizeof(bindAddress));
  if (status < 0)
    Fatal("socketBind: " << strerror(errno));
  
  //XXX...
}
#endif


template<class LowLevel>
LinuxSystemIface<LowLevel>::LinuxSystemIface
( string aIfaceName, Address aAddress, int aPrefixSize, int aIfaceIndex,
  IOScheduler* aScheduler,
  LinuxAddressFactory<LowLevel>* aFactory,
  string aStrOutputAddress, 
  ProtocolConfig* aProtocolConfig,
  IfaceConfig* aIfaceConfig,
  unsigned int aPort)
  : scheduler(aScheduler), addressFactory(aFactory),
    packetReceiver(NULL), address(aAddress), prefixSize(aPrefixSize),
    port(aPort), recvPort(0), ifaceIndex(aIfaceIndex), name(aIfaceName)
{
  protocolConfig = aProtocolConfig;
  if (aIfaceIndex>=-100)
    recvPort = port;
  else recvPort = -aIfaceIndex;

  strOutputAddress = aStrOutputAddress;

  inputSocket = -1;
  outputSocket = -1;
#ifdef LINK_MONITORING
  signalSocket = -1;
#endif
  associatedIface = NULL;
  ifaceConfig = aIfaceConfig;

#ifdef NU_AUTOCONF

  autoConfiguredAddress = false;
#ifdef AUTOCONF_IPV4_NETFILTER
  autoConfNetfilterRuleIndex = DADNetfilterManager::NoRuleIndex;
#endif // AUTOCONF_IPV4_NETFILTER
  string initialAddress = "";
  string initialPrefix = "";
  if (LowLevel::isIPv6()) {
    initialAddress = protocolConfig->autoConfIpv6InitialAddress;
    initialPrefix = protocolConfig->autoConfIpv6Prefix;
  } else {
    initialAddress = protocolConfig->autoConfIpv4InitialAddress;
    initialPrefix = protocolConfig->autoConfIpv4Prefix;
  }
  if (initialPrefix.length() > 0)
    initialAddress = initialPrefix;
  if (initialAddress.length() > 0) {
    clearAllIfaceAddress();
    int prefixSize = -1;
    int initialPrefixSize = -1;
    typename LowLevel::SystemAddress systemAddress;
    if (!LowLevel::strToAddressAndPrefix(initialAddress, systemAddress,
					 prefixSize, initialPrefixSize))
      Fatal("Can't parse autoconf initial address: " << initialAddress);
    if (initialPrefix.length() > 0) {
      void* rawAddress 	= LowLevel::systemAddressToRawAddress(systemAddress);
      setSuffixBitToRandom(rawAddress, LowLevel::AddressSize, 
			   initialPrefixSize);
    }
    internalChangeAddress(addressFactory->makeAddress(systemAddress), 
			  prefixSize, false);
    protocolConfig->autoConfPrefixLength = prefixSize; //XXX!!: ugly
  }
#endif

}

template<class LowLevel>
void LinuxSystemIface<LowLevel>::openSocket(Node* aPacketReceiver)
{
  packetReceiver = aPacketReceiver;

#if defined(NU_AUTOCONF) && defined(AUTOCONF_IPV4_NETFILTER)
  if (autoConfiguredAddress && !LowLevel::isIPv6()) {
    assert( packetReceiver != NULL );
    assert( autoConfNetfilterRuleIndex == DADNetfilterManager::NoRuleIndex);
    // XXX: should be one function:
    typename LowLevel::SystemAddress systemAddress;
    addressFactory->makeSystemAddress(address, systemAddress);
    string strAddress = LowLevel::reprAddress(systemAddress);

    autoConfNetfilterRuleIndex =
      packetReceiver->dadNetfilter->modifyRule
      (true, name, address, strAddress, 
       protocolConfig->udpPort, DADNetfilterManager::NoRuleIndex);
  }
#endif

  // Create output socket.
  inputSocket = LowLevel::makeUDPSocket();
  outputSocket = inputSocket;
#ifdef LINK_MONITORING
  signalSocket = LowLevel::makeUDPSocket();
#endif
#if !defined(SYSTEMlinux)
  if (!LowLevel::shouldMakeOneSocket()) 
#endif
    {
      outputSocket = LowLevel::makeUDPSocket();
      LowLevel::setSocketReuseAddr(outputSocket);
    }
  LowLevel::setSocketPriority(outputSocket);

  typename LowLevel::SystemAddress ifaceSystemAddress;
  addressFactory->makeSystemAddress(address, ifaceSystemAddress);
  LowLevel::setSocketReuseAddr(inputSocket);
  LowLevel::setSocketMulticastDefaultIface(inputSocket, ifaceIndex,
					   ifaceSystemAddress);
  LowLevel::joinMulticastGroup(inputSocket, name, ifaceIndex,
			       strOutputAddress);
  LowLevel::setSocketMulticastLoop(inputSocket, false);

#if 0
  if (inputSocket != outputSocket && LowLevel::isIPv6()) {
    LowLevel::joinMulticastGroup(outputSocket, name, ifaceIndex,
				 strOutputAddress);  
    LowLevel::setSocketMulticastLoop(inputSocket, false);
  }
#endif

  LowLevel::strToAddress(sendSystemAddress, strOutputAddress);
  LowLevel::setAddressPort(sendSystemAddress, port);
  
  if (inputSocket == outputSocket) {
    typename LowLevel::SystemAddress anyOLSRPortAddress;
    addressFactory->makeSystemAddress(address, anyOLSRPortAddress);
    LowLevel::setAddressPort(anyOLSRPortAddress, recvPort);
    LowLevel::socketBind(inputSocket, anyOLSRPortAddress);
    //LowLevel::socketBindToDevice(inputSocket, name);
  } else {
    typename LowLevel::SystemAddress multicastOLSRPortAddress;
    LowLevel::strToAddress(multicastOLSRPortAddress, "");
    LowLevel::setAddressPort(multicastOLSRPortAddress, recvPort);
    LowLevel::socketBind(inputSocket, multicastOLSRPortAddress);
    LowLevel::socketBindToDevice(inputSocket, name);
    
    if (!LowLevel::isIPv6()) {
      LowLevel::joinMulticastGroup(outputSocket, name, ifaceIndex,
				   strOutputAddress);
      //typename LowLevel::SystemAddress sendIfaceAddress;
      //addressFactory->makeSystemAddress(address, sendIfaceAddress);
      //LowLevel::socketBind(outputSocket, sendIfaceAddress);
    }
    LowLevel::strToAddress(multicastOLSRPortAddress, "");
#ifndef SYSTEMlinux
    //if (LowLevel::isIPv6()) // For autoconf to use the iface address
#endif
      addressFactory->makeSystemAddress(address, multicastOLSRPortAddress);
    LowLevel::setAddressPort(multicastOLSRPortAddress, recvPort);
    LowLevel::socketBind(outputSocket, multicastOLSRPortAddress, false);
    LowLevel::setSocketMulticastLoop(outputSocket, false);
    LowLevel::socketBindToDevice(outputSocket, name);
  }  

  scheduler->addFdHandler(this, NULL);
}

template<class LowLevel>
void LinuxSystemIface<LowLevel>::closeSocket()
{
  scheduler->removeFdHandler(this);
  (void)close(inputSocket);
  if (inputSocket != outputSocket)
    (void)close(outputSocket);
  inputSocket = -1;
  outputSocket = -1;
#ifdef LINK_MONITORING
#warning XXX should handle closeSocket properly
#endif

#if defined(NU_AUTOCONF) && defined(AUTOCONF_IPV4_NETFILTER)
  if (!LowLevel::isIPv6()
      && autoConfNetfilterRuleIndex != DADNetfilterManager::NoRuleIndex) {
    //XXX: should be one function:
    typename LowLevel::SystemAddress systemAddress;
    addressFactory->makeSystemAddress(address, systemAddress);
    string strAddress = LowLevel::reprAddress(systemAddress);

    assert( packetReceiver != NULL );
    packetReceiver->dadNetfilter->modifyRule
      (false, name, address, strAddress, protocolConfig->udpPort, 
       autoConfNetfilterRuleIndex);
    autoConfNetfilterRuleIndex = DADNetfilterManager::NoRuleIndex;
    //autoConfiguredAddress = false;
  }
#endif

  packetReceiver = NULL;
}

template<class LowLevel>
void LinuxSystemIface<LowLevel>::sendPacket(MemoryBlock* packet) 
{
  // XXX! hack:
  if (ifaceIndex<-100) {
    unsigned char* newPacket = (unsigned char*) malloc(address.getNetSize() 
						       + packet->size);
    address.toNet(newPacket);
    memcpy(newPacket+address.getNetSize(), packet->data, packet->size);
    free(packet->data);
    packet->data = newPacket;
    packet->size += address.getNetSize();
  }

  LowLevel::socketSend(outputSocket, packet->data, packet->size, 
		       sendSystemAddress);
  delete packet; // XXX: check memory is freed
}

#ifdef LINK_MONITORING
template<class LowLevel>
int LinuxSystemIface<LowLevel>::getSignalLevel(Address txAddress)
{
  typename LowLevel::SystemAddress ifaceSystemAddress;
  addressFactory->makeSystemAddress(txAddress, ifaceSystemAddress);
  
  return LowLevel::recvSignalNoise(signalSocket,
				   associatedIface->getSystemIface(),
				   ifaceSystemAddress);
}
#endif

template<class LowLevel>
void LinuxSystemIface<LowLevel>::handleInput()
{
  octet buffer[65536]; // XXX: not inline
  typename LowLevel::SystemAddress recvAddress;
  
  int maxSize = sizeof(buffer);
  int status = LowLevel::socketRecv(inputSocket, buffer, 
				    maxSize, recvAddress);
  if(status > 0) { // XXX: what if == 0, closed?
    MemoryBlock* packet = NULL;
    
    Address stdRecvAddress = addressFactory->makeAddress(recvAddress);
    
    // XXX! hack:
    if (ifaceIndex<-100) {
      stdRecvAddress = addressFactory->peekAddress(buffer);
      packet = new MemoryBlock(buffer+address.getNetSize(), 
			       status-address.getNetSize(), true);
    } else {
      packet = new MemoryBlock(buffer, status, true);
    }    
    packetReceiver->evReceivePacket 
      (packet, stdRecvAddress, this->associatedIface);
  }
}

//---------------------------------------------------------------------------

//#define USE_SYSTEM_IP_ROUTE // XXX: one bug still

void startHTTPServer(IOScheduler* scheduler, Node* node); // forward

//---------------------------------------------------------------------------

#ifndef WITH_IPV4
ISystemFactory* getIPv4SystemFactory(ProtocolConfig* protocolConfig)
{ return NULL; }
#endif

#ifndef WITH_IPV6
ISystemFactory* getIPv6SystemFactory(ProtocolConfig* protocolConfig)
{ return NULL; }
#endif

//---------------------------------------------------------------------------

#ifdef WITH_HTTPSERVER // XXX: this is a hack
IHTTPServer* httpServer = NULL;
extern IHTTPServer* makeHTTPServer();
extern string makeHTMLErrorTemplate(Node* node);

#include "node.h" // XXX
void startHTTPServer(IOScheduler* scheduler, Node* node)
{
  httpServer = makeHTTPServer();
  httpServer->setHTMLErrorTemplate(makeHTMLErrorTemplate(node));
  httpServer->open(scheduler, node->getProtocolConfig()->httpAdminPort,
		   new ProtocolHTTPVisitor(node) /*XXX: leak*/);
}
#else // !WITH_HTTPSERVER
void startHTTPServer(IOScheduler* scheduler, Node* node)
{ /* do nothing */ }
#endif // WITH_HTTPSERVER

//---------------------------------------------------------------------------

#ifdef LINK_MONITORING

//#include "iwevent_client.cc"

IIweventClient* iweventClient = NULL;
extern IIweventClient* makeIWEVENTClient(Node* node);

//#include "node.h" // XXX
void startIWEVENTClient(IOScheduler* scheduler, Node* node)
{
  iweventClient = makeIWEVENTClient(node);
  iweventClient->open(scheduler, NULL);
}

#else 
void startIWEVENTClient(IOScheduler* scheduler, Node* node)
{
}
#endif // LINK_MONITORING

//---------------------------------------------------------------------------
// Because of C++ and C++ compiler implementations shortcomings (about
// templates instantiation), we include directly:

#ifdef WITH_IPV4
#include "system_linux_ipv4.cc"
//template class LinuxSystemIface<LinuxIPv4LowLevel>;
#endif

#ifdef WITH_IPV6
#include "system_linux_ipv6.cc"
#endif

//---------------------------------------------------------------------------
