//---------------------------------------------------------------------------
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// This file implements the Routing Table Calculation
//---------------------------------------------------------------------------

#include "base.h"
#include "node.h"

#include "route_algorithm.cc"

//---------------------------------------------------------------------------

#ifndef NO_STAT
extern double getTimeOfDay();
int statRouteCalculation = 0; // XXX: elsewhere
double statRouteCalculationTime = 0.0;
double statRouteCalculationFullTime = 0.0;
#endif


/// [RoutingTableCalculation] This method is called when the OLSR Node 
/// is started.
void Node::startRoutingTableCalculation()
{ 
  shouldRecomputeRoute = false;
}

/// [RoutingTableCalculation] Recompute the routing table
// @@2583-2784
void Node::computeRoutingTable()
{ 
  RoutingTable* newRoutingTable = NULL;
  D(*log, lAction, getRealTime() << " [action] " << getId()
    << " computeRoutingTable" << endl);
#ifndef NO_STAT
  double startTime = getTimeOfDay();
  statRouteCalculation++;
#endif

  bool shouldReallyComputeTable =
    (protocolConfig->routeCalculationStartTime < 0.0)
    || (getCurrentTime() > protocolConfig->routeCalculationStartTime);

#ifdef NU_AUTOCONF // {DAD}
  shouldReallyComputeTable &= (_getAutoConfState() == STATE_NORMAL);
#endif

  if (shouldReallyComputeTable) {
   #if !defined(ROUTE_OPT)
    newRoutingTable = slowerComputeRoutingTable(); // always available
   #else
    if (protocolConfig->fastRouteCalculation) {
      if (!ifaceAssociationSet.empty()
	  || getAddressList()->size() > 1) { // Not for multiple interfaces
	Warn("Cannot use fast routing table calculation because of "
	     " non-empty ifaceAssociationSet or multiple interfaces"
	     "... falling back to slowerComputeRoutingTable().");
	newRoutingTable = slowerComputeRoutingTable();
      } else newRoutingTable = fasterComputeRoutingTable();
    } else newRoutingTable = slowerComputeRoutingTable();
   #endif
  } else newRoutingTable = new RoutingTable(this); // (empty table)

#ifndef NO_STAT
  statRouteCalculationTime += (getTimeOfDay() - startTime);
#endif

  if (! protocolConfig->noRouteSetup)
    _setRoutingTable(newRoutingTable);

#ifndef NO_STAT
  statRouteCalculationFullTime += (getTimeOfDay() - startTime);
#endif
}

/// [RoutingTableCalculation] Recompute the routing table
// @@2583-2784
RoutingTable* Node::slowerComputeRoutingTable()
{ 
#ifdef ROUTE_OPT
  // Build a table of symetric neighbors
  AddressMap<bool> isSymmetricNeighborTable;
  for(NeighborSet::TupleIterator it = neighborSet.getIter(); 
      !it.isDone(); it.next())
    {
      NeighborTuple* neighborTuple = it.getCurrent();
      if (neighborTuple->N_status == SYM)
	isSymmetricNeighborTable.add(neighborTuple->N_neighbor_main_addr,
				     true);
    }
#endif
  
  // Step 1 - @@2648
  RoutingTable* routingTable = new RoutingTable(this);

  // Step 2
  for(NeighborSet::TupleIterator it = neighborSet.getIter(); !it.isDone(); 
      it.next()) { 
    NeighborTuple* neighborTuple = it.getCurrent();
    LinkTuple* lastLinkTuple = NULL;
    bool isMainAddressReached = false;
    if (neighborTuple->N_status == SYM) { // @@2654
      for(NeighborTuple::AssociatedLinkIterator lit =  // @@2656-2657
	    neighborTuple->getAssociatedLinkIterator(); 
	  !lit.isDone(); lit.next()) {
	LinkTuple* linkTuple = lit.getCurrent();
	if (linkTuple->getStatus() == SYM_LINK) { // @@2657-2658
	  routingTable->addRoutingEntry
	    ( linkTuple->L_neighbor_iface_addr, // @@2661-2662
	      linkTuple->L_neighbor_iface_addr, // @@2664-2665
	      1, // @@2667
	      linkTuple->L_local_iface_addr ); // @@2669-2670
	  lastLinkTuple = linkTuple; // XXX: should select the oldest SYM link
	  if (linkTuple->L_neighbor_iface_addr
	      ==  neighborTuple->N_neighbor_main_addr) // @@2672-2673
	    isMainAddressReached = true;
	}
      }
    
      if (!isMainAddressReached) { // @@2672-2673
	assert( lastLinkTuple != NULL ); // associated link tuple is guaranted
	routingTable->addRoutingEntry
	  ( neighborTuple->N_neighbor_main_addr, // @@2676
	    lastLinkTuple->L_neighbor_iface_addr, // @@2678-2680
	    1, // @@2682
	    lastLinkTuple->L_local_iface_addr ); // @@2684-2685
      }
      
    }
  }

  // Step 3
  
  AddressMap<TwoHopNeighborTuple*> reachableTwoHopTable;
  // XXX:AUTOCONF assert( R_next_addr == STATE_NORMAL OR == R_dest_addr)

  // Select the candidate two hop neighbors
  for(TwoHopNeighborSet::TupleIterator // @@2695
	it = twoHopNeighborSet.getIter(); !it.isDone(); it.next()) {
    TwoHopNeighborTuple* twoHop = it.getCurrent();
#ifdef NU_AUTOCONF // {DAD}
    // Don't route with a two hop neighbor which is not in state normal
    if (stateSet.ensure(twoHop->N_neighbor_main_addr)->S_state != STATE_NORMAL)
      continue;
#endif // NU_AUTOCONF
    Address address = twoHop->N_2hop_addr;
#ifdef ROUTE_OPT
    if (isSymmetricNeighborTable.get(address, false) 
	|| address == getMainAddress()) 
      continue; // @@2695-2696
#else
    if (isSymmetricNeighbor(address) || address == getMainAddress()) 
      continue; // @@2695-2696
#endif // ROUTE_OPT
    NeighborTuple* neighborTuple = 
      neighborSet.findFirst_MainAddr(twoHop->N_neighbor_main_addr);
    assert( neighborTuple != NULL ); // XXX: proove
    if (neighborTuple->N_willingness == WILL_NEVER) // @@2696-2698 
      continue;
    // XXX: this will choose the first possible two hop neighbor
    if (reachableTwoHopTable.get(address) == NULL) {
      reachableTwoHopTable.add(address, twoHop);
    }
  }
  
  // Actually set up the routes to two hop neighbors
  for(AddressMap<TwoHopNeighborTuple*>::Iterator it =
	reachableTwoHopTable.getIter(); !it.isDone(); it.next()) {
    TwoHopNeighborTuple* twoHop = it.getCurrent().second;
    RoutingTuple* routingTuple // @@2707-2708, @@2715-2716
      = routingTable->findFirst_Destination(twoHop->N_neighbor_main_addr);
    assert( routingTuple != NULL ); // XXX: prove it
    routingTable->addRoutingEntry
      ( twoHop->N_2hop_addr, // @@2702
	routingTuple->R_next_addr, // @@2704-2708
	2, // @@2710
	routingTuple->R_iface_addr); // @@2712-2716
  }
  
  // Step 3bis (RFC has two steps 3)
  bool tableChanged = true;
  int h = 2; // @@2721
  while(tableChanged) {
    tableChanged = false;
    
    // Step 3.1
    for(TopologySet::TupleIterator it = topologySet.getIter(); // @@2725
	!it.isDone(); it.next()) {
      TopologyTuple* topologyTuple = it.getCurrent();
      // XXX!!! remove ourself
      if (topologyTuple->T_dest_addr == getMainAddress())
       	continue;

#ifdef NU_AUTOCONF // {DAD}
      if (stateSet.ensure(topologyTuple->T_last_addr)->S_state
	  != STATE_NORMAL)
	continue; // don't route thru a node which is not in the state normal
#endif // NU_AUTOCONF

      RoutingTuple* routingTuple // @@2732
	= routingTable->findFirst_Destination(topologyTuple->T_dest_addr);
      if (routingTuple != NULL) 
	continue; // already exists @@2730

      routingTuple // @@2725-2727
	= routingTable->findFirst_Destination(topologyTuple->T_last_addr);
      if (routingTuple == NULL)
	continue; // no route to T_last_addr @@2727-2728
      if (routingTuple->R_dist != h) // XXX: prove that there is only with h
	continue; // @@2728-2729

      tableChanged = true; // @@2722-2723
      routingTable->addRoutingEntry
	( topologyTuple->T_dest_addr, // @@2732
	  routingTuple->R_next_addr, // @@2734-2737
	  h+1, // @@2739
	  routingTuple->R_iface_addr ); // @@2751-2754
    }

    // Step 3.2: XXX "should be" is not implemented

    h++; // @@2722
  }

  // Step 4
  for(IfaceAssociationSet::TupleIterator it = ifaceAssociationSet.getIter();
      !it.isDone(); it.next()) {
    IfaceAssociationTuple* ifaceAssociationTuple = it.getCurrent();
    RoutingTuple* routingTuple = // @@2764-2765
      routingTable->findFirst_Destination(ifaceAssociationTuple->I_main_addr);
    if (routingTuple == NULL) 
      continue; // @@2761-2765
    RoutingTuple* ifaceRoutingTuple = // @@2769
      routingTable->findFirst_Destination(ifaceAssociationTuple->I_iface_addr);
    if (ifaceRoutingTuple != NULL)
      continue; // @@2767-2769
    
    routingTable->addRoutingEntry
      ( ifaceAssociationTuple->I_iface_addr, // @@2773-2774
	routingTuple->R_next_addr, // @@2776-2777
	routingTuple->R_dist, // @@2779-2780
	routingTuple->R_iface_addr); // @@2782-2783
  }

#ifdef NU_AUTOCONF // {DAD}
  // Note: the HNA are still be used to route thru node which are not
  // in state STATE_NORMAL...
#endif
  // Additional step12.6
  // @@XXX
  // XXX!!! the RFC assumes that we can reach next hop...
  for (HNASet::TupleIterator it = hnaSet.getIter(); !it.isDone(); it.next()) {
    HNATuple* hnaTuple = it.getCurrent();
    RoutingTuple* nextHopRoutingTuple = 
      routingTable->findFirst_Destination(hnaTuple->A_gateway_addr);
    if (nextHopRoutingTuple != NULL) {
      RoutingTuple* routingTuple =  //@@XXX
	routingTable->findFirst_Destination_Mask(hnaTuple->A_network_addr,
						 hnaTuple->A_netmask);
      if (routingTuple == NULL) { // step 1 - @@XXX
	routingTable->addRoutingNetEntry(hnaTuple->A_network_addr,
					 hnaTuple->A_netmask,
					 nextHopRoutingTuple->R_next_addr,
					 nextHopRoutingTuple->R_dist,
					 nextHopRoutingTuple->R_iface_addr);
      } else {
	// step 2 - @@XXX
	if (routingTuple->R_dist > nextHopRoutingTuple->R_dist) {
	  // Change routing tuple @@XXX
	  routingTuple->R_dist = nextHopRoutingTuple->R_dist;
	  routingTuple->R_next_addr = nextHopRoutingTuple->R_next_addr;
	  routingTuple->R_iface_addr = nextHopRoutingTuple->R_iface_addr;
	}
      }
    }
  }
  return routingTable;
}

/// [RoutingTableCalculation] (internal) Empties the current routing table.
void Node::_setRoutingTable(RoutingTable* routingTable)
{ 
  AddressMap<ISystemIface*> addressToIface;

  std::list<OLSRIface*>* olsrIfaceList = getIfaceList();
  for(std::list<OLSRIface*>::iterator it = olsrIfaceList->begin();
      it != olsrIfaceList->end(); it++)
    addressToIface.add( (*it)->getAddress(), (*it)->getSystemIface() );

  // Remove changed or removed routes
  assert(currentRoutingTable != NULL);
  for(RoutingTable::TupleIterator it = currentRoutingTable->getIter();
      !it.isDone(); it.next()) {
    RoutingTuple* previousRoutingTuple = it.getCurrent();
    RoutingTuple* currentRoutingTuple 
      = routingTable->findFirst_Same(previousRoutingTuple);
    if (currentRoutingTuple == NULL) {
      // Remove the route
      ISystemIface* iface = addressToIface.get
	(previousRoutingTuple->R_iface_addr, NULL);
      if (iface == NULL) {
	// XXX!!!: huge hack
	D(*log, lRoute, getRealTime() 
	  << " [route] " << getId() << 
	  " IGNORE-del: [" << previousRoutingTuple->R_iface_addr << "->]" 
	  << previousRoutingTuple->R_next_addr << "->" 
	  << previousRoutingTuple->R_dest_addr << "(" 
	  << previousRoutingTuple->R_dist << ")" << endl );
      } else {

	assert( iface != NULL ); // XXX: prove
	
	D(*log, lRoute, getRealTime() 
	  << " [route] " << getId() << 
	  " del: [" << previousRoutingTuple->R_iface_addr << "->]" 
	  << previousRoutingTuple->R_next_addr << "->" 
	  << previousRoutingTuple->R_dest_addr << "(" 
	  << previousRoutingTuple->R_dist << ")" << endl );
	
	networkConfigurator->removeRoute
	  (iface,
	   previousRoutingTuple->R_dest_addr,
	   previousRoutingTuple->R_next_addr,
	   previousRoutingTuple->R_dest_mask_addr,
	   previousRoutingTuple->R_dist);
      }
    }
  }
  
  list<RoutingTuple*> neighborRoute; // XXX: rename
  list<RoutingTuple*> twoHopOrMoreRoute;

  for(RoutingTable::TupleIterator it = routingTable->getIter();
      !it.isDone(); it.next()) {
    RoutingTuple* routingTuple = it.getCurrent();
    if (routingTuple->R_dist<=1)
      neighborRoute.push_back(routingTuple);
    else twoHopOrMoreRoute.push_back(routingTuple);
  }  

  for(std::list<RoutingTuple*>::iterator it = twoHopOrMoreRoute.begin();
      it != twoHopOrMoreRoute.end(); it++)
    neighborRoute.push_back(*it);

  //for(RoutingTable::TupleIterator it = routingTable->getIter();
  //    !it.isDone(); it.next()) {
  //  RoutingTuple* routingTuple = it.getCurrent();
  for(std::list<RoutingTuple*>::iterator it = neighborRoute.begin();
      it != neighborRoute.end(); it++) {
    RoutingTuple* routingTuple = *it;
    RoutingTuple* previousRoutingTuple = NULL;
    assert (currentRoutingTable != NULL);
    previousRoutingTuple 
      = currentRoutingTable->findFirst_Same(routingTuple);
    if (previousRoutingTuple == NULL) {
      // It is new: add the route
      ISystemIface* iface 
	= addressToIface.get(routingTuple->R_iface_addr, NULL);

      if (iface == NULL) {
	// XXX!!!: huge hack
	D(*log, lRoute, getRealTime() 
	  << " [route] " << getId() << 
	  " IGNORE-add: [" << routingTuple->R_iface_addr << "->]" 
	  << routingTuple->R_next_addr << "->" 
	  << routingTuple->R_dest_addr << "(" << routingTuple->R_dist << ")" 
	  << endl );

      } else {
	D(*log, lRoute, getRealTime() 
	  << " [route] " << getId() << 
	  " add: [" << routingTuple->R_iface_addr << "->]" 
	  << routingTuple->R_next_addr << "->" 
	  << routingTuple->R_dest_addr << "(" << routingTuple->R_dist << ")" 
	  << endl );

	networkConfigurator->addRoute(iface,
				      routingTuple->R_dest_addr,
				      routingTuple->R_next_addr,
				      routingTuple->R_dest_mask_addr,
				      routingTuple->R_dist);
      }
    }
  }
  
  delete currentRoutingTable;
  currentRoutingTable = routingTable;
}

/// Add a routing entry in the routing table
void RoutingTable::addRoutingNetEntry(Address dest, Address destMask,
				      Address next, int dist,
				      Address ifaceAddress)
{ 
  RoutingTuple* routingTuple = new RoutingTuple;
  routingTuple->R_dest_addr = dest;
  routingTuple->R_dest_mask_addr = destMask;
  routingTuple->R_next_addr = next;
  routingTuple->R_dist = dist;
  routingTuple->R_iface_addr = ifaceAddress;
  add(routingTuple);

#if 0 
  // XXX: remove, done in add(...), now
  std::list<RoutingTuple*>* routeList = addressToRoutingTupleList.get(dest);
  if (routeList == NULL) {
    std::list<RoutingTuple*> newRouteList;
    addressToRoutingTupleList.add(dest, newRouteList);
    routeList = addressToRoutingTupleList.get(dest);
    assert( routeList != NULL );
  }
  routeList->push_back(routingTuple);
#endif
}

void RoutingTable::addRoutingEntry(Address dest,
				   Address next, int dist,
				   Address ifaceAddress)
{
  Address nullAddress;
  addRoutingNetEntry(dest, nullAddress, next, dist, ifaceAddress);
}

//---------------------------------------------------------------------------

void RoutingTable::write(ostream& out)
{
  bool isFirst = true;
  for(RoutingTable::TupleIterator it = getIter(); !it.isDone(); it.next()) {
    if (!isFirst) out << ";";
    else isFirst = false;

    RoutingTuple* t = it.getCurrent();
    out << t->R_iface_addr << "->" << t->R_next_addr << "->"
	<< t->R_dest_addr << "/" << t->R_dest_mask_addr 
	<< "(" << t->R_dist << ")";
  }
}

//---------------------------------------------------------------------------

RoutingTable::~RoutingTable()
{
  RoutingTable::TupleIterator it = getIter(); 
  while(!it.isDone())
    it.removeAndDeleteCurrentAndDoNext();
}

//---------------------------------------------------------------------------

RoutingTable* Node::fasterComputeRoutingTable()
{ 
#ifdef NU_AUTOCONF // {DAD}
  Fatal("Fast route computation has not been updated for NU_AUTOCONF");
#endif
  RouteAlgorithm algorithm;

  AddressMap<int> addressToIdx;
  AddressMap<bool> willNeverTable;

#if 0
  list<Address>& myIfaceAddressList = getIfaceAddressList();
  for (list<Address>::iterator it = myIfaceAddressList.begin();
       it != myIfaceAddressList.end(); it++) {
    int idx = addNode();
    addressToIdx.add(*it, idx);
    addStartingNode(idx);
  }
#endif
  
  Address mainAddress = getMainAddress();
  int myIdx = algorithm.addNode(&mainAddress);
  addressToIdx.add(getMainAddress(), myIdx);
  algorithm.addStartingNode(myIdx);

#if 0
  // no need
  for (LinkTuple* linkTuple = it.getCurrent(); !it.isDone(); it.next()) {
    assert( (*it)->L_local_iface_addr == getMainAddress() );
    if (linkTuple._getStatus() == SYM_LINK) {
      Address otherAddress = (*it)->L_neighbor_iface_addr; 
      assert (addressToIdx.find(otherAddress, NULL) == NULL);
      addressToIdx.add(otherAddress, addNode());
    }
  }
#endif

  for (NeighborSet::TupleIterator it = neighborSet.getIter(); 
       !it.isDone(); it.next())
    {
      NeighborTuple* neighborTuple = it.getCurrent();
      if (neighborTuple->N_status == SYM) {
	int idx = algorithm.addNode(&neighborTuple->N_neighbor_main_addr);
	assert( addressToIdx.get(neighborTuple->N_neighbor_main_addr) 
		== NULL );
	addressToIdx.add(neighborTuple->N_neighbor_main_addr, idx);
	algorithm.addLink(myIdx, idx);
	bool excludeNeighbor = (neighborTuple->N_willingness == WILL_NEVER);
#ifdef NU_AUTOCONF // {DAD} not documented but not standard and not used anyway
	excludeNeighbor |= 
	  (stateSet.ensure(neighborTuple->N_neighbor_main_addr)->S_state
	   != STATE_NORMAL);
#endif
	if (excludeNeighbor)
	  willNeverTable.add(neighborTuple->N_neighbor_main_addr, true);
      }
    }
 
  // Step 3  
  AddressMap<TwoHopNeighborTuple*> reachableTwoHopTable;

  // Select the candidate two hop neighbors
  for(TwoHopNeighborSet::TupleIterator // @@2695
	it = twoHopNeighborSet.getIter(); !it.isDone(); it.next()) {
    TwoHopNeighborTuple* twoHop = it.getCurrent();
    Address address = twoHop->N_2hop_addr;

    if (twoHop->N_neighbor_main_addr == getMainAddress())
      continue; // remove ourself (XXX: check in normal calculation)

    int* oneHopIdx = addressToIdx.get(twoHop->N_neighbor_main_addr);
    assert( oneHopIdx != NULL );

    if (addressToIdx.get(address) != NULL)
      continue; // @@2695-2696
    if (willNeverTable.get(twoHop->N_neighbor_main_addr, false))
      continue;

    int* twoHopIdx = addressToIdx.get(address); 
    if (twoHopIdx == NULL) {
      addressToIdx.add(address, algorithm.addNode(&twoHop->N_2hop_addr));
      twoHopIdx = addressToIdx.get(address); 
      assert( twoHopIdx != NULL );
    }
    algorithm.addLink(*oneHopIdx, *twoHopIdx);
  }


  for(TopologySet::TupleIterator it = topologySet.getIter();
      !it.isDone(); it.next()) {
    TopologyTuple* topologyTuple = it.getCurrent();

    if (topologyTuple->T_dest_addr == getMainAddress())
      continue;

    int* firstIdx = addressToIdx.get(topologyTuple->T_last_addr); 
    if (firstIdx == NULL) {
      addressToIdx.add(topologyTuple->T_last_addr, 
		       algorithm.addNode(&topologyTuple->T_last_addr));
      firstIdx = addressToIdx.get(topologyTuple->T_last_addr);
      assert( firstIdx != NULL );
    }

    int* secondIdx = addressToIdx.get(topologyTuple->T_dest_addr); 
    if (secondIdx == NULL) {
      addressToIdx.add(topologyTuple->T_dest_addr, 
		       algorithm.addNode(&topologyTuple->T_dest_addr));
      secondIdx = addressToIdx.get(topologyTuple->T_dest_addr);
      assert( secondIdx != NULL );
    }

    algorithm.addLink(*firstIdx, *secondIdx); // XXX: maybe duplicate link
  }

  algorithm.breadthFirst();

  RoutingTable* routingTable = new RoutingTable(this);
  for (AddressMap<int>::Iterator it = addressToIdx.getIter();
       !it.isDone();it.next()) {
    GraphNode& graphNode = (algorithm.nodeInfoArray[(*it).second]); // XXX
    if (graphNode.distance == 0 || graphNode.distance == MaxDistance)
      continue; // this node = no next hop anyway
    GraphNode& otherGraphNode = 
      (algorithm.nodeInfoArray[graphNode.nextHop[1]]); // XXX
    Address dest = *(Address*) graphNode.data;
    Address nextHop = *(Address*) otherGraphNode.data;
    dest == nextHop;
    routingTable->addRoutingEntry(dest, nextHop, graphNode.distance, 
				  mainAddress);
  }

  return routingTable;
}

//---------------------------------------------------------------------------
