#---------------------------------------------------------------------------
#                                OOLSR
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
#  Copyright 2004 Institut National de Recherche en Informatique et
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------

import time, os, sys, re

#---------------------------------------------------------------------------

SourceFile = "template_protocol_config.h"

info = {}
execfile("parameters.def", info, info)

parameterList = info["ParameterList"]

f = open("../include/" + SourceFile)
template = f.read()
f.close()

s = template.replace("<GENERATED>",
                     "Parts of this file automatically were generated")
s = s.replace("<DATE>", time.asctime())
s = s.replace("<USER>", os.environ.get("USER", "???"))
s = s.replace("<COMMAND>", " ".join(sys.argv))
s = s.replace("<TEMPLATE>", SourceFile)


# XXX:TODO: merge the 3 cases in one
ifaceFieldStr = ""
configFieldStr = ""
logFieldStr = ""

ifaceParseStr = ""
configParseStr = ""
logParseStr = ""

ifaceOutStr = []
configOutStr = []
logOutStr = []

def internalConfigName(name):
    m = re.match("^[A-Z_]+$", name)
    if m:
        nameList = name.split("_")
        nameList = [ x.lower() for x in nameList ]
        return "-".join(nameList)
    else:
        nameList = name.split("_")
        name = "-".join(nameList)
        nameList = re.split("([A-Z])", name)
        name = nameList[0]
        for i in range(1,len(nameList),2):
            name += "-" + nameList[i].lower() + nameList[i+1]
        return name

def configName(name):
    result = internalConfigName(name)
    if result.startswith("l-"):
        result = "log-" + result[2:]
    return result
        
#def cxxName(name):
#    name.split("_")
Translate = { "float" : "double", "boolean": "bool", "int": "int",
              "list:address" : "std::list<Address>", "string": "string",
              "hnaList" : "std::list< std::pair<string,string> >" }

CXXParseFunc = { "float" : "parseFloat", "boolean": "parseBool",
                 "int" : "parseInt", "list:address": "parseAddressList",
                 "string": "parseString",
                 "hnaList" : "parseHNAList" } 

configDefaultStr = ""
ifaceDefaultStr = ""
logDefaultStr = ""

logAllDefaultStr = ""

ifaceCommentList = []
logCommentList = []
configCommentList = []

for name, kind, defaultValue, comment in parameterList:
    #print name, configName(name)
    if kind.startswith("*"):
        # Per interface configuration value
        kind = kind[1:]
        ifaceFieldStr += "  %s %s;\n" % (Translate[kind], name)
        ifaceParseStr += ('else if (data[0] == "%s") {\n' % configName(name)
          + "      %s = %s(data[1]);\n    } " % (name, CXXParseFunc[kind]))
        if defaultValue != None:
            ifaceDefaultStr += "    %s = %s;\n" % (name, defaultValue)
        ifaceOutStr += [ ' << "%s " << %s ' % (configName(name), name) ]
        ifaceCommentList.append( (configName(name), defaultValue, name, comment) )
    elif kind.startswith("+"):
        # Log configuration value
        kind = kind[1:]
        logFieldStr += "  %s %s;\n" % (Translate[kind], name)
        configParseStr += ('else if (data[0] == "%s") {\n' % configName(name)
          + "      log.%s = %s(data[1]);\n    } " % (name, CXXParseFunc[kind]))
        if defaultValue != None:
            logDefaultStr += "    %s = %s;\n" % (name, defaultValue)
        logAllDefaultStr += "    %s = value;\n" % (name,)            
        logOutStr += [ ' << "%s " << %s ' % (configName(name), name) ]
        logCommentList.append( (configName(name), defaultValue, name, comment) )
    else:
        # General configuration value
        configFieldStr +=  "  %s %s;\n" % (Translate[kind], name)
        configParseStr += ('else if (data[0] == "%s") {\n' % configName(name)
          + "      %s = %s(data[1]);\n    } " % (name, CXXParseFunc[kind]))
        # XXX: should set error if too many arguments...
        if defaultValue != None:
            configDefaultStr += "    %s = %s;\n" % (name, defaultValue)
        configOutStr += [ ' << "%s " << %s ' % (configName(name), name) ]
        configCommentList.append( (configName(name), defaultValue, name, comment) )        

configOutStr = ' << "; " '.join(configOutStr)
logOutStr = ' << "; " '.join(logOutStr)
ifaceOutStr = ' << "; " '.join(ifaceOutStr)

s = s.replace("<GEN_IFACE_CONF_FIELD>", ifaceFieldStr)
s = s.replace("<GEN_CONF_FIELD>", configFieldStr)
s = s.replace("<GEN_LOG_FIELD>", logFieldStr)

s = s.replace("<GEN_IFACE_CONF_PARSE_CODE>", ifaceParseStr)
s = s.replace("<GEN_CONF_PARSE_CODE>", configParseStr)
s = s.replace("<GEN_LOG_PARSE_CODE>", logParseStr)

s = s.replace("<GEN_IFACE_DEFAULT>", ifaceDefaultStr)
s = s.replace("<GEN_CONF_DEFAULT>", configDefaultStr)
s = s.replace("<GEN_LOG_DEFAULT>", logDefaultStr)

s = s.replace("<GEN_LOG_ALL_DEFAULT>", logAllDefaultStr)

s = s.replace("<GEN_IFACE_OUTPUT>", ifaceOutStr)
s = s.replace("<GEN_CONF_OUTPUT>", configOutStr)
s = s.replace("<GEN_LOG_OUTPUT>", logOutStr)

s = s.replace("<NOMOD>", "DO NOT MODIFY THIS FILE - CHANGES COULD BE LOST"
              "\n// - SINCE IT WAS AUTOMATICALLY GENERATED")

f = open("gen_protocol_config.h", "w")
f.write(s)
f.close()

def texEscape(x):
    return x.replace("_", r"\_").replace("%", r"\%").replace(">", "$>$")

def tableToTex(data):
    r = "\\begin{longtable}{|c|c|p{2in}|}\hline \n"
    #r += " a & b & c \\ \hline \hline \endhead"
    for name, value, cxxName,  comment in data:
        if type(value) != type("string"):
            value = "%s" % value
        else: value = value.strip('"')
        r += "{\\small "+texEscape(name)+"}" + " & "+ \
             texEscape(value) +" & "+ \
             texEscape(comment) + "\\\\ \\hline \n"
    r += "\\end{longtable}\n"
    return r

def tableToHTML(data):
    r = "<table border='1'>\n"
    #r += " a & b & c \\ \hline \hline \endhead"
    for name, value, cxxName,  comment in data:
        if type(value) != type("string"):
            value = "%s" % value
        else: value = value.strip('"')
        r += "<tr><td>"+texEscape(name)+"</td>" + "<td> "+ \
             texEscape(value) +" </td> <td>"+ \
             texEscape(comment) + "</td></tr> \n"
    r += "</table>"
    return r


f = open("gen_parameter_doc.tex", "w")
f.write("""% Automatically generated -- DON'T MODIFY\n""")
f.write("Table of general configuration options:\n")
f.write(tableToTex(configCommentList))
f.write("Table of 'per interface' configuration options:\n")
f.write(tableToTex(ifaceCommentList))
f.write("Table of trace/log options:\n")
f.write(tableToTex(logCommentList))
f.close()

f = open("gen_parameter_doc.html", "w")
f.write("""<html>""")
f.write("<h1>Table of general configuration options</h1>\n")
f.write(tableToHTML(configCommentList))
f.write("<h1>Table of 'per interface' configuration options</h1>\n")
f.write(tableToHTML(ifaceCommentList))
f.write("<h1>Table of trace/log options</h1>\n")
f.write(tableToHTML(logCommentList))
f.write("</html>")
f.close()


#---------------------------------------------------------------------------
