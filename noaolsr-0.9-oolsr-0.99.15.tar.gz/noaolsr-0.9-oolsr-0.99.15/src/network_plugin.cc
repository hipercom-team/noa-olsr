//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// Empty file, everything is in network_plugin.h
//---------------------------------------------------------------------------

#include "network_plugin.h"

  /// Add one route in the kernel
void PluginNetworkConfigurator::addRoute
(ISystemIface* iface, Address destIpAddress,
 Address gatewayAddress, Address netMaskAddress, 
 int metric)
{ 
  PPA_Route route;
  route.localInterfaceAddress = iface->getAddress().getRawAddress();
  route.nextHopInterfaceAddress = gatewayAddress.getRawAddress();
  route.destinationAddress = destIpAddress.getRawAddress();
  route.distance = metric;
  plugeeApi->configureRouteFunction(plugeeNode, &route, PPA_ADD_ROUTE);
  //cout << "addRoute: " << iface->getAddress() << "->" // XXX: remove
  //<< gatewayAddress << "->" << destIpAddress << endl; 
}
  
/// Remove one route from the kernel // XXX: factor the two methods
void PluginNetworkConfigurator::removeRoute
(ISystemIface* iface, Address destIpAddress,
 Address gatewayAddress, Address netMaskAddress, 
 int metric)
{ 
  PPA_Route route;
  route.localInterfaceAddress = iface->getAddress().getRawAddress();
  route.nextHopInterfaceAddress = gatewayAddress.getRawAddress();
  route.destinationAddress = destIpAddress.getRawAddress();
  route.distance = metric;
  plugeeApi->configureRouteFunction(plugeeNode, &route, PPA_DEL_ROUTE);  
  //cout << "delRoute: " << iface->getAddress() << "->" // XXX: remove
  //	    << gatewayAddress << "->" << destIpAddress << endl; 
}

//---------------------------------------------------------------------------

