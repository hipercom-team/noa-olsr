#include <stdlib.h> // drand48

#include <sys/time.h>
#include <stdio.h>

#include "general.h"

//---------------------------------------------------------------------------

#ifdef NEWRAND

double drawDouble(double maxValue)
{ return genrand_real2()*maxValue; }

#else

 /// Draw a random number (double) between 0 (incl.) and maxValue (excl.)
double drawDouble(double maxValue)
{ return random()/(double)(RAND_MAX)*maxValue; }

#endif

double getTimeOfDay()
{
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec/1e6;
}

