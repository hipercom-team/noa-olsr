//---------------------------------------------------------------------------
//                             OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
//#include <dlsym.h>
#include "mystream.h"

#include <protocol-plugin-api.h> // XXX: filename

extern "C" int protocolPluginApiInit
(int major, int minor, 
 PPA_PlugeeApi* aSimulatorApi, 
 PPA_PluginApi** resultPluginApi);

extern "C" int doesRequirePlugin()
{
  return 0;
}

extern "C" void loadPlugin(char* fileName,
			   PPA_PlugeeApi* myApi, PPA_PluginApi** pluginApi)
{
  int status = protocolPluginApiInit(PPA_VERSION_MAJOR, PPA_VERSION_MINOR,
				     myApi, pluginApi);
  assert( fileName == NULL );
  if (status != PPA_OK) {
    cerr << "load-plugin: init function of plugin returned FAILURE";
    exit(EXIT_FAILURE);
  }
}

//---------------------------------------------------------------------------
