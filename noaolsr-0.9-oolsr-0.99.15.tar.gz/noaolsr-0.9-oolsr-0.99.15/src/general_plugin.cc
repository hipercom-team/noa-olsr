//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// Wrapper around OOLSR classes to match the plugin interface
//---------------------------------------------------------------------------

#include "base.h"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#include <sys/stat.h>
#include <sys/types.h>

//#include <stl.h>
#include <sstream>
#include <fstream>
#include "mystream.h"
#include <iomanip>

//--------------------------------------------------

#include <protocol-plugin-api.h>

//--------------------------------------------------

#include "general.h"
#include "log.h"
#include "scheduler_generic.h"
#include "scheduler_plugin.h"
#include "node.h"

#include "general_plugin.h"
#include "network_plugin.h"
#include "packet.h"

#include "simulation-api.h"

#ifdef NU_AUTOCONF
#include "nu_autoconf.h"
#endif

//---------------------------------------------------------------------------

PPA_PluginApi pluginProtocolApi;
PPA_PlugeeApi* simulatorApi = NULL;
PPA_OpaqueFunctionCall* simulatorOpaqueFunction = NULL;
int pluginAddressSize = -1;

class PluginScheduler;
PluginScheduler* pluginScheduler = NULL;

//---------------------------------------------------------------------------

void pluginSchedulerCallBack(void* data1, void* data2, void* data3)
{
  assert(data3 == NULL);
  ((IEvent*)data1)->handleEvent(data2);
  delete (IEvent*)data1;
}

//---------------------------------------------------------------------------

static PPA_Address simBroadcastAddress = NULL; // [Design Pattern] singleton
void* getBroadcastAddress() 
{
  if (simBroadcastAddress == NULL) {
    simBroadcastAddress = new octet[simulatorApi->addressSize];
    simulatorApi->getBroadcastAddressFunction(simBroadcastAddress);
  }
  return simBroadcastAddress;
}

void PluginIface::sendPacket(MemoryBlock* packet)
{
  PPA_Packet ppaPacket;
  ppaPacket.size = packet->size;
  ppaPacket.data = malloc(packet->size); // (allocated by malloc, not new)
  memcpy(ppaPacket.data, packet->data, packet->size);
  simulatorApi->sendPacketFunction(plugeeNode, 
				   address.getRawAddress(),
				   ifaceIndex,
				   getBroadcastAddress(), ppaPacket);
  delete packet;
}

//---------------------------------------------------------------------------

#ifdef WITH_MULTICAST_ENCAPSULATION
#include "general_encapsulation.cc"
#endif // WITH_MULTICAST_ENCAPSULATION

void* createNode(PPA_PlugeeNode simNode,
		 int nbIface,
		 /* borrowed: */ void** ifaceAddressArray,
		 int* mtuArray,
		 void* configData, int configSize)
{
  // XXX: check how to free all this.
  Node* node = new Node;
  PacketManager* packetManager = new PacketManager(node);
  ProtocolConfig* protocolConfig = new ProtocolConfig;
  Log* log = new Log;

  ConfigParser configParser;
  string configString = (char*)configData; // XXX: configSize
  configParser.parse(*protocolConfig, *log, configString);

  //SystemConfig* systemConfig = new SystemConfig;
  INetworkConfigurator* netConfig 
    = new PluginNetworkConfigurator(simNode, simulatorApi);
  std::vector<ISystemIface*> ifaceList;
  AddressFactory* addressFactory = 
    new AddressFactory(simulatorApi->addressSize);
  addressFactory->setAddressType("plugin-address");

#ifndef NOLOG
  if(!protocolConfig->noLog) {
    if (globalLog == NULL) { // XXX: should be done elsewhere
      globalLog = new Log;
      globalLog->out = createLogFile(protocolConfig->logFileName,
				     "global");
    }
    Address address = Address(addressFactory, ifaceAddressArray[0]);
    log->out = createLogFile(protocolConfig->logFileName,
			     toText(address));
  }
#endif

  for (int j=0;j<nbIface;j++) {
    // Create the j-th interface
    Address address = Address(addressFactory, ifaceAddressArray[j]);
    string ifaceName = "I0";
    ifaceName[1] = '0' + j; // ifaceName is I0, I1, I2, ...

    if (protocolConfig->ifaceConfig.count(ifaceName) == 0)
      protocolConfig->ifaceConfig[ifaceName] = new IfaceConfig;

    IfaceConfig* ifaceConfig = protocolConfig->ifaceConfig[ifaceName];
    ISystemIface* iface = new PluginIface
      (pluginScheduler,
       simNode, dynamic_cast<IPacketReceiver*>(node), 
       address, mtuArray[j], ifaceConfig, j);
    ifaceList.push_back(iface);
  }
  // Configure the node
  node->configure(dynamic_cast<IScheduler*>(pluginScheduler),
		  addressFactory, packetManager, 
		  netConfig,
		  protocolConfig,
		  ifaceList, log);

#ifdef WITH_MULTICAST_ENCAPSULATION
  if (protocolConfig->multicastType >= 0) {
    // XXX: should check it is different from HELLO etc...
    node->addMessageHandler(protocolConfig->multicastType,
			    new EMMessageHandler(node, simNode));
  }
#endif /* WITH_MULTICAST_ENCAPSULATION */

  return (void*)node;
}

void nodeStart(PPA_PluginNode protocolNode)
{ ((Node*)protocolNode)->start(); }

#if 0
// XXX: remove
PluginIface* getIfaceByInitialAddress(Node* node, Address initialAddress)
{
  list<OLSRIface*>* ifaceList = node->getIfaceList();
  for(list<OLSRIface*>::iterator it = ifaceList->begin();
      it != ifaceList->end();it++) {
    ISystemIface* systemIface = (*it)->getSystemIface();
    PluginIface* pluginIface = dynamic_cast<PluginIface*>(systemIface);
    if (pluginIface->getInitialAddress() == initialAddress) {
      return pluginIface;
    }
  }
  return NULL;
}
#endif

PluginIface* getIfaceByIndex(Node* node, int ifaceIndex)
{
  list<OLSRIface*>* ifaceList = node->getIfaceList();
  int currentIfaceIndex = 0;
  for(list<OLSRIface*>::iterator it = ifaceList->begin();
      it != ifaceList->end();it++) {
    ISystemIface* systemIface = (*it)->getSystemIface();
    PluginIface* pluginIface = dynamic_cast<PluginIface*>(systemIface);
    if (currentIfaceIndex == ifaceIndex) {
      return pluginIface;
    }
    currentIfaceIndex++;
  }
  return NULL;
}

void nodeReceive(PPA_PluginNode protocolNode,
		 PPA_Address ppaSenderAddress,
		 PPA_Address ppaReceiverAddress,
		 int receiverIfaceIndex,
		 PPA_Packet ppaPacket /* owned*/)
{
  Node* node = (Node*)protocolNode;
  MemoryBlock* packet = new MemoryBlock((octet*)ppaPacket.data, 
					ppaPacket.size, true);
  Address senderAddress(node->getAddressFactory(), ppaSenderAddress);
  Address receiverAddress(node->getAddressFactory(), ppaReceiverAddress);
#if 0
  // XXX: remove
  OLSRIface* iface =
    getIfaceByInitialAddress(node, receiverAddress)->getOLSRIface();
  //OLSRIface* iface = node->getIfaceByAddress(receiverAddress);
#endif
  OLSRIface* iface = getIfaceByIndex(node, receiverIfaceIndex)->getOLSRIface();

  assert( iface != NULL );
  node->evReceivePacket(packet, senderAddress, iface);
  free(ppaPacket.data); // (erased with free, not delete)
}


//---------------------------------------------------------------------------

void nodeWrite(PPA_PluginNode pluginNode, char** result)
{
  Node* node = (Node*)pluginNode;
  ostringstream* out = new ostringstream;
  (*out) << "[node] " << node->getId() << " ";
  (*out) << (*node->getProtocolConfig()) << endl;
  node->writeIfaceList(*out);
  node->logState(*out);
  out->flush();
  *result = strdup(out->str().c_str());
  delete out;
}

void nodeOutput(PPA_PluginNode pluginNode, char* fileName)
{
  Node* node = (Node*)pluginNode;
  ostream* out;
  if (!strcmp(fileName, "stdout") || !strcmp(fileName, "-")) {
    out = &cout;
  } else {
    out = new ofstream(fileName,
#ifdef NEW			   
			    std::ios_base::app | std::ios_base::out
#else
			    std::ios::app | std::ios::out
#endif
			    );
  }
  (*out) << "[node] " << node->getId() << " ";
  (*out) << (*node->getProtocolConfig()) << endl;
  node->writeIfaceList(*out);
  node->logState(*out);
  out->flush();
  if (out != &(cout)) {
    delete out;
  }
}

//---------------------------------------------------------------------------

#ifdef NU_AUTOCONF //{DAD}

#if 0
// XXX: remove
void getActualAddress(PPA_PluginNode pluginNode, 
		      void* rawAddress, void* rawAddressResult)
{
  Node* node = (Node*)pluginNode;
  Address address(node->getAddressFactory(), rawAddress);
  PluginIface* iface = getIfaceByInitialAddress(node, address);
  if (iface != NULL) {
      memcpy(rawAddressResult, iface->getAddress().getRawAddress(),
	     simulatorApi->addressSize);
      return;
  }
#if 0
  for(list<OLSRIface*>::iterator it = ifaceList->begin();
      it != ifaceList->end();it++) {
    ISystemIface* systemIface = (*it)->getSystemIface();
    PluginIface* pluginIface = dynamic_cast<PluginIface*>(systemIface);
    if (pluginIface->getInitialAddress() == address) {
      // Found the interface
      memcpy(rawAddressResult, pluginIface->getAddress().getRawAddress(),
	     simulatorApi->addressSize);
      return;
    }
  }
#endif
  Fatal("In node " << node->getId() << " couldn't find an interface "
	<< " with initial address " << address);
}
#endif

static int getNUAutoConfExtension(PPA_ExtensionInfo* info,
				  void* data)
{
  if (info->majorVersion != NU_AUTOCONF_EXTENSION_VERSION_MAJOR)
    return PPA_FAILURE;
  NUAutoConfExtensionApi** api = (NUAutoConfExtensionApi**) data;
  *api = (NUAutoConfExtensionApi*)malloc(sizeof(NUAutoConfExtensionApi));
  (*api)->getActualAddressFunction = NULL; //getActualAddress;
  return PPA_OK;
}

#endif // NU_AUTOCONF

//---------------------------------------------------------------------------

static void* pluginOpaqueFunctionCall
(char* cFunctionName,
 int argCount, void** argData, int* argSize,
 int* resultCount, void*** resultData, int** resultSize)
{
  list<string> resultList;
  string functionName = cFunctionName;
  if (functionName == "test") {
    resultList.push_back("result value 1");
    resultList.push_back("result value 2");
    return opaqueMakeResult(resultList, resultCount, resultData, resultSize);
  } else if (functionName == "getStatus") {
    if (argCount != 1)
      return errorBadNbArg("Plugin", 1, argCount);
    Node* node = *(Node**)(argData[0]); //XXX: check size
    char* info = NULL;
    nodeWrite(node, &info);
    string resultInfo = info;
    resultList.push_back(resultInfo);
    free(info);
    return opaqueMakeResult(resultList, resultCount, resultData, resultSize);

#ifdef NU_AUTOCONF // {DAD}
  } else if (functionName == "getAddressList") {
    if (argCount != 1)
      return errorBadNbArg("Plugin", 1, argCount); //XXX: check size
    Node* node = *(Node**)(argData[0]); //XXX: check size
    list<OLSRIface*>* ifaceList = node->getIfaceList();
    for(list<OLSRIface*>::iterator it = ifaceList->begin();
	it != ifaceList->end();it++) {
      ISystemIface* systemIface = (*it)->getSystemIface();
      PluginIface* pluginIface = dynamic_cast<PluginIface*>(systemIface);
      //Address initialAddress = pluginIface->getInitialAddress();
      Address currentAddress = pluginIface->getAddress();
      //string rawAddress1((char*)initialAddress.getRawAddress(), 
      //		 simulatorApi->addressSize);
      string rawAddress1 = "<deprecated value>";
      string rawAddress2((char*)currentAddress.getRawAddress(),
			 simulatorApi->addressSize);
      resultList.push_back(rawAddress1);
      resultList.push_back(rawAddress2);
      return opaqueMakeResult(resultList, resultCount, resultData, resultSize);
    }

  } else if (functionName == "performAddressChange") {
    if (argCount != 3)
      return errorBadNbArg("Plugin", 3, argCount); //XXX: check size
    Node* node = *(Node**)(argData[0]); //XXX: check size
    Address oldAddress(node->getAddressFactory(), argData[1]);
    Address newAddress(node->getAddressFactory(), argData[2]);
    node->performAddressChange(oldAddress, newAddress);
    return opaqueMakeResult(resultList, resultCount, resultData, resultSize);
#endif /* NU_AUTOCONF */

  }
  resultCount = 0;
  *resultData = NULL;
  *resultSize = NULL;
  string errorMsg = "Unknown plugin opaque function name '" 
    + functionName + "'";
  return NULL;
}

//---------------------------------------------------------------------------

static int getExtension(PPA_ExtensionInfo* info, void* data)
{
  string name = info->name;
#ifdef NU_AUTOCONF // {DAD}
  if (name == "NiigataUniversityAutoConfiguration")
    return getNUAutoConfExtension(info, data);
#endif /* NU_AUTOCONF */
  if (name == "OpaqueFunctionCall") {
    if (info->majorVersion != STD_OPAQUE_EXTENSION_VERSION_MAJOR)
      return PPA_FAILURE;
    PPA_OpaqueFunctionCall* opaqueFunction = (PPA_OpaqueFunctionCall*) data;
    *opaqueFunction = &pluginOpaqueFunctionCall;
    return PPA_OK;
  }

  return PPA_FAILURE;
}


//---------------------------------------------------------------------------

extern "C" int protocolPluginApiInit
(int major, int minor, 
 PPA_PlugeeApi* aSimulatorApi, 
 PPA_PluginApi** resultPluginApi)
{
  if(major != PPA_VERSION_MAJOR) {
    fprintf(stderr, "Plugin failure: implementing API v%d.%d while API %d.%d "
	    "is used", PPA_VERSION_MAJOR, PPA_VERSION_MINOR,
	    major, minor);
    return PPA_FAILURE;
  }

  simulatorApi = aSimulatorApi;
  //pluginProtocolApi._private = XXX;
  pluginProtocolApi.createNodeFunction = createNode;
  pluginProtocolApi.nodeStartFunction = nodeStart;
  pluginProtocolApi.nodeReceiveFunction = nodeReceive;
  pluginProtocolApi.nodeWriteFunction = nodeWrite;
  pluginProtocolApi.nodeOutputFunction = nodeOutput;
  pluginProtocolApi.nodeMulticastJoinGroupFunction = NULL;
  pluginProtocolApi.nodeMulticastLeaveGroupFunction = NULL;
  pluginProtocolApi.nodeMulticastSenderJoinFunction = NULL;
  pluginProtocolApi.nodeMulticastSenderLeaveFunction = NULL;

#ifdef WITH_MULTICAST_ENCAPSULATION
  pluginProtocolApi.nodeMulticastEncapsulateFunction 
    = nodeMulticastEncapsulate;
#ifdef  MULTICAST_RESEARCH
  pluginProtocolApi.nodeMulticastJoinGroupFunction = nodeMulticastJoinGroup;
  pluginProtocolApi.nodeMulticastLeaveGroupFunction = nodeMulticastLeaveGroup;
  pluginProtocolApi.nodeMulticastSenderJoinFunction = nodeMulticastSenderJoin;
  pluginProtocolApi.nodeMulticastSenderLeaveFunction 
    = nodeMulticastSenderLeave;
#endif  /* MULTICAST_RESEARCH */
#else /* !defined(WITH_MULTICAST_ENCAPSULATION) */
  pluginProtocolApi.nodeMulticastEncapsulateFunction = NULL;
#endif
  pluginProtocolApi.pluginGetExtension = getExtension;
  *resultPluginApi = &pluginProtocolApi;

  pluginAddressSize = simulatorApi->addressSize;

  pluginScheduler = new PluginScheduler;

  if (simulatorApi->getExtensionFunction != NULL) {
    PPA_ExtensionInfo opaqueExtensionInfo;
    memset(&opaqueExtensionInfo, 0, sizeof(opaqueExtensionInfo));
    opaqueExtensionInfo.name = "OpaqueFunctionCall";
    opaqueExtensionInfo.majorVersion = STD_OPAQUE_EXTENSION_VERSION_MAJOR;
    opaqueExtensionInfo.minorVersion = STD_OPAQUE_EXTENSION_VERSION_MINOR;
    if (simulatorApi->getExtensionFunction
	(&opaqueExtensionInfo, &simulatorOpaqueFunction) == PPA_FAILURE) {
      Warn("Couldn't load opaque function call from the simulator/plugee");
      simulatorOpaqueFunction = NULL;
    }
  }

  return PPA_OK;
}

//---------------------------------------------------------------------------
