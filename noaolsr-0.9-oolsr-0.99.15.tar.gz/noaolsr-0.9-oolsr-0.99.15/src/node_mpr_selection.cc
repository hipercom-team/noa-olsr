//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Adokoe Plakoo, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//     $Id: node_mpr_selection.cc,v 1.31.2.6 2005/02/15 08:29:50 adjih Exp $
//---------------------------------------------------------------------------
// This file implements the MPR Selection
//---------------------------------------------------------------------------

#include <signal.h> // XXX: remove

#include "address.h"
#include "protocol_tuple.h"
#include "node.h"
#include "node_mpr_selection.h"

//-----------------------------------------------------------------------------


NeighborSet::LocalIfaceNeighborIterator
NeighborSet::getLocalIfaceNeighborIterator(Address localIfaceAddress)
{
  return LocalIfaceNeighborIterator(IsLocalIfaceNeighbor(localIfaceAddress), 
				    this->getIter());
}

//---------------------------------------------------------------------------

TwoHopNeighborSet::LocalIfaceTwoHopNeighborIterator
TwoHopNeighborSet::getLocalIfaceTwoHopNeighborIterator(Node* aNode,
					   Address localIfaceAddress)
{
  return LocalIfaceTwoHopNeighborIterator
    (IsLocalIfaceTwoHopNeighbor(aNode, localIfaceAddress), this->getIter());
}

//-----------------------------------------------------------------------------

// Return true iff:
// - the two hop tuple is actually on local_iface_addr and reaches *this
//
// Iterator:
// - gives the twoHopTuple to reach *this (TwoHopNodeTuple)
// - iteration time: O( TxTxNxL )
// - used: 1 time

struct HasTwoHopNodeAddress 
{
  HasTwoHopNodeAddress(Node* aNode, Address mainAddress, Address localAddress)
    : node(aNode), main_address(mainAddress), local_iface_addr(localAddress) {}

  bool operator () (TwoHopNeighborTuple& twoHopNeighborTuple)
  {
    for(TwoHopNeighborSet::LocalIfaceTwoHopNeighborIterator it =
	  node->twoHopNeighborSet.getLocalIfaceTwoHopNeighborIterator
	  (node, local_iface_addr); 
	!it.isDone(); it.next())

      if ( (it.getCurrent() == &twoHopNeighborTuple) &&  
	   (it.getCurrent()->N_2hop_addr == main_address) ) return true;

    return false;
  }

  Node* node;
  Address main_address;
  Address local_iface_addr;
};

TwoHopNodeTuple::AssociatedTwoHopLinkIterator
TwoHopNodeTuple::getAssociatedTwoHopLinkIterator()
{
  return AssociatedTwoHopLinkIterator
    (HasTwoHopNodeAddress(node, Main_addr, L_local_iface_addr),
     node->twoHopNeighborSet.getIter());
}

//-----------------------------------------------------------------------------

#ifndef MPR_OPT

// Return true iff:
// - neighborTuple is one hop of a twoHopTuple on iface
//
// Iterator:
// - gives the neighborTuple which have twoHopTuple on iface
// - iteration time: O( NxTxTxNxL )
// - used: 4 times

struct HasTwoHopLinkNeighborAddress 
{
  HasTwoHopLinkNeighborAddress(TwoHopNodeTuple* aTwoHopNodeTuple)
    : twoHopNodeTuple(aTwoHopNodeTuple) {}

  bool operator () (NeighborTuple& neighborTuple)
  {
    if (neighborTuple.N_status != SYM)
      return false;

    for(TwoHopNodeTuple::AssociatedTwoHopLinkIterator it =
	  twoHopNodeTuple->getAssociatedTwoHopLinkIterator();
	!it.isDone(); it.next())
      
      if (it.getCurrent()->N_neighbor_main_addr == 
	  neighborTuple.N_neighbor_main_addr) return true;

    return false;
  }

  TwoHopNodeTuple* twoHopNodeTuple;
};

TwoHopNodeTuple::AssociatedNeighborIterator
TwoHopNodeTuple::getAssociatedNeighborIterator()
{
  return AssociatedNeighborIterator
    (HasTwoHopLinkNeighborAddress(this), node->neighborSet.getIter());
}

#else

// - iteration time: O( T ) [+ setup time in initOptimization]
TwoHopNodeTuple::AssociatedNeighborIterator
TwoHopNodeTuple::getAssociatedNeighborIterator()
{
  assert( mprComputation->twoHopToOneHopList.get(Main_addr) != NULL );
  list<NeighborTuple*>* l = mprComputation->twoHopToOneHopList.get(Main_addr);
  return AssociatedNeighborIterator(l->begin(), l->end());
}


// Time: about O( L.M ) + O( N ) + O( T ) 
//  with several log(L), log(N), or log(T) factors (for the Map).
// 
void LocalIfaceMPRComputation::initOptimization()
{
  // Time: O( L )
  for (LinkSet::TupleIterator it = node->linkSet.getIter();
       !it.isDone(); it.next()) 
    {
      LinkTuple* linkTuple = it.getCurrent();
      if (linkTuple->getStatus() != SYM_LINK)
	continue;

      if( linkTuple->L_local_iface_addr == local_iface_addr ) {
	Address neighborMainAddress = node->ifaceToMainAddress
	  (linkTuple->L_neighbor_iface_addr);
	if( neighborHasLinkOnThis.get(neighborMainAddress) == NULL)
	  neighborHasLinkOnThis.add(neighborMainAddress, true);
      }
    }

  // Time: O( N )
  for(NeighborSet::TupleIterator it = node->neighborSet.getIter();
      !it.isDone(); it.next()) 
    {
      NeighborTuple* neighborTuple = it.getCurrent();
      if (neighborTuple->N_status != SYM)
	continue;
      Address neighborMainAddress = neighborTuple->N_neighbor_main_addr;
      if( neighborHasLinkOnThis.get(neighborMainAddress, false)
	  && localNeighborTuple.get(neighborMainAddress) == NULL)
	localNeighborTuple.add(neighborMainAddress, neighborTuple);
    }

  // Time: O( T )
  for(TwoHopNeighborSet::TupleIterator it = node->twoHopNeighborSet.getIter();
      !it.isDone(); it.next())
    {
      TwoHopNeighborTuple* twoHop = it.getCurrent();
      if (localNeighborTuple.get(twoHop->N_neighbor_main_addr) != NULL) {
	// This two hop can be reached by a neighbor which has a link
	// to this interface, hence:
	twoHopNeighborSetOnIface.push_back(twoHop);
	NeighborTuple* neighborTuple = 
	  localNeighborTuple.get(twoHop->N_neighbor_main_addr, NULL);
	assert( neighborTuple != NULL ); // guaranted by invariants
	assert (neighborTuple->N_status == SYM);
	if(twoHopToOneHopList.get(twoHop->N_2hop_addr) == NULL) {
	  list<NeighborTuple*> emptyList;
	  twoHopToOneHopList.add(twoHop->N_2hop_addr, emptyList);
	}
	list<NeighborTuple*>* oneHopList = 
	  twoHopToOneHopList.get(twoHop->N_2hop_addr);
	assert( oneHopList != NULL );
	oneHopList->push_back(neighborTuple);
      }
    }
}
#endif


//-----------------------------------------------------------------------------

OneHopNodeTuple*
LocalIfaceMPRComputation::getOneHopNode(NeighborTuple* neighborTuple)
{
  assert( neighborTuple->N_status == SYM );
  for(std::list<OneHopNodeTuple*>::iterator it = oneHopNodeList.begin();
      it != oneHopNodeList.end(); it++) 

    if ( neighborTuple == (*it)->neighborTuple ) return *it;
  return NULL;
}

//-----------------------------------------------------------------------------

bool TwoHopNodeTuple::isPoorlyCovered()
{
  int counter = 0;
  for(AssociatedNeighborIterator it = getAssociatedNeighborIterator();
      !it.isDone(); it.next()) 
    {
      assert( (*it)->N_status == SYM );
      OneHopNodeTuple* oneHopNodeTuple = mprComputation->getOneHopNode(*it);
      if (oneHopNodeTuple)
	counter++;
    }

  if (!counter) 
    return false;
  else
    return counter < node->getMprCoverage();
}

//-----------------------------------------------------------------------------

bool LocalIfaceMPRComputation::isSelectedAsLocalIfaceMpr(Address main_address)
{
#ifdef MPR_OPT
  OneHopNodeTuple* oneHop = oneHopNodeTable.get(main_address, NULL);
  if (oneHop == NULL) return false;
  else return oneHop->isSelectedAsMPR();
#endif

  NeighborTuple* neighborTuple = 
    node->neighborSet.findFirst_MainAddr(main_address);
  if (neighborTuple->N_status != SYM)
    return false;

  for(std::list<OneHopNodeTuple*>::iterator it = oneHopNodeList.begin();
      it != oneHopNodeList.end(); it++) 

    if ( neighborTuple == (*it)->neighborTuple ) 

      return (*it)->isSelectedAsMPR();

  return false;
}

//-----------------------------------------------------------------------------

int TwoHopNodeTuple::getCurrentMprCoverage()
{
  int counter = 0;

#ifdef MPR_OPT
  //  if (oneHopListCache == NULL)
  list<NeighborTuple*>* oneHopList 
    //oneHopListCache
    = mprComputation->twoHopToOneHopList.get(Main_addr);
  //list<NeighborTuple*>* oneHopList = oneHopListCache;
  assert( oneHopList != NULL );
  for(list<NeighborTuple*>::iterator it = oneHopList->begin();
      it != oneHopList->end(); it++) 
#else
  for(AssociatedNeighborIterator it = getAssociatedNeighborIterator();
      !it.isDone(); it.next()) 
#endif
    {
      NeighborTuple* neighborTuple = *it; //it.getCurrent();
      
      if (neighborTuple->N_status != SYM)
	continue;

      if ( mprComputation->isSelectedAsLocalIfaceMpr
	   (neighborTuple->N_neighbor_main_addr) )
	counter++;
    }
  
  return counter;
}

//-----------------------------------------------------------------------------

bool TwoHopNodeTuple::isLinkedTo(OneHopNodeTuple& oneHopNode)
{
#ifndef MPR_OPT
  for(NeighborTuple::AssociatedTwoHopNeighborIterator it =
	oneHopNode.neighborTuple->getAssociatedTwoHopNeighborIterator(); 
      !it.isDone(); it.next())

    if (it.getCurrent()->N_2hop_addr == Main_addr) return true;
#else

  // Looks in all the two hop tuples associated with 
  list<NeighborTuple*>* oneHopList 
    = mprComputation->twoHopToOneHopList.get(Main_addr);
  assert( oneHopList != NULL );
  for(list<NeighborTuple*>::iterator it = oneHopList->begin();
      it != oneHopList->end(); it++) 

    if ((*it)->N_neighbor_main_addr 
	== oneHopNode.neighborTuple->N_neighbor_main_addr) 
      return true;

#endif

  return false;
}

//-----------------------------------------------------------------------------

int OneHopNodeTuple::getDegree()
{
  int degree = 0;

  for(std::list<TwoHopNodeTuple*>::iterator it =
	mprComputation->strictTwoHopNodeList.begin();
      it != mprComputation->strictTwoHopNodeList.end(); it++) 
    
    if ( (*it)->isLinkedTo(*this) ) degree++;

  return degree;
}

//-----------------------------------------------------------------------------

int OneHopNodeTuple::getReachability()
{
  int counter = 0;

  for(std::list<TwoHopNodeTuple*>::iterator it =
	mprComputation->strictTwoHopNodeList.begin();
      it != mprComputation->strictTwoHopNodeList.end(); it++) 
    
    if ( (*it)->isLinkedTo(*this) &&
	 ((*it)->getCurrentMprCoverage() < node->getMprCoverage()) )
      
      counter++;
  
  return counter;
}

//-----------------------------------------------------------------------------

void LocalIfaceMPRComputation::setOneHopNodeList()
{
  OneHopNodeTuple* oneHopNodeTuple;

  for(NeighborSet::LocalIfaceNeighborIterator it
	= node->neighborSet.getLocalIfaceNeighborIterator(local_iface_addr); 
      !it.isDone(); it.next())
    
    if ( (*it)->N_status == SYM && (*it)->getWillingness() != WILL_NEVER ) 
      {
	oneHopNodeTuple = new OneHopNodeTuple(*it, this, node,
					      local_iface_addr);
	oneHopNodeTuple->setMPR(false);
	oneHopNodeList.push_back(oneHopNodeTuple);
#ifdef MPR_OPT
	oneHopNodeTable.add((*it)->N_neighbor_main_addr, oneHopNodeTuple);
#endif
      }
}

//-----------------------------------------------------------------------------

void LocalIfaceMPRComputation::deleteOneHopNodeList()
{
  for(std::list<OneHopNodeTuple*>::iterator it = oneHopNodeList.begin();
      it != oneHopNodeList.end(); it++) 

    delete *it;

  oneHopNodeList.clear();
}

//-----------------------------------------------------------------------------

bool TwoHopNodeTuple::isAlsoNeighbor()
{

  NeighborTuple* neighborTuple = 
    node->neighborSet.findFirst_MainAddr(Main_addr);
  return (neighborTuple != NULL) && (neighborTuple->N_status == SYM);
}

//-----------------------------------------------------------------------------

bool TwoHopNodeTuple::isFoundInStrictTwoHopList()
{
  for(std::list<TwoHopNodeTuple*>::iterator it =
	mprComputation->strictTwoHopNodeList.begin();
      it != mprComputation->strictTwoHopNodeList.end(); it++)

    if (Main_addr == (*it)->Main_addr) return true;

  return false;
}

//-----------------------------------------------------------------------------

bool TwoHopNodeTuple::isOnlyReachableByWillNever()
{
  for(AssociatedNeighborIterator it = getAssociatedNeighborIterator();
      !it.isDone(); it.next()) 
    {
      NeighborTuple* neighborTuple = it.getCurrent();
      assert( neighborTuple->N_status == SYM );
      if (neighborTuple->getWillingness() != WILL_NEVER) return false;
    }
  return true;
}

//-----------------------------------------------------------------------------

void LocalIfaceMPRComputation::setStrictTwoHopNodeList()
{
  TwoHopNodeTuple* twoHopNodeTuple = NULL;

#ifndef MPR_OPT
  for(TwoHopNeighborSet::LocalIfaceTwoHopNeighborIterator it
       = node->twoHopNeighborSet.getLocalIfaceTwoHopNeighborIterator
	(node, local_iface_addr); !it.isDone(); it.next())
#else
  for(std::list<TwoHopNeighborTuple*>::iterator it 
         = twoHopNeighborSetOnIface.begin();
      it != twoHopNeighborSetOnIface.end(); it++)
#endif
    {
      twoHopNodeTuple = new TwoHopNodeTuple
	(this, node, (*it)->N_2hop_addr, local_iface_addr);
      
      if ( !twoHopNodeTuple->isFoundInStrictTwoHopList() &&   
	   !twoHopNodeTuple->isOnlyReachableByWillNever() && 
	   !twoHopNodeTuple->isAlsoNeighbor() )

	strictTwoHopNodeList.push_back(twoHopNodeTuple);
      else delete twoHopNodeTuple;
    }
}

//-----------------------------------------------------------------------------

void LocalIfaceMPRComputation::deleteStrictTwoHopNodeList()
{
  for(std::list<TwoHopNodeTuple*>::iterator it = strictTwoHopNodeList.begin();
      it != strictTwoHopNodeList.end(); it++) 
    delete *it;

  strictTwoHopNodeList.clear();
}

//-----------------------------------------------------------------------------

void LocalIfaceMPRComputation::selectWillAlwaysAsMpr()
{
  for(std::list<OneHopNodeTuple*>::iterator it = oneHopNodeList.begin();
      it != oneHopNodeList.end(); it++)
    
    if ( ((*it)->neighborTuple->getWillingness() == WILL_ALWAYS) &&
	 (*it)->getDegree() )
      
      (*it)->setMPR(true);
}

//-----------------------------------------------------------------------------

void LocalIfaceMPRComputation::selectPoorlyCoveredNeighborAsMpr()
{
  for(std::list<TwoHopNodeTuple*>::iterator it = strictTwoHopNodeList.begin();
      it != strictTwoHopNodeList.end(); it++)
    {
      if ( (*it)->isPoorlyCovered() )
	{
	  for(TwoHopNodeTuple::AssociatedNeighborIterator N_it =
		(*it)->getAssociatedNeighborIterator();
	      !N_it.isDone(); N_it.next()) 
	    {
	      NeighborTuple* neighborTuple = N_it.getCurrent();
	      assert( neighborTuple->N_status == SYM );
	      if (neighborTuple->getWillingness() != WILL_NEVER) 
		{
		  OneHopNodeTuple* oneHopNodeTuple = 
		    getOneHopNode(neighborTuple);
		  assert(oneHopNodeTuple != NULL);
		  oneHopNodeTuple->setMPR(true);
		}
	    }
	}
    }
}

//-----------------------------------------------------------------------------

#ifdef NU_AUTOCONF // {DAD}
// XXX:AUTOCONF: this is actually useless, because getWillingness()
// returns WILL_NEVER for any node which not in STATE_NORMAL
static bool hasLowerWillingness(Node* node, NeighborTuple* neighborTuple1,
				NeighborTuple* neighborTuple2)
{ 
  AutoConfState state1 
    = node->stateSet.ensure(neighborTuple1->N_neighbor_main_addr)->S_state;
  AutoConfState state2 
    = node->stateSet.ensure(neighborTuple2->N_neighbor_main_addr)->S_state;
  if (state2 == STATE_NORMAL && state1 != STATE_NORMAL)
    return true; // it is TRUE that "W1 < W2"
  if (state1 == STATE_NORMAL && state2 != STATE_NORMAL)
    return false; // it is FALSE that "W1 < W2"
  return neighborTuple1->getWillingness() < neighborTuple2->getWillingness();
}
static bool hasSameWillingness(Node* node, NeighborTuple* neighborTuple1,
				NeighborTuple* neighborTuple2)
{ 
  AutoConfState state1 
    = node->stateSet.ensure(neighborTuple1->N_neighbor_main_addr)->S_state;
  AutoConfState state2 
    = node->stateSet.ensure(neighborTuple2->N_neighbor_main_addr)->S_state;
  bool isNormal1 = state1 == STATE_NORMAL;
  bool isNormal2 = state2 == STATE_NORMAL;
  return (isNormal1 == isNormal2) 
    && (neighborTuple1->getWillingness() < neighborTuple2->getWillingness());
}

#else
static bool hasLowerWillingness(Node* node, NeighborTuple* neighborTuple1,
				NeighborTuple* neighborTuple2)
{ return neighborTuple1->getWillingness() < neighborTuple2->getWillingness(); }
static bool hasSameWillingness(Node* node, NeighborTuple* neighborTuple1,
			       NeighborTuple* neighborTuple2)
{return neighborTuple1->getWillingness() == neighborTuple2->getWillingness(); }

#endif // NU_AUTOCONF

void LocalIfaceMPRComputation::selectOtherMpr()
{
  OneHopNodeTuple* mprCandidate = NULL;
  
  for(std::list<OneHopNodeTuple*>::iterator it = oneHopNodeList.begin();
      it != oneHopNodeList.end(); it++)
    {
      if ( (*it)->isSelectedAsMPR() || !(*it)->getReachability() ) continue;
      
      if (!mprCandidate) { mprCandidate = *it; continue; }
      
      if ( hasLowerWillingness(node, mprCandidate->neighborTuple, 
			       (*it)->neighborTuple) )
	{
	  mprCandidate = *it; continue;
	}

      if ( hasSameWillingness(node, mprCandidate->neighborTuple,
			      (*it)->neighborTuple) )
	{
	  if ( mprCandidate->getReachability() <
	       (*it)->getReachability() )
	    {
	      mprCandidate = *it; continue;
	    }
	  
	  if ( mprCandidate->getReachability() ==
	       (*it)->getReachability() )
	    {
	      if ( mprCandidate->getDegree() <
		   (*it)->getDegree() )

		mprCandidate = *it;
	    }
	}
    }
  
  if (mprCandidate) mprCandidate->setMPR(true);
}

//-----------------------------------------------------------------------------

bool LocalIfaceMPRComputation::isNewMprNodeNeeded()
{
  int counter = 0;

  for(std::list<TwoHopNodeTuple*>::iterator it = strictTwoHopNodeList.begin();
      it != strictTwoHopNodeList.end(); it++) 

    if ( !(*it)->isPoorlyCovered() && 
	 ((*it)->getCurrentMprCoverage() < node->getMprCoverage()) )

      counter++;

  return counter != 0;
}

//-----------------------------------------------------------------------------

void LocalIfaceMPRComputation::computeMpr()
{
  selectWillAlwaysAsMpr();
  selectPoorlyCoveredNeighborAsMpr();
  
  while( isNewMprNodeNeeded() ) selectOtherMpr();
}

//-----------------------------------------------------------------------------

void LocalIfaceMPRComputation::addMprToNodeList()
{

  for(std::list<OneHopNodeTuple*>::iterator it = oneHopNodeList.begin();
      it != oneHopNodeList.end(); it++)

    if( (*it)->isSelectedAsMPR() && 
	!node->isMPR((*it)->neighborTuple->N_neighbor_main_addr) )

      node->mprList.push_back( (*it)->neighborTuple );

}

//-----------------------------------------------------------------------------

int statMPRSelection = 0;
double statMPRSelectionTime = 0;

#ifndef NO_STAT
extern double getTimeOfDay();
#endif

/// [MPRSelection] Recompute the MPR of the node.
void Node::computeMPR()
{
  D(*log, lAction, getRealTime() << " [action] " << getId() 
    << " computeMPR" << " " << statMPRSelection << endl);
  bool shouldComputeMPR = true;

#ifdef NU_AUTOCONF // {DAD}
  shouldComputeMPR = (_getAutoConfState() != STATE_HELLO);
  autoConfNotifyPreMPRComputation();
#endif

#ifndef NO_STAT
  double startTime = getTimeOfDay();
#endif
  statMPRSelection++;
  std::list<Address>* addressList = getAddressList();
  mprList.clear();

  if (shouldComputeMPR) {  
    for (std::list<Address>::iterator it = addressList->begin();
	 it != addressList->end(); it++) 
      {
	LocalIfaceMPRComputation localIfaceMPRComputation(this, *it);
#ifdef MPR_OPT
	localIfaceMPRComputation.initOptimization();
#endif
	localIfaceMPRComputation.setOneHopNodeList();
	localIfaceMPRComputation.setStrictTwoHopNodeList();
	localIfaceMPRComputation.computeMpr();
	localIfaceMPRComputation.addMprToNodeList();
      }
  }

#ifdef NU_AUTOCONF // {DAD}
  autoConfUpdateMPRList(mprList);
#endif

#ifndef NO_STAT
  statMPRSelectionTime += (getTimeOfDay() - startTime);
#endif
}

//-----------------------------------------------------------------------------

/// [MPRSelection] Returns true if and only if ifaceAddress is the
/// address of an interface of a node which is a MPR.
bool Node::isMPR(Address ifaceAddress) 
{
  Address ifaceMainAddress = ifaceToMainAddress(ifaceAddress);
  NeighborTuple* neighborTuple = 
    neighborSet.findFirst_MainAddr(ifaceMainAddress);

  for(std::list<NeighborTuple*>::iterator it = mprList.begin(); 
      it != mprList.end(); it++)
    
    if ( neighborTuple == *it ) return true;
  
  return false;
}

//-----------------------------------------------------------------------------

void Node::writeMPRSet(ostream& out)
{
  bool isFirst = true;
  for(std::list<NeighborTuple*>::iterator it = mprList.begin(); 
      it != mprList.end(); it++) {
    if (!isFirst) out << ";";
    else isFirst = false;
    out << (*it)->N_neighbor_main_addr;
  }
}

//---------------------------------------------------------------------------
