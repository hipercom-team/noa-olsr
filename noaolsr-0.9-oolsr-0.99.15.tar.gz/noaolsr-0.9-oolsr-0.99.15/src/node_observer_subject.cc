//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
//  
//---------------------------------------------------------------------------

#include "mystream.h"

//--------------------------------------------------

#include "general.h"
#include "protocol_observer.h"
#include "protocol_tuple.h"
#include "node_link_monitoring.h"
#include "node.h"

//---------------------------------------------------------------------------

typedef pair<string, string> StringPair;

#define ADD2(x,y) \
    BeginMacro \
      if (!header) { \
        ostringstream fmt; \
        fmt << y; \
        result->push_back(fmt.str()); \
      } else result->push_back(x); \
    EndMacro

#define ADD(x) ADD2(""#x,t->x)

#define ADDTime(x,now) ADD2(""#x,t->x - (now))

//---------------------------------------------------------------------------

class LinkTupleSubject: public ITupleSubject
{
public:
  LinkTuple* t;

  LinkTupleSubject(LinkTuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "LinkTuple"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD(L_neighbor_iface_addr);
    ADD(L_local_iface_addr);
    ADDTime(L_SYM_time, node->getCurrentTime());
    ADDTime(L_ASYM_time, node->getCurrentTime());
    ADDTime(L_time, node->getCurrentTime());

    ADDTime(L_LOST_LINK_time, node->getCurrentTime());
    ADD(L_link_pending);

    ADD2("link status", linkTypeToString(t->getStatus()));
    return result;
  }
};


class NeighborTupleSubject: public ITupleSubject
{
public:
  NeighborTuple* t;

  NeighborTupleSubject(NeighborTuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "NeighborTuple"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD(N_neighbor_main_addr);
    ADD2("N_status", neighborStatusToString(t->N_status));
    ADD(N_willingness);
    return result;
  }
};


class TwoHopNeighborTupleSubject: public ITupleSubject
{
public:
  TwoHopNeighborTuple* t;
  
  TwoHopNeighborTupleSubject(TwoHopNeighborTuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "TwoHopNeighborTuple"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD(N_neighbor_main_addr);
    ADD(N_2hop_addr);
    ADDTime(N_time, node->getCurrentTime());
    return result;
  }
};

class MPRSelectorTupleSubject: public ITupleSubject
{
public:
  MPRSelectorTuple* t;

  MPRSelectorTupleSubject(MPRSelectorTuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "MPRSelectorTuple"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD(MS_addr);
    ADDTime(MS_time, node->getCurrentTime());
    return result;
  }
};

class TopologyTupleSubject: public ITupleSubject
{
public:
  TopologyTuple* t;

  TopologyTupleSubject(TopologyTuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "TopologyTuple"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD(T_dest_addr);
    ADD(T_last_addr);
    ADD(T_seq);
    ADDTime(T_time, node->getCurrentTime());

    return result;
  }
};

class IfaceAssociationTupleSubject: public ITupleSubject
{
public:
  IfaceAssociationTuple* t;

  IfaceAssociationTupleSubject(IfaceAssociationTuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "IfaceAssociationTuple"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD(I_iface_addr);
    ADD(I_main_addr);
    ADDTime(I_time, node->getCurrentTime());
    return result;
  }
};


class HNATupleSubject: public ITupleSubject
{
public:
  HNATuple* t;

  HNATupleSubject(HNATuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "HNATuple"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD(A_gateway_addr);
    ADD(A_network_addr);
    ADD(A_netmask);
    ADDTime(A_time, node->getCurrentTime());
    return result;
  }
};

class RoutingTupleSubject: public ITupleSubject
{
public:
  RoutingTuple* t;

  RoutingTupleSubject(RoutingTuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "RoutingTuple"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD(R_dest_addr);
    ADD(R_dest_mask_addr);
    ADD(R_next_addr);
    ADD(R_dist);
    ADD(R_iface_addr);
    return result;
  }
};

class MPRSubject: public ITupleSubject
{
public:
  Address neighborMainAddress;

  MPRSubject(Address mprAddress) 
    : neighborMainAddress(mprAddress) {}

  virtual string getTupleName() { return "MPR"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD2("MPR main address", neighborMainAddress);
    return result;
  }
};


class DuplicateTupleSubject: public ITupleSubject
{
public:
  DuplicateTuple* t;

  DuplicateTupleSubject(DuplicateTuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "DuplicateTuple"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD(D_addr);
    ADD(D_seq_num);
    ADD(D_retransmitted);
    ostringstream ifaceListOut;
    if (!header) {
      for(std::list<Address>::iterator it = t->D_iface_list.begin(); 
	  it != t->D_iface_list.end(); it++)
	ifaceListOut << "," << (*it);
    } else ifaceListOut << ","; // unused
    string ifaceListStr = ifaceListOut.str();
    ifaceListStr.erase(0, 1);
    ADD2("D_iface_list", ifaceListStr.c_str());
    ADDTime(D_time, node->getCurrentTime());
    return result;
  }
};

class HeardIfaceTupleSubject: public ITupleSubject
{
public:
  HeardIfaceTuple* t;

  HeardIfaceTupleSubject(HeardIfaceTuple* aTuple) : t(aTuple) {}

  virtual string getTupleName() { return "HeardIfaceTuple"; }

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD(H_remonte_iface_addr);
    ADD(H_local_iface_addr);
    ADD(H_last_packetSequenceNumber);
    //XXX: MonitoringInfo
    return result;
  }
};

#if 0
class ITupleSubject: public ITupleSubject
{
public:
  Tuple* t;

  vector< string >* getContent(Node* node, bool header) 
  {
    vector< string >* result = new vector< string >;
    ADD();
    return result;
  }
};
#endif

//---------------------------------------------------------------------------


template<class TupleSet, class TupleSubject>
vector<vector<string>*>* getTableContent(Node* node, TupleSet& tupleSet)
{
  vector<vector<string>*>* result = new vector<vector<string>*>;
  TupleSubject nullSubject(NULL);

  result->push_back(nullSubject.getContent(node, true));

  for (typename TupleSet::TupleIterator it = tupleSet.getIter(); 
       !it.isDone(); it.next()) {
    TupleSubject subject(it.getCurrent());
    result->push_back(subject.getContent(node, false));
  }

  return result;
} 

vector<vector<string>*>* getMPRTableContent(Node* node)
{
  vector<vector<string>*>* result = new vector<vector<string>*>;
  Address nullAddress;
  MPRSubject nullSubject(nullAddress);
  result->push_back(nullSubject.getContent(node, true));
  for (std::list<NeighborTuple*>::iterator it = node->mprList.begin();
       it != node->mprList.end(); it++) {
    MPRSubject subject((*it)->N_neighbor_main_addr);
    result->push_back(subject.getContent(node, false));
  }
  return result;
} 


//---------------------------------------------------------------------------

void DumpProtocolObserver::notifyTupleChange(string changeType,
					     ITupleSubject* subject)
{
  out << "[tuple] " << changeType.c_str() << " " 
      << subject->getTupleName().c_str() << "{" ;
  vector<string>* header = subject->getContent(node, true);
  vector<string>* data = subject->getContent(node, false);
  for (unsigned int i=0; i<data->size(); i++) {
    if (i!=0)
      out << "; ";
    out << (*header)[i] << "=" << (*data)[i];
  }
  out << "}" << endl;
  delete data;
}

//---------------------------------------------------------------------------

void Node::attach(IProtocolObserver* observer,
	    bool observeMajorTupleChange,
	    bool observeMinorTupleChange)
{
  observerList.push_back(observer);
}

void Node::detach(IProtocolObserver* observer)
{
  observerList.remove(observer);
}

vector<string>* Node::getTableNameList()
{
  vector<string>* result = new vector<string>;
  char* tableName[] = { 
    "Route", "Neighbor", "Link", "TwoHopNeighbor", "MPR", "MPRSelector", 
    "Topology", "MID", "HNA", "Duplicate", NULL
  };
  for (char** it = tableName; *it != NULL; it++)
    result->push_back(*it);
  return result;
}

vector<vector<string>*>* Node::getTableContent(string name)
{
  if (name == "Neighbor") 
    return ::getTableContent<NeighborSet,NeighborTupleSubject>(this, neighborSet);
  else if (name == "Link")
    return ::getTableContent<LinkSet,LinkTupleSubject>(this, linkSet);
  else if (name == "TwoHopNeighbor")
    return ::getTableContent<TwoHopNeighborSet,
      TwoHopNeighborTupleSubject>(this, twoHopNeighborSet);
  else if (name == "MPRSelector")
    return ::getTableContent<MPRSelectorSet, 
      MPRSelectorTupleSubject>(this, mprSelectorSet);
  else if (name == "Topology")
    return ::getTableContent<TopologySet,TopologyTupleSubject>(this,
							       topologySet);
  else if (name == "MID")
    return ::getTableContent<IfaceAssociationSet,
      IfaceAssociationTupleSubject>(this, ifaceAssociationSet);
  else if (name == "HNA")
    return ::getTableContent<HNASet,
      HNATupleSubject>(this, hnaSet);
  else if (name == "Duplicate")
    return ::getTableContent<DuplicateSet,
      DuplicateTupleSubject>(this, duplicateSet);
  else if (name == "HeardIface") 
    return ::getTableContent<HeardIfaceSet,
      HeardIfaceTupleSubject>(this, heardIfaceSet);
  else if (name == "MPR")
    return ::getMPRTableContent(this);
  else if (name == "Route")
    return ::getTableContent<RoutingTable,
      RoutingTupleSubject>(this, *currentRoutingTable);
  else return NULL;
}

//---------------------------------------------------------------------------
