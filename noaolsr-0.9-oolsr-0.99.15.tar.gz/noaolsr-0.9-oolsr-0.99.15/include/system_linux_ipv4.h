//---------------------------------------------------------------------------
//                             OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#include <sys/types.h>
#include <netdb.h>
#include <net/if.h>

//---------------------------------------------------------------------------

#include "system_linux.h"

#include "system_linux_ipv4_internal.h"
#include "scheduler_simulation.h"


#define STR_IP_BROADCAST "255.255.255.255"

class LinuxIPv4LowLevel : public LinuxLowLevel
{
public:
  static const int AddressSize = 4; // XXX: correct one

  static bool isIPv6() { return false; }

  static bool shouldMakeOneSocket()
  { return true; } // should make one socket: both for input and output

  typedef sockaddr_in SystemAddress;

  static void* systemAddressToRawAddress(SystemAddress& systemAddress) {
    assert( systemAddress.sin_family == AF_INET );
    assert( sizeof(systemAddress.sin_addr) == AddressSize );
    return &systemAddress.sin_addr;
  }

  static void rawAddressToSystemAddress(void* rawAddress, 
					SystemAddress& resultAddress)
  {
    memset(&resultAddress, 0, sizeof(resultAddress));
    resultAddress.sin_family = AF_INET;
    memcpy(&resultAddress.sin_addr, rawAddress, AddressSize);
  }

  static void reprAddress(SystemAddress& address, char* result)
  { inet_ntop(AF_INET, &address.sin_addr, result, 4096 /*XXX!*/); }

  // Factor in with ipv6
  static string reprAddress(SystemAddress& address)
  {
    char buffer[4096]; // XXX
    if (inet_ntop(AF_INET, &address.sin_addr, buffer, sizeof(buffer)) == NULL)
      Fatal("inet_ntop: " << strerror(errno));
    string result = buffer;
    return result;
  }
  
  static int makeUDPSocket()
  {
    int sd = socket(PF_INET, SOCK_DGRAM, 0);
    if(sd < 0)
      Fatal(" socket(PF_INET, SOCK_DGRAM, 0): " << strerror(errno));
    return sd;
  }

  static void strToAddress(SystemAddress& sockAddress, string strGroupAddress)
			     
  {
    memset(&sockAddress, 0, sizeof(sockAddress));
    sockAddress.sin_family = AF_INET;

    if (strGroupAddress == "")
      sockAddress.sin_addr.s_addr = INADDR_ANY; // XXX
    else inet_pton(AF_INET, strGroupAddress.c_str(), &sockAddress.sin_addr);
  }

#if 0  
  static bool strToAddressAndPrefix(string strAddress,
				    SystemAddress& resultAddress,
				    int& resultSize)
  {
    const int BitPerByte = 8;
    resultSize = -1;
    vector<string> tokenList = stringSplit(strAddress, "/");
    if (tokenList.size() != 2) 
      return false;
    //Fatal("address should have format "
    //	    "aaa.aaa.aaa.aaa/prefixSize, instead found: " << strAddress);

    // Parse address
    strToAddress(resultAddress, tokenList[0]);
    tokenList[0];
    // Get prefix first
    int prefixSize = -1;
    if (!strToInt(tokenList[1], prefixSize) 
	|| (prefixSize < 0) 
	|| (prefixSize > AddressSize*BitPerByte))
      return false;
    //Fatal("Bad prefixSize in autoconfiguration address: " 
    //<< tokenList[0]);
    resultSize = prefixSize;
    return true;
  }
#else

  // another copy. Here's the story: the IPv4 code was copied verbatim
  // to IPv6. Then the IPv6 code was modified. Then it has to be copied
  // back to IPv4: here it is.

  static bool strToAddressAndPrefix(string strAddress,
				    SystemAddress& resultAddress,
				    int& resultSize, int& resultInitialSize)
  {
    const int BitPerByte = 8;
    resultSize = -1;
    vector<string> tokenList = stringSplit(strAddress, "/");
    if (tokenList.size() != 2) 
      return false;
    //Fatal("address should have format "
    //	    "aaa.aaa.aaa.aaa/prefixSize, instead found: " << strAddress);

    // Parse address
    strToAddress(resultAddress, tokenList[0]);

    vector<string> prefixTokenList = stringSplit(tokenList[1], "-");
    if (prefixTokenList.size() != 1 
	&& prefixTokenList.size() != 2)
      return false;
          
    // Get prefix first
    int prefixSize = -1;
    if (!strToInt(prefixTokenList[0], prefixSize) 
	|| (prefixSize < 0) 
	|| (prefixSize > AddressSize*BitPerByte))
      return false;
    //Fatal("Bad prefixSize in autoconfiguration address: " 
    //<< tokenList[0]);
    resultSize = prefixSize;

    if (prefixTokenList.size() == 2) {
      int prefixInitialSize = -1;
      if (!strToInt(prefixTokenList[1], prefixInitialSize)
	  || (prefixInitialSize < 0)
	  || (prefixInitialSize > AddressSize*BitPerByte))
	return false;
      resultInitialSize = prefixInitialSize;
    } else resultInitialSize = resultSize;

    return true;
  }

#endif

  static void setAddressPort(SystemAddress& sockAddress, int udpPort)
  { sockAddress.sin_port = htons(udpPort); }

  static void joinMulticastGroup(int sd, string ifaceName, 
				 int ifaceIndex, string strGroupAddress)
  {
    struct ip_mreqn mreq;
    if ( strGroupAddress == STR_IP_BROADCAST) {
      // we don't actually "join" in this case
      setSocketBroadcast(sd);
      char* tmpIfaceName = strdup(ifaceName.c_str());
      setsockopt(sd, SOL_SOCKET, SO_BINDTODEVICE, tmpIfaceName,
		 strlen(tmpIfaceName)+1);
      free(tmpIfaceName);

      return; 
    }

    //XXX! hack
    if (ifaceIndex < -100)
      return;
	  	  
    memset (&mreq, 0, sizeof (mreq));
    inet_pton(AF_INET, strGroupAddress.c_str(), &mreq.imr_multiaddr);
    mreq.imr_ifindex = ifaceIndex;
    //XXX: set imr_address
    
    if(setsockopt(sd, IPPROTO_IP, IP_ADD_MEMBERSHIP,
		  (char *) &mreq, sizeof (mreq)) < 0)
      Fatal(" setsockopt IP_ADD_MEMBERSHIP: " << strerror(errno) );
  }

  // http://www.tldp.org/HOWTO/Multicast-HOWTO-6.html
  static void setSocketMulticastDefaultIface(int sd, int ifaceIndex,
					     SystemAddress& ifaceAddress)
  {
    // XXX: int ifaceIndex
    // XXX: hack
    if (ifaceIndex < -100)
      return;

    if (setsockopt(sd, IPPROTO_IP, IP_MULTICAST_IF, &ifaceAddress.sin_addr,
		   sizeof(ifaceAddress.sin_addr)) < 0)
      Fatal(" setsockopt IP_MULTICAST_IF: " << strerror(errno) );
  }

  //XXX: redundant with IPv6, should be templatized
  static void socketBind(int sd, SystemAddress& address, 
			 bool withKludge = true)
  {
    if (withKludge)
      address.sin_addr.s_addr = INADDR_ANY; // XXX!! kludge
    int status = bind(sd, (struct sockaddr*)&address, sizeof(address));
    if (status < 0)
      Fatal("socketBind: " << strerror(errno));
  }

  static int socketRecv(int sd, void* buffer, int bufferSize,
			SystemAddress& recvAddress)
  {
    socklen_t socketSize = sizeof(recvAddress);
    int status = recvfrom(sd, buffer, bufferSize, /*flags*/ 0,
			  (struct sockaddr*)&recvAddress, &socketSize);
    if(status <0) {
      Warn("error in recvfrom: " << strerror(errno));
      return status;
    } else {
      return status;
    }
  }


  static void socketSend(int sd, void* data, int dataSize, 
			SystemAddress& sendAddress)
  {
    if(sendto(sd, data, dataSize, 0, (sockaddr*)&sendAddress,
	      sizeof(sendAddress)) <0)
      Warn(" sendto: " << strerror(errno) );// XXX: not fatal
  }

#ifdef LINK_MONITORING
  static int recvSignalNoise(int sd, ISystemIface* iface,
			     SystemAddress txAddress)
  {
    LinuxSystemIface<LinuxIPv4LowLevel>* ipv4Iface 
      = (LinuxSystemIface<LinuxIPv4LowLevel>*) iface;

    return get_interface_signal(sd, (char *)ipv4Iface->getName().c_str(), txAddress);
  }
#endif

  static void setSocketMulticastLoop(int sd, bool value)
  {
    int on = (int)value;
    if (setsockopt(sd, SOL_IP, IP_MULTICAST_LOOP, &on, sizeof (on)) < 0)
      Fatal("setsockopt IP_MULTICAST_LOOP: " << strerror(errno));
  }

};
