//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _SCHEDULER_PLUGIN_H
#define _SCHEDULER_PLUGIN_H

//---------------------------------------------------------------------------

#include "base.h"
#include "general_plugin.h"

//---------------------------------------------------------------------------

// XXX: remove extra functions of IScheduler
/// This implements only partially the full protocol:
///   no removeEvent
///   no runUntil, getFirstEventTime, etc...

class PluginScheduler : public IScheduler
{
public:
  virtual EventIdentifier addEvent(Time relativeTime, IEvent* event,
				   void* data)
  { 
    if(relativeTime < 0) relativeTime = 0; // XXX!
    simulatorApi->scheduleAtFunction(relativeTime, pluginSchedulerCallBack,
				     event, data, NULL); 
    return -1; 
  }

  virtual EventIdentifier addEventAt(Time absoluteTime, IEvent* event,
				     void* data)
  { addEvent(absoluteTime-getTime(), event, data); return -1; }

  virtual void removeEvent(EventIdentifier eventIdentifier)
  { Fatal("removeEvent is not implemented for Plugin"); }

  virtual void runUntil(Time absoluteTime)
  { Fatal("runUntil is not implemented for Plugin"); }

  virtual void runUntilNoEvent()
  { Fatal("runUntilNoEvent is not implemented for Plugin"); }

  virtual Time getTime() 
  { return simulatorApi->getCurrentTimeFunction(); }

  /// Returns the time at which the first event should be scheduled
  virtual Time getFirstEventTime()
  { Fatal("getFirstEventTime is not implemented for Plugin"); }

  virtual bool hasEvent()
  { Fatal("hasEvent is not implemented for Plugin"); }

  virtual void write(ostream& out)
  { out << "(PluginScheduler: opaque content)"; }
};

//---------------------------------------------------------------------------

#endif // _SCHEDULER_PLUGIN_H
