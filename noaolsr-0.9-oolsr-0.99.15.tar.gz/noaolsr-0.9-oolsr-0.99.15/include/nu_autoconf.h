//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
// Cedric Adjih, Information Network Research Group,
// Department of Information Engineering, Niigata University.
// Copyright 2004-2005 - Niigata University
// All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _NU_AUTOCONF_H
#define _NU_AUTOCONF_H

//---------------------------------------------------------------------------

#define NU_AUTOCONF_EXTENSION_VERSION_MAJOR 1
#define NU_AUTOCONF_EXTENSION_VERSION_MINOR 0

typedef struct {
  void (*getActualAddressFunction)(void* node, void* rawAddress, 
				   void* rawAddressResult);
} NUAutoConfExtensionApi;

//---------------------------------------------------------------------------

#include "protocol_tuple.h"

typedef enum {
  STATE_undefined = 3, // internal use only
  STATE_HELLO = 2,
  STATE_TOPOLOGY = 1,
  STATE_NORMAL = 0
} AutoConfState;

inline ostream& operator<< (ostream& out, AutoConfState& state)
{
  switch(state) {
  case STATE_undefined: out << "STATE_undefined"; break;
  case STATE_TOPOLOGY: out << "STATE_TOPOLOGY"; break;
  case STATE_HELLO: out << "STATE_HELLO"; break;
  case STATE_NORMAL: out << "STATE_NORMAL"; break;
  default: Fatal("Impossible AutoConfState=" << state);
  }
  return out;
}

//static inline const string autoConfStateToString(AutoConfState state)
//{ return Repr(state); }

class Node;

class StateTuple : public ITuple
{
public:
  Address      S_main_addr;
  Time         S_time;
  Time         S_last_hello_time;
  int          S_last_hello_seq_num;
  Time         S_last_tc_time;
  int          S_last_tc_seq_num;
  Time         S_conflict_time;
#ifdef WITH_AUTOCONF_PRIORITY
  AutoConfState S_conflict_state;
#endif
  Time         S_MPR_remember_time;
  Time         S_MPR_forced_time;
  Time         S_creation_time;
  bool         isOwn;

  AutoConfState S_state;

  bool isInConflict();

  bool isFamiliar();

  StateTuple(Node* aNode) : node(aNode) {}

  virtual Time getExpireTime() { return S_time; }
  virtual void update() { /* nothing to do */ }
protected:
  Node* node;
}; // {DAD}

class StateSet : public BasicTupleSet<StateTuple>
{
public:
  StateSet(Node* aNode) : node(aNode) { }

  StateTuple* findFirst_MainAddr(Address mainAddress)
  { Search(StateTuple, current->S_main_addr == mainAddress); }

  virtual void write(ostream& out);

  StateTuple* ensure(Address address, AutoConfState state = STATE_undefined);

protected:
  Node* node;
  virtual void notifyRemoval(StateTuple* tuple);
  virtual void notifyAddition(StateTuple* tuple);
};

//---------------------------------------------------------------------------

class IAddressChangeAlgorithm
{
public:
  virtual void changeAddress(void* address) = 0;
};

//---------------------------------------------------------------------------

#endif /* _NU_AUTOCONF_H */
