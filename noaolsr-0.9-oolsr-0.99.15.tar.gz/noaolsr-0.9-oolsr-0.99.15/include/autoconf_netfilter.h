//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
// Cedric Adjih, Information Network Research Group,
// Department of Information Engineering, Niigata University.
// Copyright 2004 - Niigata University
// All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _SYSTEM_LINUX_NETLINK_H
#define _SYSTEM_LINUX_NETLINK_H

//---------------------------------------------------------------------------

#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netpacket/packet.h>
#include <net/ethernet.h>

//#include <linux/if.h>
#include <net/if.h>
#include <sys/types.h>
#include <asm/types.h>
#include <linux/netlink.h>
//#include <linux/netfilter_ipv4/ipt_ULOG.h>
#include <ipt_ULOG.h>

#include <map>

using std::map;

//---------------------------------------------------------------------------

#include "scheduler_unix.h"
//#include "node.h"

//---------------------------------------------------------------------------

class UlogNetlinkManager : public IFdHandler
{
public:
  UlogNetlinkManager()
  { 
    openNetlinkSocket();
  }

  virtual ~UlogNetlinkManager()
  { 
    close(netlinkSocket); 
    netlinkSocket = -1;
  }

  void openNetlinkSocket()
  {
    netlinkSocket = socket(PF_NETLINK, SOCK_RAW, NETLINK_NFLOG);
    struct sockaddr_nl addr;
    if (netlinkSocket<0)
      Fatal("socket(PF_NETLINK, SOCK_RAW, NETLINK_NFLOG): "
	    << strerror(errno));
    memset(&addr, 0, sizeof(addr));
    addr.nl_family = AF_NETLINK;
    addr.nl_pad = 0;
    addr.nl_pid = getpid();
    addr.nl_groups = 1; //XXX: should be configurable: groups;
    if (bind(netlinkSocket, (struct sockaddr *)&addr, sizeof(addr))<0)
      Fatal("bind(s,addr_nl<NETLINK,pid,groups>,...): " << strerror(errno));
  }

  virtual void handleUlogMessage(ulog_packet_msg_t* message, 
				 int messageSize) = 0;

  void receiveData()
  {
    struct sockaddr_nl addr;
    unsigned char buffer[16384];
    socklen_t addrSize = sizeof(addr);
    struct nlmsghdr* nlMsg = NULL;
    unsigned int nlSize = 0;
    bool finished = false;
    int status = recvfrom(netlinkSocket, buffer, sizeof(buffer), 0,
			  (struct sockaddr*)&addr, &addrSize);
    if (status < 0 && errno!=EAGAIN && errno!=EINTR)
      Fatal("recvfrom(netlinkSocket, ...): "<<strerror(errno));
    if (addrSize != sizeof(addr))
      Fatal("recvfrom(netlinkSocket, ...) changed size of sockaddr !");
  
    nlMsg = (struct nlmsghdr*) buffer;
    nlSize = status;
    
    if (!NLMSG_OK(nlMsg, nlSize))
      return;
    
    while (!finished) {
      struct ulog_packet_msg* ulogMsg = 
	(struct ulog_packet_msg*) NLMSG_DATA(nlMsg);
      int ulogSize = NLMSG_PAYLOAD(nlMsg, 0);
      handleUlogMessage(ulogMsg, ulogSize);
      
      finished = (nlMsg->nlmsg_type == NLMSG_DONE)
	|| ((nlMsg->nlmsg_flags & NLM_F_MULTI) == 0);
      if (!finished)
	nlMsg = NLMSG_NEXT(nlMsg, nlSize);
    }
  }

  // IFdHandler:
  virtual FileDescriptor getFileDescriptor() { return netlinkSocket; }
  virtual bool waitingForInput() { return true; }
  virtual bool waitingForOutput() { return false; }
  virtual bool waitingForExcept() { return false; }
  virtual void handleInput() { receiveData(); }
  virtual void handleOutput() { Fatal("Impossible call to handleOuput"); }
  virtual void handleExcept() { Fatal("Impossible call to handleExcept"); }

protected:
  int netlinkSocket;
};

//---------------------------------------------------------------------------

class Node;

class DADNetfilterManager : public UlogNetlinkManager
{
public:
  DADNetfilterManager() : node(NULL), nextRuleIndex(0) { }

  // destructor: should destroy all the installed rules

  void setNode(Node* aNode) { node = aNode; }

  static const int NoRuleIndex = -1;
  
  int modifyRule(bool shouldAdd, string deviceName, Address ipv4Address, 
		 string strIpv4Address, 
		 int udpPort, int ruleIndex = NoRuleIndex);

  virtual void handleUlogMessage(ulog_packet_msg_t* message, 
				 int messageSize);

protected:
  Node* node;
  int nextRuleIndex;
  map<int, Address> ruleToAddress;
};

//---------------------------------------------------------------------------

#endif // _SYSTEM_LINUX_NETLINK_H
