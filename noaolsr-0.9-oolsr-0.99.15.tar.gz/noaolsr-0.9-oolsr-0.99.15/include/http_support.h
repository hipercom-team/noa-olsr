//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// Support for the HTTP server (via a modified version of thttpd)
//---------------------------------------------------------------------------

#ifndef _HTTP_SUPPORT_H
#define _HTTP_SUPPORT_H

//---------------------------------------------------------------------------

#include "base.h"

#include <string>
using std::string;

//---------------------------------------------------------------------------

class IOScheduler;

class IHTTPConnection
{
public:
  virtual string getURL() = 0;
  virtual void write(string data) = 0;
  virtual void close() = 0;
  virtual void serveFile() = 0;
  virtual void send404Error() = 0; // XXX: should be: send error
  virtual void sendError(int errorCode, string title, string data,
			 string extraField = "") = 0;
  virtual void sendAuthenticate(string authenticateField) = 0;
  virtual string getAuthentication() = 0;
};

class IHTTPConnectionVisitor
{
public:
  virtual void visit(IHTTPConnection* connection) = 0;
};

class IHTTPServer
{
public:
  virtual void setHTMLErrorTemplate(string htmlTemplate) = 0;
  virtual void open(IOScheduler* scheduler, unsigned short port,
		    IHTTPConnectionVisitor* visitor) = 0;
};

//---------------------------------------------------------------------------

#endif // _HTTP_SUPPORT_H
