//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _NETWORK_GENERIC_H
#define _NETWORK_GENERIC_H

//---------------------------------------------------------------------------

#include "base.h"
#include "address.h"
#include "protocol_config.h"

//---------------------------------------------------------------------------

class OLSRIface;

class PacketInfo
{
public:
  // XXX: fill
};

/// An receiver of packet. Implemented by Node.
class IPacketReceiver
{
public:
  /// (packet:owned)
  virtual void evReceivePacket(MemoryBlock* packet,
			       Address sendIfaceAddress,
			       OLSRIface* recvIface) = 0;
};

//---------------------------------------------------------------------------

class Node;

/// An interface used for OLSR.
/// It performs whatever system calls are necessary to receive and send
/// packets
class ISystemIface
{
public:

  /// Open the send/receive socket(s) and register oneself in the proper
  /// IOScheduler.
  virtual void openSocket(Node* packetReceiver) = 0;

  /// Send a packet to an interface (packet is owned).
  virtual void sendPacket(MemoryBlock* packet) = 0;

  /// Return the maximum packet that the interface can send without IP
  /// fragmentation
  virtual int getMTU() = 0;

  virtual Address getAddress() = 0;

  virtual string getIfaceName() = 0;

  virtual int getIndex() = 0;

#ifdef LINK_MONITORING
  virtual int getSignalLevel(Address txAddress) = 0;
  virtual int getSignalFileDescriptor() = 0;
#endif

  void setOLSRIface(OLSRIface* aIface) // template method
  { associatedIface = aIface; }

  OLSRIface* getOLSRIface() // template method
  { return associatedIface; }

  IfaceConfig* getConfig() // template method
  { return ifaceConfig; }

#ifdef NU_AUTOCONF
  virtual void changeAddress(Address newAddress)
  { Fatal("Address change not supported on this kind of interface"); }
#endif

protected:
  /// The higher level interface associated to this system interface
  /// used when calling 
  OLSRIface* associatedIface;

  /// The interface configuration parameters
  IfaceConfig* ifaceConfig;
};

//---------------------------------------------------------------------------

/// Limited network configurator
class INetworkConfigurator
{
public:

  /// Add one route in the kernel
  virtual void addRoute(ISystemIface* iface, Address destIpAddress,
			Address gatewayAddress, Address netMaskAddress, 
			int metric) = 0;
  
  /// Remove one route from the kernel
  virtual void removeRoute(ISystemIface* iface, Address destIpAddress,
			   Address gatewayAddress, Address netMaskAddress, 
			   int metric) = 0;
};

//---------------------------------------------------------------------------

// XXX: move this out
class IScheduler;

class Node;

class ISystemFactory
{
public:
  virtual AddressFactory* getAddressFactory() = 0;
  virtual ISystemIface* getIfaceByName(ProtocolConfig* protocolConfig,
				       const string name,
				       IfaceConfig* ifaceConfig) = 0;
  virtual IScheduler* getScheduler() = 0;
  virtual INetworkConfigurator* getNetworkConfigurator() = 0;
  virtual void visitNode(Node* node) = 0;
};

//---------------------------------------------------------------------------

#endif // _NETWORK_GENERIC_H
