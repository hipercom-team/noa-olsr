//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------
// This is because embedded VC++ SP4 doesn't have <iostream>, <sstream> 
// and the like
//---------------------------------------------------------------------------

#ifndef _MY_STREAM_H
#define _MY_STREAM_H

//---------------------------------------------------------------------------

#ifdef UNDER_CE

#include <windows.h>

#include <string>
#include <string.h>
#include <stdio.h>

using std::string;

//---------------------------------------------------------------------------

class Manip 
{
public:
  Manip(string aType) : type(aType), arg(0) {}
  string type;
  int arg;
};
extern Manip hex;
extern Manip endl;
extern Manip dec;

//class endl
//{ };

//class hex
//{ public: hex(int x) {} };

class setfill : public Manip
{ public: setfill(int x) : Manip("setfill") { arg=x; } };

class setw : public Manip
{ public: setw(int x) : Manip("setw") { arg=x; } };

//---------------------------------------------------------------------------

class ostream
{
public:
  string floatPrecision;
  bool hexMode;
  string fillChar;
  string fieldWidth;

  ostream() 
  { 
    floatPrecision = "%f";
    //intFormat = "%d";
    hexMode = false;
    fillChar = "";
    fieldWidth = "";
  }

  void precision(int digit) 
  {
    sprintf(tmp, "%d", digit);
    floatPrecision = "%";
    floatPrecision += tmp;
    floatPrecision += "f";
  }

  virtual void write(string data) {}

  virtual void close() {}

  virtual ~ostream()
  { close(); }

  ostream& operator << (const DWORD& value)
  { 
    //    sprintf("
    return *this << (unsigned int)value;
  }

  ostream& operator << (const unsigned int& value)
  { 
    string format = "%" + fillChar + fieldWidth;
    if (hexMode) format += "x";
    else format += "u";
    sprintf(tmp, format.c_str(), value);
    write(tmp);
    fieldWidth = ""; fillChar = " ";
    return *this; 
  }

  ostream& operator << (const int& value)
  { 
    if (hexMode) 
      return (*this) << (unsigned int)value;
    string format = "%" + fillChar + fieldWidth + "d";
    sprintf(tmp, format.c_str(), value);
    write(tmp);
    fieldWidth = ""; fillChar = " ";
    return *this; 
  }

  ostream& operator << (const double& value)
  { 
    sprintf(tmp, floatPrecision.c_str(), value);
    write(tmp);
    return *this; 
  }

  ostream& operator << (const Manip& manip)
  { 
    if (manip.type == "endl") write("\n");
    else if (manip.type == "hex") hexMode = true;
    else if (manip.type == "dec") hexMode = false;
    else if (manip.type == "setfill") {
      fillChar = (char)manip.arg;
    } else if (manip.type == "setw") {
      sprintf(tmp, "%d", manip.arg);
      fieldWidth = tmp;
    }
    return *this; 
  }

  ostream& operator << (const string& data)
  { write(data); return *this; }

  ostream& operator << (const char* data)
  { write(data); return *this; }

  //ostream& operator << (char* data)
  //{ write(data); return *this; }

  ostream& operator << (const char& data)
  { sprintf(tmp, "%c", data); write(tmp); return *this; }

protected:
  char tmp[128];
};

class ostringstream : public ostream
{
public:
  virtual void write(string data)
  { content += data; }

  string str() { return content; }
protected:
  string content;
};

class ofstream : public ostream
{ 
public:
  ofstream(const char* fileName) 
  {
    out = fopen(fileName,"w");
  }

  virtual void write(string data)
  { 
    if (out!= NULL) {
      fwrite(data.data(), data.length(), 1, out);
      fflush(out);
    }
  }

  virtual void close()
  { fclose(out); out=NULL; }

protected:
  FILE* out;
};

//---------------------------------------------------------------------------

extern ofstream cout;
extern ofstream cerr;

#if 0
template <typename T>
ostream& operator << (ostream& out, const T& value)
{ return out; }
#endif

extern int abort();

//---------------------------------------------------------------------------

#else

#include <iomanip>
#include <iostream>
#include <fstream>
#include <sstream>

using std ::cout;
using std ::cerr;
using std ::ostream;
using std:: endl;
using std:: ostringstream;
using std:: hex;
using std:: setw;
using std:: setfill;
using std:: dec;
using std:: ofstream;
using std:: ifstream;

#endif

//---------------------------------------------------------------------------

#endif //_MY_STREAM_H
