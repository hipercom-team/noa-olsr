//-----------------------------------------------------------------*- c++ -*-
//                                OOLSR
//             Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2003-2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _SCHEDULER_UNIX_H
#define _SCHEDULER_UNIX_H

//---------------------------------------------------------------------------

#include "base.h"

#include <list>

#include "general.h"
#include "log.h"
#include "scheduler_generic.h"

//---------------------------------------------------------------------------

typedef int FileDescriptor;

/// IFdHandler, a FileDescriptor Handler.
/// It is used within the IOScheduler in when it is needed to wait.
class IFdHandler
{
public:
  virtual FileDescriptor getFileDescriptor() = 0;
  virtual bool waitingForInput() = 0;
  virtual bool waitingForOutput() = 0;
  virtual bool waitingForExcept() = 0;
  virtual void handleInput() = 0;
  virtual void handleOutput() = 0;
  virtual void handleExcept() = 0;
};

//---------------------------------------------------------------------------

class IOScheduler : public IScheduler
{
public:
  IOScheduler(IScheduler* baseScheduler) : scheduler(baseScheduler)
  { clockOffset = 0.0; inSchedulerRunUntil = false; }

  virtual ~IOScheduler() {}

  virtual EventIdentifier addEvent(Time relativeTime, 
				   IEvent* event, void* data)
  { return scheduler->addEvent(relativeTime, event, data); }

  virtual EventIdentifier addEventAt(Time absoluteTime, IEvent* event,
				     void* data)
  { return scheduler->addEventAt(absoluteTime, event, data); }

  virtual void removeEvent(EventIdentifier eventIdentifier)
  { scheduler->removeEvent(eventIdentifier); }

  virtual void runUntil(Time absoluteTime)
  {
    for(;;) {
      Time currentTime = getTime();

      if(currentTime >= absoluteTime)
	break;
      inSchedulerRunUntil = true;
      scheduler->runUntil(currentTime);
      inSchedulerRunUntil = false;
      Time maxDelay = TimeNever;
      if(scheduler->hasEvent()) {
	Time eventTime = scheduler->getFirstEventTime();
      
	maxDelay = eventTime-currentTime;
      }
      waitForIO(maxDelay);
    }
  }

  virtual void runUntilNoEvent()
  { runUntil(TimeNever); }

  virtual Time getTime();

  void waitForIO(Time maxDelay);

  void addFdHandler(IFdHandler* fdHandler, void* data);
  
  void removeFdHandler(IFdHandler* fdHandler)
  {
    for(std::list< std::pair<IFdHandler*, void*>  >::iterator it
	  = handlerList.begin(); it != handlerList.end(); it++)
      if (fdHandler == (*it).first) {
	handlerList.erase(it);
	return;
      }
  }

  virtual Time getFirstEventTime()
  { Fatal("Not a meaningfull call"); return TimeNever; }

  virtual bool hasEvent()
  { Fatal("Not a meaningfull call"); return false; }

  virtual void write(ostream& out);

  void setClockOffset(Time offset)
  { clockOffset = offset; }

  IScheduler* scheduler;
  std::list< std::pair<IFdHandler*, void*>  > handlerList;
  Time clockOffset;

  bool inSchedulerRunUntil; // XXX: This is because of a more general
  // problem in the algorithm of the scheduler when there is lag
  // XXX: is this really working ?
};

//---------------------------------------------------------------------------

#endif // _SCHEDULER_UNIX_H
