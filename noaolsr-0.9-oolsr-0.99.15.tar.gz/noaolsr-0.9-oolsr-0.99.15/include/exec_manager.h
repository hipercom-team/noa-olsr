//-----------------------------------------------------------------*- c++ -*-
//                             OOLSR
//               Cedric Adjih, projet Hipercom, INRIA Rocquencourt
//  Copyright 2004 Institut National de Recherche en Informatique et
//  en Automatique.  All rights reserved.  Distributed only with permission.
//---------------------------------------------------------------------------

#ifndef _EXEC_MANAGER_H
#define _EXEC_MANAGER_H

//---------------------------------------------------------------------------

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>

#include "general.h"
#include "log.h"

//---------------------------------------------------------------------------

class CommandManager
{
public:
  CommandManager(list<string>& anArgList) 
  { 
    argList = anArgList; 
    state = StateInitial; 
  }

  void start() 
  {
    assert( state == StateInitial );
    signal(SIGPIPE, SIG_IGN); // XXX: ignore SIG_IGN, check BSDs
    if (pipe(childToParentOut) < 0)
      Fatal("pipe: " << strerror(errno));
    if (pipe(childToParentErr) < 0)
      Fatal("pipe: " << strerror(errno));
    if (pipe(parentToChild) < 0)
      Fatal("pipe: " << strerror(errno));
    childPid = fork();
    if (childPid < 0)
      Fatal("fork: " << strerror(errno));
    if (childPid == 0) {
      runAsChild();
      exit(EXIT_FAILURE);
    } else setUpParent();
    state = StateStarted;
  }

  void runAsChild()
  {
    close(childToParentOut[0]);
    close(childToParentErr[0]);
    close(parentToChild[1]);
    dup2(parentToChild[0], 0);
    dup2(childToParentOut[1], 1);
    dup2(childToParentErr[1], 2);
    int nbArg = argList.size();
    char** argPtr = new char* [nbArg+1];
    int i=0;
    list<string>::iterator it = argList.begin();
    while (it != argList.end()) {
      assert (i<nbArg);
      argPtr[i] = strdup((*it).c_str());
      //XXX:remove:cerr << (*it) << " ";
      it++;
      i++;
    }
    //XXX:remove:cerr << endl;
    assert( i == nbArg );
    argPtr[nbArg] = NULL;
    if (execvp(argPtr[0], argPtr) < 0)
      Fatal("execvp: " << strerror(errno));
  }

  void waitForEvent(Time maxTime = TimePastNever)
  {
    assert( state == StateStarted );
    fd_set inFdSet; // (note: in cygwin/winsock2, this is not a bitmap)
    fd_set outFdSet;
    fd_set exceptFdSet;

    FD_ZERO(&inFdSet);
    FD_ZERO(&outFdSet);
    FD_ZERO(&exceptFdSet);

    int maxFd = -1;
    if (!outClosed) {
      FD_SET(childToParentOut[0], &inFdSet);
      maxFd = myMax(maxFd, childToParentOut[0]);
    }
    if (!errClosed) {
      FD_SET(childToParentErr[0], &inFdSet);
      maxFd = myMax(maxFd, childToParentErr[0]);
    }
    if (!writeClosed && writeBuffer.length()>0) {
      FD_SET(parentToChild[1], &outFdSet);
      maxFd = myMax(maxFd, parentToChild[1]);
    }
    if (hasInputFd) {
      FD_SET(inputFd, &inFdSet);
      maxFd = myMax(maxFd, inputFd);
    }
    if (maxFd >= 0) {
      struct timeval timeOut;
      struct timeval* timeOutPtr = &timeOut;
      if (maxTime < 0) 
	timeOutPtr = NULL;
      else {
	timeOut.tv_sec = (long)maxTime;
	if ((maxTime - timeOut.tv_sec) > 10.0 /* actually: 1.0 */)
	  timeOutPtr = NULL; /* maxTime was probably too big, so no block */
	else {
	  timeOut.tv_usec = (int)((maxTime - timeOut.tv_sec)*1e6);
	  if (timeOut.tv_usec >= 1000000) {
	    // this should not happen, but anyway, if it does we don't
	    // want to abort, FATAL or crash
	    timeOut.tv_usec = 1000000-1;
	  }
	}
      }
      int status = select(maxFd+1, &inFdSet, &outFdSet, &exceptFdSet,
			  timeOutPtr);
      if (status<0 && errno!= EINTR)
	Fatal("select: " << strerror(errno));
      else {
	if (!outClosed && FD_ISSET(childToParentOut[0], &inFdSet))
	  _readSomeData(childToParentOut[0], receivedOutBuffer, outClosed);
	if (!errClosed && FD_ISSET(childToParentErr[0], &inFdSet))
	  _readSomeData(childToParentErr[0], receivedErrBuffer, errClosed);
	if (!writeClosed && FD_ISSET(parentToChild[1], &outFdSet))
	  _writeSomeData(parentToChild[1], writeBuffer, writeClosed);
	if (hasInputFd && FD_ISSET(inputFd, &inFdSet)) {
	  bool closed = false;
	  string inputData = "";
	  _readSomeData(inputFd, inputData, closed);
	  writeBuffer += inputData;
	  if (closed) {
	    (void)close(inputFd);
	    inputFd = -1;
	    hasInputFd = false;
	    endPushIn();
	  }
	}
      }
    }
    checkChildStatus();
  }

  void waitIOCompletion(Time timeOut = TimePastNever)
  {
    while (!(outClosed && (writeClosed || hasTerminated())))
      waitForEvent(timeOut);
  }

  void checkChildStatus()
  {
    if (!commandFinished) {
      int status = 0;
      pid_t result = waitpid(childPid, &status, WNOHANG|WUNTRACED); //|__WALL);
      if (result < 0) {
#if 0 // XXX: should uncomment this?
	if (errno == ECHILD)
	  commandFinished = true; // probably
	//else
#endif
	if (errno != EINTR)
	  Fatal("waitpid: " << strerror(errno));
      } else if (result > 0) {
	assert( result == childPid );
	if (WIFEXITED(status)) {
	  commandFinished = true;
	  childStatus = WEXITSTATUS(status);
	} else if (WIFSIGNALED(status)) {
	  commandFinished = true;
	  childSignal = WTERMSIG(status);
	}
      }
    }
  }

  void _readSomeData(int fd, string& buffer, bool& isClosed)
  { 
    assert(!isClosed);
    const int BUFFER_SIZE = 1024;
    char charBuffer[BUFFER_SIZE];
    int status = read(fd, charBuffer, 
		      myMin((long)BUFFER_SIZE, (long)SSIZE_MAX));
    if (status < 0) {
      if (errno != EINTR  && errno != EAGAIN)
	Fatal("read: " << strerror(errno));
    } else if (status == 0) {
      isClosed = true;
      (void)close(fd);
    } else {
      string newData(charBuffer, status);
      buffer += newData;
    }
  }

  void _writeSomeData(int fd, string& buffer, bool& isClosed)
  {
    assert(!isClosed && buffer.length()>0);
    int status = write(fd, buffer.data(), buffer.length());
    if (status < 0) {
      if (errno == EPIPE) {
	isClosed = true; // Note: need to block signals
	(void)close(fd);
      } else if (errno != EINTR  && errno != EAGAIN)
	Fatal("write: " << strerror(errno));
    } else {
      if (status > 0)
	buffer.erase(0, status);
    }
  }

  void setUpParent()
  {
    close(parentToChild[0]);
    close(childToParentOut[1]);
    close(childToParentErr[1]);
    writeClosed = false;
    outClosed = false;
    errClosed = false;
    commandFinished = false;
    childStatus = -1;
    childSignal = -1;
    hasInputFd = false;
    inputFd = -1;
  }

  bool hasTerminated()
  {
    assert( state == StateStarted );
    return commandFinished;
  }

  int getStatus()
  { 
    assert( state == StateStarted );
    assert( commandFinished );
    return childStatus;
  }

  int getTermSignal()
  { 
    assert( state == StateStarted );
    assert( commandFinished );
    return childSignal;
  }

  void killChild()
  { 
    assert( state == StateStarted );
    checkChildStatus();
    if (!commandFinished) {
      if (kill(childPid, SIGKILL) < 0)
	Fatal("kill: " << strerror(errno));
      checkChildStatus(); // XXX:dunno if it is asynchronous
    }
  }

  ~CommandManager()
  { 
    if(state == StateStarted && !commandFinished)
      killChild();

    if (hasInputFd) (void) close(inputFd);
    if (!writeClosed) close(parentToChild[1]);
    if (!outClosed) close(childToParentOut[0]);
    if (!errClosed) close(childToParentErr[0]);
  }

  void pushInFd(int fd)
  {
    assert( state == StateStarted );
    assert( !hasInputFd );
    inputFd = fd;
    hasInputFd = true;
  }

  bool inFdFinished()
  { return !hasInputFd; }

  void pushInData(string data) 
  {
    assert( state == StateStarted && !writeClosed );
    writeBuffer += data;
  }

  void endPushIn()
  { 
    assert( state == StateStarted);
    assert( !writeClosed );
    writeClosed = true; 
    close(parentToChild[1]);
  }

  string popOutData()
  { 
    string result  = receivedOutBuffer;
    receivedOutBuffer = "";
    return result;
  }

  string popErrData()
  { 
    string result  = receivedErrBuffer;
    receivedErrBuffer = "";
    return result;
  }

  string getInBuffer() { return writeBuffer; }

  //--------------------------------------------------

  int simpleRun(string& output, string& error)
  {
    start();
    endPushIn();
    waitIOCompletion();
    if (hasTerminated()) {
      // Ok
      output = popOutData();
      error = popErrData();
      return getStatus();
    } else return -1;
  }

protected:
  int childToParentOut[2];
  int childToParentErr[2];
  int parentToChild[2];

  list<string> argList;

  typedef enum {
    StateInitial, StateStarted
  } StateType;

  StateType state;

  // This is from the parent point of view
  int childPid;
  string writeBuffer;
  bool writeClosed;
  string receivedOutBuffer;
  bool outClosed;
  string receivedErrBuffer;
  bool errClosed;
  bool commandFinished;
  int childStatus;
  int childSignal;

  int inputFd;
  bool hasInputFd;
};

//---------------------------------------------------------------------------

template <typename T>
static inline list<T>& operator <<(list<T>& l, T value)
{ l.push_back(value); return l; }

static inline list<string>& operator <<(list<string>& l, char* value)
{ l.push_back(value); return l; }

//--------------------------------------------------


//---------------------------------------------------------------------------

#endif // _EXEC_MANAGER_H

