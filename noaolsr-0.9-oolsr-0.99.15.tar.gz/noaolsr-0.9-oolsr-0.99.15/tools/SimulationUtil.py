#---------------------------------------------------------------------------
#                             OOLSR (from pyOLSR)
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
#  Copyright 2003-2004 Institut National de Recherche en Informatique et  
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------
# TODO:
# - this need to be seriously cleaned up
#---------------------------------------------------------------------------

import re

#---------------------------------------------------------------------------

def runScenario(scenarioString, duration):
    simulation=OLSRSimulation(scenarioString, duration)
    simulation.create()  # dodge this
    simulation.run()
    return simulation

#---------------------------------------------------------------------------


optSep = "[ \t\n\r;,]*"
#nodeDef = "(?:([a-zA-Z]+)([0-9]+))|(?:(N[0-9]+)(I[0-9]+))"
nodeDef = ("(?:"
           +"(?:([a-zA-Z]+)([0-9]+)(?![0-9I]))"
           +"|"
           +"(?:(N[0-9]+)(I[0-9]+))"
           +")")
timeDef = "([0-9]+(?:[.][0-9]+)?)"
optLinkDef = ("(?:"
              + "[(]"  # (
              + optSep + "(?:(?:"+timeDef+")?)"
              + optSep +"[:]"
              + optSep + timeDef + optSep
              + "[)]" # )
              +")?") # optional
rLink = re.compile(optSep  +nodeDef
                   +optSep +"((<->)|(<-)|(->))"
                   +optSep +nodeDef
                   +optSep +optLinkDef +optSep,
                   re.MULTILINE)

rDebug = re.compile(optSep+"\\?([a-zA-Z]+)([0-9]+)?\\(([^)]+)\\)"+optSep,
                    re.MULTILINE)

rConfig = re.compile(optSep+r'((?:[a-zA-Z]+(?![0-9]))|(?:N[0-9]+))'
                     +'[(]([^)]+)[)]'+optSep,
                     re.MULTILINE)
rCheck = re.compile(optSep+"at"+optSep+"[(]([^)]+)[)]"+optSep)

def convert(nodeName):
    if nodeName.startswith('N') and '0' <= nodeName[-1] <= '9': #XXX
        return int(nodeName[1:])
    else:
        result = ord(nodeName)-ord('A')
        assert( 0 <= result <= 25 )
        return result

def parseScenario(data):
    linkList = []
    debugList = []
    nodeName = {}
    ifaceName = {}
    checkPointList = []
    nodeConfig = {}
    while len(data)>0:
        m = rLink.match(data)
        mDebug = rDebug.match(data)
        mConfig = rConfig.match(data)
        mCheck = rCheck.match(data)
        #print data, m, mDebug, mMacro
        #print data, m, mDebug, mConfig, mCheck
        if m!=None:
            # parse LINK:
            start,end = m.span()
            assert start == 0
            data=data[end:]

            #for i in range(100): print m.group(i)

            if m.group(1) != None: name1,iface1 = m.group(1), m.group(2)
            else: name1,iface1 = m.group(3), m.group(4)[1:]
            
            linkType = m.group(5)
            if m.group(9) != None: name2,iface2 = m.group(9), m.group(10)
            else: name2,iface2 = m.group(11), m.group(12)[1:]

            if m.group(13)!= None: upTime = m.group(13)
            else: upTime = None
            if m.group(14)!= None: downTime = m.group(14)
            else: downTime = None
            #print "LINK", name1, iface1, linkType, \
            #              name2, iface2, upTime, downTime

            if linkType == "->" or linkType == "<->":
                linkList.append( (name1, iface1, name2, iface2,
                                  upTime, downTime) )
            if linkType == "<-" or linkType == "<->":
                linkList.append( (name2, iface2, name1, iface1,
                                  upTime, downTime) )
            if not nodeName.has_key(name1): nodeName[name1]={}
            nodeName[name1][iface1] = "<exists>"
            if not nodeName.has_key(name2): nodeName[name2]={}
            nodeName[name2][iface2] = "<exists>"
        elif mDebug != None: # XXX: no longer used.
            # parse DEBUG:  ?node(...)
            # where ... is the "debug" string specification
            start,end = mDebug.span()
            assert start == 0
            data=data[end:]
            
            thisNodeName = mDebug.group(1)
            optIface = mDebug.group(2)
            debugString = mDebug.group(3)
            debugList.append( thisNodeName )
        elif mCheck != None:
            start,end = mCheck.span()
            assert start == 0
            data=data[end:]
            checkInfo = mCheck.group(1).split(",")
            checkPointList.append([float(checkInfo[0])]
                                  + [x.strip() for x in checkInfo[1:]])
        elif mConfig != None:
            start,end = mConfig.span()
            assert start == 0
            data=data[end:]

            name = mConfig.group(1)
            configStr = mConfig.group(2)
            nodeConfig[name] = configStr
        else: raise "Syntax error in scenario", data

    nodeList = [ x for x in nodeName.keys() ]
    nodeList.sort() # XXX: added, check if ok.
    ifaceList = {}
    ifaceCountList = []
    #for name in nodeName.keys():
    for name in nodeList:
        nodeIdx = convert(name)
        ifaceList[nodeIdx] = [ int(x) for x in nodeName[name].keys() ]
        ifaceList[nodeIdx].sort()
        ifaceCountList.append( len(ifaceList[nodeIdx]) )

    nodeList = [ convert(x) for x in nodeName.keys() ]
    matrix = {}
    for name1,iface1,name2,iface2,upTime,downTime in linkList:
        idx1 = nodeList.index(convert(name1))
        idx2 = nodeList.index(convert(name2))
        ifaceIdx1 = int(iface1) #ifaceList[convert(name1)].index(iface1)
        ifaceIdx2 = int(iface2) #ifaceList[convert(name2)].index(iface2)
        if not matrix.has_key( (idx1, ifaceIdx1) ):
            matrix[(idx1,ifaceIdx1)] = []
        matrix[(idx1,ifaceIdx1)].append( (idx2,ifaceIdx2) )
    nbNode = len(ifaceCountList)
    del matrix # XXX: no longer used
    
    #return nbNode, ifaceCountList, matrix, nodeList, ifaceList, debugList
    #print nodeList, nodeName, ifaceList, matrix, linkList

    # XXX: this need to be cleaned up.
    nodeTable = {}
    for name in nodeName.keys():
        nodeIfaceList = [ name+ifaceId for ifaceId in nodeName[name].keys()]
        nodeIfaceList.sort()
        nodeTable[name] = nodeIfaceList

    nodeConfigTable = {}
    for node,config in nodeConfig.items():
        nodeConfigTable[convert(node)] = config

    #realLinkList = [ (0.0, 'up', x+y, u+t) for x,y,u,t in linkList ]
    #realLinkList = [ (0.0, 'up', (convert(x), int(y)), (convert(u), int(t)))
    #                  for x,y,u,t in linkList ]
    realLinkList = []
    for x,y,u,t,up,down in linkList:
        if up == None:
            realLinkList.append \
            ((-1.0, True, (convert(x), int(y)), (convert(u), int(t))))
        elif up ==  "-": pass
        else:
            realLinkList.append \
            ((float(up), True,(convert(x), int(y)), (convert(u), int(t))))
        if down != None:
            realLinkList.append \
            ((float(down), False,(convert(x), int(y)), (convert(u), int(t))))

    #return nodeTable, realLinkList
    return nodeList, ifaceList, realLinkList, checkPointList, nodeConfigTable

rScenario = re.compile(optSep+"[[]([^]]+)[][" +optSep)

def parseSeveralScenario(data):
    result = []
    scenarioList = rScenario.split(data)
    if scenarioList[0] == '':
        del scenarioList[0]
    else: scenarioList = [ "default" ] + scenarioList
    for i in range(0,len(scenarioList),2):
        scenarioName = scenarioList[i+0]
        scenario = scenarioList[i+1]
        result.append( (scenarioName, parseScenario(scenario)) )
    return result

#---------------------------------------------------------------------------

def generateUMLConfig(prefix, data):
    info = parseSeveralScenario(data)
    nbNode, ifaceCountList, matrix, nodeList, ifaceList, debugList = info
    result = (
        "#--------------------------------------------------\n"+
        "# Configuration file. automatically generated from\n"+
        "# Scenario: %s\n" % data+
        "#--------------------------------------------------\n"+
        "#<NbMachine=%d>\n" % nbNode + "\n")
    resultSh = "NBMACHINE=%d\n" % nbNode
    def s(nodeIdx, ifaceIdx): return ifaceIdx*10+(nodeIdx+1)
    matrixItems = matrix.items()
    matrixItems.sort()

    for nodeIdx in range(len(nodeList)):
        resultSh += 'NAME%d="%s"\n' % (nodeIdx+1, nodeList[nodeIdx])
        nodeIfaceList = ifaceList[nodeList[nodeIdx]]
        resultSh += "NBETH%d=%d\n" % (nodeIdx+1, len(nodeIfaceList))
        ifaceStr = ""
        for ifaceIdx in range(len(nodeIfaceList)):
            resultSh += "IP%d_%d=%d\n" % (nodeIdx+1, ifaceIdx, s(nodeIdx, ifaceIdx))
            ifaceStr += " %s%s(%d)" % (nodeList[nodeIdx], nodeIfaceList[ifaceIdx], s(nodeIdx, ifaceIdx))
        resultSh += "IFSTR%d='%s'\n" % (nodeIdx+1, ifaceStr)
    
    for (nodeIdx,ifaceIdx), linkList in matrixItems:
        i = s(nodeIdx, ifaceIdx)
        result += "# %d: iface %d of node '%s' w/ iface:" % (i, ifaceIdx, nodeList[nodeIdx])
        nodeIfaceList = ifaceList[nodeList[nodeIdx]]
        for j in range(len(nodeIfaceList)):

            result += " %d=eth%d(%s%s)" % (j, j, nodeList[nodeIdx],
                                           nodeIfaceList[j])
        result += "\n%s " % i
        for (dstNodeIdx, dstIfaceIdx) in linkList:
            result += " %s" % s(dstNodeIdx, dstIfaceIdx)
        result += "\n"
    Base.writeFile(prefix+".conf", result)
    Base.writeFile(prefix+".py", repr(info))
    Base.writeFile(prefix+".sh", resultSh)

#---------------------------------------------------------------------------

def testParser():
    print parseScenario("A0->B0, B0 -> A0")
    print parseScenario("A1 <-> B1")
    print parseScenario("A1 <-> B1 ; A0 <-> B1")
    print parseScenario("A1 <-> B1 , ?A(H)  ;A0 <-> B1 ; ?B0(h)")

#---------------------------------------------------------------------------

def nthLetter(n):
    assert 0<= n < 26
    return chr(ord('A')+n)

def name(x):
    if x<26: return nthLetter(x)
    else: return nthLetter( int(x/26) ) + nthLetter( x % 26 )

def makeLinear(n,*optList):
    #XXX: check options
    if "unidir" in optList: sep=""
    else: sep="<"
    if "ring" in optList: bound=n
    else: bound=n
    linkList = [ "%s0 %s-> %s0" %(name(i),sep,name((i+1)%bound))
                 for i in range(n)]

    return ";".join(linkList)

#def makeTree(depth):
#    nbNode = 1<<

def makeFullyConnected(n,m):
    linkList = [ "%s0 -> %s0" % (name(i),name(j))
                 for i in range(n) for j in range(m)]
    return ";".join( linkList)    

# Non-working connection
ScenarioUnidirLink = "A0 -> B0"
# Simple link
ScenarioLinear1 = "A0 <-> B0"
# 2 links, 1 2 hop route
ScenarioLinear2 = "A0 <-> B0 ; B0 <-> C0" 
# Linear, 20 stations, 19 links
ScenarioLinearUniDir20 = makeLinear(20,"unidir") #+ " ?C(H) "
ScenarioLinear20 = makeLinear(20)
ScenarioRing20 = makeLinear(20, "ring")

Scenario3 = "A0 -> B0 ; B0 <-> C0 ; A0 <-> C0"
Scenario2 = "A0 <-> B0 ; A1 <-> C0" # Multiple iface routing

Scenario4 = "A0 -> B0 ; B1 -> A1"
Scenario5 = "A0 <-> B0 ; A1 <-> C1 ; B1 <-> C0"

Scenario6 = """A0  -> B0 ; B0  -> C0 ; C0  -> D0 ; D0  -> A0
               A1 <-> B1 ; B1 <-> C1 ; C1 <-> D1 ; D1 <-> A1"""

def makeDense(nbNeighbor, nbHop):
    result = []
    for hop in range(nbHop):
        for i in range(nbNeighbor):
            me = name(hop*26+i)
            if hop > 0 and i==0:
                previous = name((hop-1)*26+i)
                result.append(" %s0 <-> %s0 " % (me, previous))
            for j in range(nbNeighbor):
                if i!=j:
                    other = name(hop*26+j)
                    result.append(" %s0 <-> %s0 " % (me,other))
    return ";".join(result)

#print makeDense(4, 4)

def test(scenario = Scenario5, duration=100):
    sim = runScenario(scenario, duration)
    #sim = runScenario(ScenarioLinear20, duration=100.0)
    for node in sim.nodeList:
        print node
    for node in sim.nodeList:
        print "%s:" % node.getMainAddress(),
        for iface in node.getAllIfaceList():
            print "%s(<-:%d,->:%d)" % (iface.getAddress(),
                                       iface.statRecv, iface.statSend),

#XXX: linear/ring are broken

ScenarioTable = {
    "self": "A0 <-> A1",
    "linear2": makeLinear(2),
    "linear3": makeLinear(3),
    "ring3": makeLinear(3, "ring"),
    "unidir3": makeLinear(3, "unidir"),
    "linear20": ScenarioLinear20,
    "ring20": ScenarioRing20,
    "unidir20" : ScenarioLinearUniDir20,
    "dense9": makeDense(3,3)
}

def mainRunScenario(scenarioString, optDuration):
    if optDuration != []:
        duration = int( optDuration[0] )
    else: duration = 100.0
    test(scenarioString, duration)

#---------------------------------------------------------------------------

def testMacro():
    print parseScenario("@makeLinear(10) ; A0 <-> Z0")

#if __name__=="__main__": testParser()
if __name__=="__main__": test()
#if __name__=="__main__": testMacro()

#---------------------------------------------------------------------------
