//{{NO_DEPENDENCIES}}
// Microsoft eMbedded Visual C++ generated include file.
// Used by oolsrCE.rc
//
#define IDS_APP_TITLE                   1
#define IDS_HELLO                       2
#define IDC_OOLSRCE                     3
#define IDI_OOLSRCE                     101
#define IDM_MENU                        102
#define IDD_ABOUTBOX                    103
#define IDS_HELP                        104
#define IDS_COMMAND1                    301
#define IDM_MAIN_COMMAND1               40001
#define IDM_HELP_ABOUT                  40003
#define IDS_CAP_ABOUT                   40006
#define IDS_CAP_TOOLS                   40008
#define IDM_FILE_EXIT                   40009
#define IDS_CAP_EXIT                    40011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40013
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
